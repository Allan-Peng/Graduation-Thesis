/*
 Navicat MySQL Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : localhost:3306
 Source Schema         : hihr

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 19/05/2019 23:53:00
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for al_stores
-- ----------------------------
DROP TABLE IF EXISTS `al_stores`;
CREATE TABLE `al_stores` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `answer` text NOT NULL,
  `tags` varchar(255) NOT NULL,
  `kind` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for bd_stores
-- ----------------------------
DROP TABLE IF EXISTS `bd_stores`;
CREATE TABLE `bd_stores` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `answer` text,
  `tags` varchar(255) DEFAULT NULL,
  `kind` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for be_stores
-- ----------------------------
DROP TABLE IF EXISTS `be_stores`;
CREATE TABLE `be_stores` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `answer` text,
  `tags` varchar(255) DEFAULT NULL,
  `kind` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for candidates
-- ----------------------------
DROP TABLE IF EXISTS `candidates`;
CREATE TABLE `candidates` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `college` varchar(255) NOT NULL,
  `graduate` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `kind` varchar(255) NOT NULL,
  `resume` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for commits
-- ----------------------------
DROP TABLE IF EXISTS `commits`;
CREATE TABLE `commits` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `resumeId` text NOT NULL,
  `commit` text NOT NULL,
  `date` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `addName` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of commits
-- ----------------------------
BEGIN;
INSERT INTO `commits` VALUES (1, '57', '我不知道该说点什么好', '2018:1:1', '2019-01-14 18:12:34', '2019-01-14 18:12:40', '111');
INSERT INTO `commits` VALUES (2, '57', '我该说点什么呢', '2018:2:1', '2019-01-15 19:19:38', '2019-01-16 19:19:44', '222');
INSERT INTO `commits` VALUES (3, '57', '真的不知道说点什么了', '2', '2019-01-22 19:20:13', '2019-01-14 19:20:21', '333');
INSERT INTO `commits` VALUES (4, '57', '123', '111', '2019-01-14 21:28:38', '2019-01-14 21:28:38', '111');
INSERT INTO `commits` VALUES (5, '57', '123456', '111', '2019-01-14 21:29:45', '2019-01-14 21:29:45', '111');
INSERT INTO `commits` VALUES (6, '63', '123', '111', '2019-01-15 11:38:27', '2019-01-15 11:38:27', '111');
INSERT INTO `commits` VALUES (7, '63', '我也不知道说点什么啊', '111', '2019-01-15 11:45:40', '2019-01-15 11:45:40', '111');
INSERT INTO `commits` VALUES (8, '63', '那就随便说一点吧', 'January 15th 2019, 11:49:29 am', '2019-01-15 11:49:29', '2019-01-15 11:49:29', '111');
COMMIT;

-- ----------------------------
-- Table structure for departments
-- ----------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for exams
-- ----------------------------
DROP TABLE IF EXISTS `exams`;
CREATE TABLE `exams` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `jobTitle` varchar(255) NOT NULL,
  `paperId` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `isDelete` int(11) NOT NULL,
  `answer1` text,
  `answer2` text,
  `answer3` text,
  `answer4` text,
  `answer5` text,
  `answer6` text,
  `answer7` text,
  `answer8` text,
  `answer9` text,
  `answer10` text,
  `answer11` text,
  `answer12` text,
  `answer13` text,
  `answer14` text,
  `answer15` text,
  `answer16` text,
  `answer17` text,
  `answer18` text,
  `answer19` text,
  `answer20` text,
  `answer21` text,
  `answer22` text,
  `answer23` text,
  `answer24` text,
  `answer25` text,
  `answer26` text,
  `answer27` text,
  `answer28` text,
  `answer29` text,
  `answer30` text,
  `answer31` text,
  `answer32` text,
  `answer33` text,
  `answer34` text,
  `answer35` text,
  `answer36` text,
  `answer37` text,
  `answer38` text,
  `answer39` text,
  `answer40` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for fe_stores
-- ----------------------------
DROP TABLE IF EXISTS `fe_stores`;
CREATE TABLE `fe_stores` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `answer` text NOT NULL,
  `tags` varchar(255) NOT NULL,
  `kind` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for hrds
-- ----------------------------
DROP TABLE IF EXISTS `hrds`;
CREATE TABLE `hrds` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `departmentId` bigint(20) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `hrUserId` bigint(20) NOT NULL,
  `status` varchar(255) NOT NULL,
  `jobtypeId` bigint(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for interview_records
-- ----------------------------
DROP TABLE IF EXISTS `interview_records`;
CREATE TABLE `interview_records` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `interviewId` bigint(20) NOT NULL,
  `interviewer` varchar(255) NOT NULL,
  `paperId` varchar(255) NOT NULL,
  `record1` varchar(255) DEFAULT NULL,
  `record2` varchar(255) DEFAULT NULL,
  `record3` varchar(255) DEFAULT NULL,
  `record4` varchar(255) DEFAULT NULL,
  `record5` varchar(255) DEFAULT NULL,
  `record6` varchar(255) DEFAULT NULL,
  `record7` varchar(255) DEFAULT NULL,
  `record8` varchar(255) DEFAULT NULL,
  `record9` varchar(255) DEFAULT NULL,
  `record10` varchar(255) DEFAULT NULL,
  `record1Score` int(11) DEFAULT NULL,
  `record2Score` int(11) DEFAULT NULL,
  `record3Score` int(11) DEFAULT NULL,
  `record4Score` int(11) DEFAULT NULL,
  `record5Score` int(11) DEFAULT NULL,
  `record6Score` int(11) DEFAULT NULL,
  `record7Score` int(11) DEFAULT NULL,
  `record8Score` int(11) DEFAULT NULL,
  `record9Score` int(11) DEFAULT NULL,
  `record10Score` int(11) DEFAULT NULL,
  `advantage` text,
  `disadvantage` text,
  `result` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of interview_records
-- ----------------------------
BEGIN;
INSERT INTO `interview_records` VALUES (8, 57, 'rlweng', '57', '111', '57', '57', '候选人能给出一个NP hard 问题的解体思路。', NULL, NULL, NULL, NULL, NULL, NULL, 0, 3, 3, 4, 4, 3, NULL, NULL, NULL, NULL, '<p style=\"text-align: center;\"><span style=\"font-size: 12px;\">这里是优点<strong>这里是加强的优点。</strong><em>这里是斜体，</em></span><span style=\"font-size: 12px; text-decoration: underline;\">这里是下划线，</span><span style=\"font-size: 12px; text-decoration: none; font-family: 黑体, SimHei;\">这里是字体</span></p>', '<p>候选人的数学基础不错，思路也挺清晰。</p>', '算法这块和工程这块较弱。', 4, '2019-01-14 20:25:52', '2019-02-01 14:03:42');
INSERT INTO `interview_records` VALUES (9, 1, 'yyang', '1', '11', '1', '1', '1', '1', NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, '1', '1', '1', 5, '2019-01-15 17:15:23', '2019-01-15 17:15:23');
INSERT INTO `interview_records` VALUES (10, 2, 'yyang', '2', '11', '1', '1', '1', '1', NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, '1', '1', '1', 5, '2019-01-15 17:15:30', '2019-01-15 17:15:30');
INSERT INTO `interview_records` VALUES (11, 8, 'yyang', '8', '111', '57', '57', '候选人能给出一个NP hard 问题的解体思路。', NULL, NULL, NULL, NULL, NULL, NULL, 0, 3, 3, 4, 4, 3, NULL, NULL, NULL, NULL, '这里是优点', '候选人的数学基础不错，思路也挺清晰。', '算法这块和工程这块较弱。', 2, '2019-01-15 19:53:30', '2019-01-15 19:53:30');
COMMIT;

-- ----------------------------
-- Table structure for interviews
-- ----------------------------
DROP TABLE IF EXISTS `interviews`;
CREATE TABLE `interviews` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `resumeFile` varchar(255) DEFAULT NULL,
  `examTime` bigint(16) DEFAULT NULL,
  `exam` varchar(255) DEFAULT NULL,
  `examScore` varchar(255) DEFAULT NULL,
  `interviewTime1` bigint(16) DEFAULT NULL,
  `interviewer1` varchar(255) DEFAULT NULL,
  `interviewTime2` bigint(16) DEFAULT NULL,
  `interviewer2` varchar(255) DEFAULT NULL,
  `interviewTime3` bigint(16) DEFAULT NULL,
  `interviewer3` varchar(255) DEFAULT NULL,
  `interviewTime4` bigint(16) DEFAULT NULL,
  `interviewer4` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of interviews
-- ----------------------------
BEGIN;
INSERT INTO `interviews` VALUES (1, 'hr', 'hr', 'api/resumes/view?name=返标统计-Invalid date.xlsx_0.46094848368927854.xlsx', 1537318800000, 'https://exam.aibee.cn/paper.html?id=undefined', NULL, 1547537094795, 'yyang', 1547537094795, 'aibee_admin', 1547537094795, NULL, 1547537094795, NULL, '0', '2019-01-15 12:03:29', '2019-01-15 17:09:19');
INSERT INTO `interviews` VALUES (2, '杨', NULL, 'api/resumes/view?name=', 1537318800000, 'https://exam.aibee.cn/paper.html?id=undefined', NULL, 1553254476366, NULL, 1553254476366, NULL, 1553254476366, NULL, 1553254476366, NULL, '0', '2019-03-22 19:31:44', '2019-03-22 19:34:47');
COMMIT;

-- ----------------------------
-- Table structure for job_types
-- ----------------------------
DROP TABLE IF EXISTS `job_types`;
CREATE TABLE `job_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `jd` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for other_stores
-- ----------------------------
DROP TABLE IF EXISTS `other_stores`;
CREATE TABLE `other_stores` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `answer` text NOT NULL,
  `tags` varchar(255) NOT NULL,
  `kind` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for papers
-- ----------------------------
DROP TABLE IF EXISTS `papers`;
CREATE TABLE `papers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `contents` text NOT NULL,
  `answers` text NOT NULL,
  `scores` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `kind` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for positions
-- ----------------------------
DROP TABLE IF EXISTS `positions`;
CREATE TABLE `positions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `describe` varchar(255) DEFAULT NULL,
  `require` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `recruitType` varchar(255) DEFAULT NULL,
  `companyName` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `lowSalary` varchar(10) DEFAULT NULL,
  `highSalary` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of positions
-- ----------------------------
BEGIN;
INSERT INTO `positions` VALUES (1, '计算机视觉算法科学家/工程师', '技术/产品', '北京', '2018-12-21', '计算机视觉算法的研发，包括但不限于：人脸识别、大规模图片分类、物体检测、跟踪、图像/视频语义分割、视频语义理解、SLAM、3D视觉等； 计算机视觉前沿算法跟进与研发； 计算机视觉算法在实际应用领域的性能优化。', '熟练掌握C/C++、Python等编程语言； 熟悉OpenCV，以及图像处理基本方法； 熟悉深度学习基础知识和经典网络模型，熟练使用至少一种深度学习工具，如Caffe、Mxnet、TensorFlow、PyTorch、PaddlePaddle等； 具有较强算法实现能力，同方向项目经验，学术比赛经验以及发表过顶会论文者优先。', '2019-01-16 20:15:56', '2019-01-25 20:16:03', '社会招聘', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (6, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:13', '2019-02-01 10:36:13', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (7, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:15', '2019-02-01 10:36:15', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (8, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:17', '2019-02-01 10:36:17', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (9, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:19', '2019-02-01 10:36:19', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (10, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:21', '2019-02-01 10:36:21', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (11, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:23', '2019-02-01 10:36:23', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (12, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:25', '2019-02-01 10:36:25', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (13, '1', '', '', '2019-2-1', '', '', '2019-02-01 10:36:31', '2019-02-01 10:36:31', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (14, '2', '', '', '2019-2-1', '', '', '2019-02-01 10:36:37', '2019-02-01 10:36:37', '', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (15, '2', '市场/销售', '2', '2019-2-1', '2', '2', '2019-02-01 11:08:56', '2019-02-01 11:08:56', '2', NULL, NULL, NULL, NULL);
INSERT INTO `positions` VALUES (24, '1', '市场/销售', '', '2019-5-15', '2', '', '2019-05-15 13:37:41', '2019-05-15 13:37:41', '校园招聘', NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for resumes
-- ----------------------------
DROP TABLE IF EXISTS `resumes`;
CREATE TABLE `resumes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rid` bigint(20) NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `birth` varchar(255) DEFAULT NULL,
  `education` text,
  `intern` text,
  `projects` text,
  `honors` text,
  `skill` text,
  `location` varchar(255) DEFAULT NULL,
  `hireType` varchar(255) DEFAULT NULL,
  `jobId` int(11) DEFAULT NULL,
  `jobTitle` varchar(255) DEFAULT NULL,
  `college` varchar(255) DEFAULT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `addName` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `expecSalary` varchar(10) DEFAULT NULL,
  `salaried` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rid` (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of resumes
-- ----------------------------
BEGIN;
INSERT INTO `resumes` VALUES (1, 999999, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2019-01-10 20:11:02', '2019-01-10 20:11:02', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (7, 980000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2019-01-10 20:23:45', '2019-01-10 20:23:45', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (8, 9800001, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2019-01-10 20:32:00', '2019-01-10 20:32:00', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (12, 1547125485240, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '2', '2', '2', '男', '2019-01-19T16:00:00.000Z', NULL, '未知', '3', '3', '3', '未知', '校园招聘', 3, 'shanghai', '2', '未知', 0, '2019-01-10 21:04:45', '2019-01-10 21:04:45', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (13, 1547125528046, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '3', '3', '3', '女', '2018-12-31T16:00:00.000Z', NULL, '未知', '3', '3', '3', '未知', '校园招聘', 3, 'beijing', '3', '未知', 0, '2019-01-10 21:05:28', '2019-01-10 21:05:28', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (14, 1547125605296, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '4', '4', '4', '男', '2019-01-19T16:00:00.000Z', NULL, '未知', '4', '4', '4', '未知', '校园招聘', 3, 'shanghai', '4', '未知', 0, '2019-01-10 21:06:45', '2019-01-10 21:06:45', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (15, 1547125638070, '/api/resumes/view?name=', '5', '5', '5', NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, '5', '未知', 0, '2019-01-10 21:07:18', '2019-01-10 21:07:18', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (16, 1547125938126, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '6', '6', '6', '女', '2019-01-20T16:00:00.000Z', NULL, '未知', '6', '6', '6', '未知', '校园招聘', 3, 'shanghai', '6', '未知', 0, '2019-01-10 21:12:18', '2019-01-10 21:12:18', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (17, 1547126005730, 'api/resumes/view?name=返标统计-Invalid date.xlsx', '111', '111', NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:13:25', '2019-01-10 21:13:25', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (18, 1547126040411, 'api/resumes/view?name=echarts.js', '111111', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:14:00', '2019-01-10 21:14:00', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (19, 1547126853233, '/api/resumes/view?name=返标统计-Invalid date.xlsx', NULL, NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:27:33', '2019-01-10 21:27:33', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (20, 1547126993875, '/api/resumes/view?name=返标统计-Invalid date.xlsx', NULL, NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:29:53', '2019-01-10 21:29:53', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (21, 1547127062402, '/api/resumes/view?name=echarts.js', NULL, NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:31:02', '2019-01-10 21:31:02', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (22, 1547127905142, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '333', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:45:05', '2019-01-10 21:45:05', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (23, 1547127980965, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '444', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:46:20', '2019-01-10 21:46:20', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (24, 1547128161519, '/api/resumes/view?name=echarts.js', '555', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 21:49:21', '2019-01-10 21:49:21', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (25, 1547132658054, '/api/resumes/view?name=前段工具.png', '12345', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 23:04:18', '2019-01-10 23:04:18', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (26, 1547133101529, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '11:11', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 23:11:41', '2019-01-10 23:11:41', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (27, 1547133333686, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '11:15', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 23:15:33', '2019-01-10 23:15:33', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (28, 1547133847110, '/api/resumes/view?name=', '11:24', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 23:24:07', '2019-01-10 23:24:07', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (29, 1547134346770, '/api/resumes/view?name=返标统计-Invalid date.xlsx', '11:32', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 23:32:26', '2019-01-10 23:32:26', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (30, 1547134423916, '/api/resumes/view?name=undefined', '11:33', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-10 23:33:43', '2019-01-10 23:33:43', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (31, 1547170504518, '/api/resumes/view?name=undefined', '9:34', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-11 09:35:04', '2019-01-11 09:35:04', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (32, 1547170680810, '/api/resumes/view?name=undefined', '9:37', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-11 09:38:00', '2019-01-11 09:38:00', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (33, 1547173882813, '/api/resumes/view?name=', '10:31', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-11 10:31:22', '2019-01-11 10:31:22', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (34, 1547175914089, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-11 11:05:14', '2019-01-11 11:05:14', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (35, 1547186344350, '/api/resumes/view?name=', '1:58', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-11 13:59:04', '2019-01-11 13:59:04', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (36, 1547188066651, '/api/resumes/view?name=c29ead1d82ad261eebb84e397cbfe402', '2:27', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-11 14:27:46', '2019-01-11 14:27:46', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (37, 1547188168185, '/api/resumes/view?name=00e4a05b7985d4872a9472189958ed3d', '2:29', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, NULL, NULL, '未知', 0, '2019-01-11 14:29:28', '2019-01-11 14:29:28', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (38, 1547188574633, '/api/resumes/view?name=6b81ef50ee1f803631251a64131d7017', '2:36', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, '未知', NULL, 3, '语音识别与多轮交互算法工程师', NULL, '未知', 0, '2019-01-11 14:36:14', '2019-01-11 14:36:14', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (39, 1547189258867, '/api/resumes/view?name=aea63e3bf603c587754d3623ed8582e5', '2:47', '2:47', '2:47', '男', '2019-01-06T16:00:00.000Z', NULL, '未知', '2:47', '2:47', '2:47', '2:47', '社会招聘', 3, '后端开发工程师', '2:47', '2:47', 0, '2019-01-11 14:47:38', '2019-01-11 14:47:38', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (40, 1547189345846, '/api/resumes/view?name=329eddb0e4f2f5986a1b8388055e294c', '1', '1', '1', '女', '2019-01-19T16:00:00.000Z', NULL, '未知', '1', '1', '1', '1', '校园招聘', 3, '机器学习算法工程师 (用户画像方向)', '1', '1', 0, '2019-01-11 14:49:05', '2019-01-11 14:49:05', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (41, 1547189510110, '/api/resumes/view?name=', '2:51', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, 'degree', 0, '2019-01-11 14:51:50', '2019-01-11 14:51:50', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (42, 1547189582435, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '教育经历', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 14:53:02', '2019-01-11 14:53:02', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (43, 1547189594218, '/api/resumes/view?name=', '111', NULL, NULL, NULL, NULL, '教育经历', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 14:53:14', '2019-01-11 14:53:14', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (44, 1547189612934, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '111', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 14:53:32', '2019-01-11 14:53:32', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (45, 1547189680873, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '1', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 14:54:40', '2019-01-11 14:54:40', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (46, 1547189739542, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '123445', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 14:55:39', '2019-01-11 14:55:39', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (47, 1547189951426, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '12', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 14:59:11', '2019-01-11 14:59:11', '111', NULL, NULL);
INSERT INTO `resumes` VALUES (49, 1547190696555, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '[我不知道]', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 15:11:36', '2019-01-11 15:11:36', '111', NULL, NULL);
INSERT INTO `resumes` VALUES (50, 1547190804743, '/api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '5', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 15:13:24', '2019-01-11 15:13:24', '111', NULL, NULL);
INSERT INTO `resumes` VALUES (51, 1547191076088, '/api/resumes/view?name=3206480e18d64d2986cf15e24ea73ce3', '最新版', '最新版', '最新版', '男', '2019-01-20T16:00:00.000Z', '最新版', '未知', '最新版', '最新版', '最新版', '最新版', '校园招聘', 3, '前端开发工程师', '最新版', '最新版', 0, '2019-01-11 15:17:56', '2019-01-11 15:17:56', '111', NULL, NULL);
INSERT INTO `resumes` VALUES (52, 1547191802927, '/api/resumes/view?name=返标统计-Invalid date.xlsx_1547191793707_0.5777229317641637.xlsx', 'a', 'a', 'a', '男', '2019-01-10T16:00:00.000Z', 'a', '未知', 'a', 'a', 'a', 'a', '校园招聘', 3, '机器学习算法工程师 (推荐算法方向)', 'a', 'a', 0, '2019-01-11 15:30:02', '2019-01-11 15:30:02', '111', NULL, NULL);
INSERT INTO `resumes` VALUES (53, 1547192027578, '/api/resumes/view?name=', 'b', 'bb', 'b', '男', '2019-01-10T16:00:00.000Z', 'b', '未知', 'b', 'b', 'b', 'b', '校园招聘', 3, '机器学习算法工程师 (推荐算法方向)', 'b', 'b', 0, '2019-01-11 15:33:47', '2019-01-11 15:33:47', '11', NULL, NULL);
INSERT INTO `resumes` VALUES (54, 1547192359814, '/api/resumes/view?name=返标统计-Invalid date.xlsx_0.11896181560457908.xlsx', '1', NULL, NULL, NULL, NULL, '[[\"硕士\",\"2016-09-01\",\"2019-04-05\",\"哈尔滨理工大学\",\"机械电子工程\"],[\"本科\",\"2012-09-01\",\"2016-06-06\",\"佳木斯大学\",\"机械设计制造及其自动化\"]]', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 15:39:19', '2019-01-11 15:39:19', '1', NULL, NULL);
INSERT INTO `resumes` VALUES (55, 1547192684953, '/api/resumes/view?name=echarts.js_0.9718114353542668.js', NULL, NULL, NULL, NULL, NULL, '[[\"硕士\",\"2016-09-01\",\"2019-04-05\",\"哈尔滨理工大学\",\"机械电子工程\"],[\"本科\",\"2012-09-01\",\"2016-06-06\",\"佳木斯大学\",\"机械设计制造及其自动化\"]]', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-11 15:44:44', '2019-01-11 15:44:44', '1', NULL, NULL);
INSERT INTO `resumes` VALUES (56, 1547210683475, 'api/resumes/view?name=返标统计-Invalid date.xlsx_0.07983373741772226.xlsx', 'new', 'new', 'new', '男', '2018-12-30T16:00:00.000Z', 'new', '未知', 'new', 'new', 'new', 'new', '校园招聘', 3, '机器学习算法工程师 (用户画像方向)', 'new', 'new', 0, '2019-01-11 20:44:43', '2019-01-11 20:44:43', '111', NULL, NULL);
INSERT INTO `resumes` VALUES (57, 1547431286642, 'api/resumes/view?name=返标统计-Invalid date.xlsx_0.46094848368927854.xlsx', 'hr', 'hr', '915973260@qq.com', '男', '2019-01-26', '[[\"硕士\",\"2016-09-01\",\"2019-06-20\",\"华南师范大学\",\"光学\"],[\"本科\",\"2012-09-01\",\"2016-06-20\",\"湖北汽车工业学院\",\"光信息科学与工程\"]]', '[[\"2016-07-10\",\"2017-06-10\",\"北京久其软件股份有限公司\",\"Java研发工程师\",\"负责财政部的“基于HTTPS双向认证通信的Android客户端”预研。在实习期间很好的完成了工作，符合公司的要求，文档完整，实习结束对工作进行交接，获“优秀实习生”证书。\"]]', '[[\"2017-06-20\",\"2018-08-20\",\"基于***的内弹道接触阻抗研究\",\"利用stm32芯片设计基于DDS方法的同步正弦信号发生器；设计制作设计基于自由轴的相敏检波法的阻抗测试电路板；通过comsol和matlab联合编程进行电磁、力、热场耦合仿真，模拟接触阻抗动态变化。\\n\"],[\"2016-10-20\",\"2018-08-20\",\"数字经络云针灸机器人\",\"通过matlab对三轴六自由度机器人运动过程仿真分析并进行路径规划；结合matlab和opencv，开发双目视觉定位系统，结合小世界效应模型，实现经络数字化，穴位坐标化；\\n\"]]', '第六届山东省acm省赛 银牌\n“蓝桥杯” 全国软件与信息技术人才大赛国家级三等奖', 'hr', 'hr', '校园招聘', 3, '机器学习算法工程师 (推荐算法方向)', 'hr', 'hr', 4, '2019-01-14 10:01:26', '2019-01-25 10:37:08', '111', '15', '14*13');
INSERT INTO `resumes` VALUES (58, 1547431446254, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '[[\"硕士\",\"2016-09-01\",\"2019-04-05\",\"哈尔滨理工大学\",\"机械电子工程\"],[\"本科\",\"2012-09-01\",\"2016-06-06\",\"佳木斯大学\",\"机械设计制造及其自动化\"]]', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-14 10:04:06', '2019-01-14 10:04:06', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (59, 1547431624096, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '[[\"硕士\",\"2016-09-01\",\"2019-04-05\",\"哈尔滨理工大学\",\"机械电子工程\"],[\"本科\",\"2012-09-01\",\"2016-06-06\",\"佳木斯大学\",\"机械设计制造及其自动化\"]]', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-14 10:07:04', '2019-01-14 10:07:04', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (60, 1547432256982, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, '[[\"硕士\",\"2016-09-01\",\"2019-04-05\",\"哈尔滨理工大学\",\"机械电子工程\"],[\"本科\",\"2012-09-01\",\"2016-06-06\",\"佳木斯大学\",\"机械设计制造及其自动化\"]]', '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-14 10:17:36', '2019-01-14 10:17:36', 'aibee_admin', NULL, NULL);
INSERT INTO `resumes` VALUES (61, 1547455330005, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, '2018-12-31T16:00:00.000Z', NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-14 16:42:10', '2019-01-14 16:42:10', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (62, 1547455481090, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, '2019-01-26T16:00:00.000Z', NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-14 16:44:41', '2019-01-14 16:44:41', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (63, 1547455537589, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, '2019-01-02', NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-01-14 16:45:37', '2019-01-14 16:45:37', '111', NULL, NULL);
INSERT INTO `resumes` VALUES (65, 1548387446540, 'api/resumes/view?name=', '1', '1', '1', '男', '2019-01-27', NULL, '未知', NULL, NULL, NULL, '1', '校园招聘', 3, '机器学习算法工程师 (推荐算法方向)', '1', '1', 0, '2019-01-25 11:37:26', '2019-01-25 11:37:26', 'yyang', '12', '11*11');
INSERT INTO `resumes` VALUES (66, 1552999428558, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-03-19 20:43:48', '2019-03-19 20:43:48', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (67, 1552999978154, 'api/resumes/view?name=', NULL, NULL, NULL, '女', NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-03-19 20:52:58', '2019-03-19 20:52:58', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (68, 1553254283445, 'api/resumes/view?name=', '杨', NULL, '915973260@qq.com', NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-03-22 19:31:23', '2019-03-22 19:31:23', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (69, 1553502976311, 'api/resumes/view?name=', '111', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-03-25 16:36:16', '2019-03-25 16:36:16', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (70, 10087, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 16:39:15', '2019-03-25 16:39:15', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (73, 10001, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 16:47:54', '2019-03-25 16:47:54', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (77, 10002, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 16:53:10', '2019-03-25 16:53:10', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (78, 1553504291988, 'api/resumes/view?name=', NULL, NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, 0, '2019-03-25 16:58:11', '2019-03-25 16:58:11', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (80, 10003, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 17:18:46', '2019-03-25 17:18:46', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (82, 10004, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 17:23:42', '2019-03-25 17:23:42', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (83, 10005, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 17:26:12', '2019-03-25 17:26:12', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (84, 10006, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 17:26:46', '2019-03-25 17:26:46', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (86, 10007, NULL, 'test1', 'test1', 'test1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-03-25 17:33:19', '2019-03-25 17:33:19', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (87, 1554280675299, NULL, '11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2019-04-03 16:37:55', '2019-04-03 16:37:55', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (88, 1554281280059, NULL, 'test杨', NULL, '915973260@qq.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-04-03 16:48:00', '2019-04-03 16:48:00', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (89, 1554283313950, NULL, 'test杨', NULL, '915973260@qq.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-04-03 17:21:53', '2019-04-03 17:21:53', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (90, 1554283363900, NULL, 'test杨', NULL, '915973260@qq.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-04-03 17:22:43', '2019-04-03 17:22:43', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (91, 1554283391100, NULL, 'test杨', NULL, '915973260@qq.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '校园招聘', NULL, NULL, NULL, NULL, 0, '2019-04-03 17:23:11', '2019-04-03 17:23:11', 'moka', NULL, NULL);
INSERT INTO `resumes` VALUES (92, 1557900052797, 'api/resumes/view?name=', 'test1', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 3, '24', NULL, NULL, 0, '2019-05-15 14:00:52', '2019-05-15 14:00:52', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (93, 1557900412863, 'api/resumes/view?name=', 'test2', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 24, '1', NULL, NULL, 0, '2019-05-15 14:06:52', '2019-05-15 14:06:52', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (94, 1557900811727, 'api/resumes/view?name=', 'test3', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 24, '1', NULL, NULL, 0, '2019-05-15 14:13:31', '2019-05-15 14:13:31', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (95, 1558279104104, 'api/resumes/view?name=192.168.11.png_0.06746212955588127.png', 'test123', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 24, '1', NULL, NULL, 0, '2019-05-19 23:18:24', '2019-05-19 23:18:24', NULL, NULL, NULL);
INSERT INTO `resumes` VALUES (96, 1558280883337, 'api/resumes/view?name=name.png_0.3637008334744216.png', 'test1234', NULL, NULL, NULL, NULL, NULL, '未知', NULL, NULL, NULL, NULL, NULL, 15, '2', NULL, NULL, 0, '2019-05-19 23:48:03', '2019-05-19 23:48:03', NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for templates
-- ----------------------------
DROP TABLE IF EXISTS `templates`;
CREATE TABLE `templates` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of templates
-- ----------------------------
BEGIN;
INSERT INTO `templates` VALUES (1, 'Aibee 2018秋季校招笔试通知', '<div style=\"border: 1px #ddd solid; border-radius: 6px; padding:20px; width: 600px; margin: 30px auto; background-color: #f0f0f0; box-shadow: 0 0 10px #ccc; \">\n                <p style=\"font-size: 20px;\">{username}同学,您好!</p>\n                <p></p>\n                <p style=\"font-size: 16px; color: #888\">您已通过简历筛选，Aibee诚邀您参加在线笔试！</p>\n                <p style=\"font-size: 16px; color: #888\"><br></p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">笔试时间：2018-09-19 9:00-10:00</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">笔试答题地址：<a href=\"https://exam.aibee.cn/paper.html?id={uuid}\">https://exam.aibee.cn/paper.html?id={uuid}</a></p>\n                <p style=\"font-size: 16px; color: #888\"><br></p>\n                <p style=\"font-size: 16px; color: #888\">注意：</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">1.请在考试时间开始后再点击链接答题。若提前点击进入，请刷新页面。</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">2.请使用chrome浏览器。</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">3.考试中请打开摄像头，考试过程会进行全程录像</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">4.请不要跳出考试页面，否则会影响您的成绩</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">5.在线考试结束时，如果没有主动交卷，系统会自动交卷</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">6.在线考试过程中遇到问题请邮件联系<a href=\"mailto:hr@aibee.com\">hr@aibee.com</a></p>\n                <p style=\"font-size: 16px; color: #888; margin-top: 40px\">Aibee</p>\n              </div>', '2018-08-31 19:19:19', '2018-09-19 00:39:39');
INSERT INTO `templates` VALUES (2, '一面面试通知', '<div style=\"border: 1px solid rgb(221, 221, 221); border-radius: 6px; padding: 20px; width: 600px; margin: 30px auto; box-shadow: rgb(204, 204, 204) 0px 0px 10px; background-color: rgb(240, 240, 240);\">\n                <p style=\"font-size: 20px;\">{username}同学,你好!</p>\n                <p></p>\n                <p style=\"font-size: 16px; color: #888\">Aibee诚邀您参加我们的现场面试！</p>\n                <p style=\"font-size: 16px; color: #888\"><br></p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">面试时间：{time}</p>\n                <p style=\"font-size: 16px; color: #888\" \"=\"\">面试地址：亚朵酒店（博物馆店）- 哈尔滨市南岗区红军街4号</p><p style=\"font-size: 16px; color: #888\" \"=\"\">备注：<span lang=\"EN-US\" style=\"color: rgb(59, 62, 68); font-family: 微软雅黑, sans-serif;\">1. </span><span style=\"color: rgb(59, 62, 68); font-family: 微软雅黑, sans-serif;\">面试时请携带</span><span lang=\"EN-US\" style=\"color: rgb(59, 62, 68); font-family: 微软雅黑, sans-serif;\">3</span><span style=\"color: rgb(59, 62, 68); font-family: 微软雅黑, sans-serif;\">份简历。</span></p>\n\n<p class=\"MsoNormal\" align=\"left\" style=\"line-height: 17.85pt;\"><span lang=\"EN-US\" style=\"font-family:\n&quot;微软雅黑&quot;,sans-serif;color:#3B3E44\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2.\n</span><span style=\"font-family:&quot;微软雅黑&quot;,sans-serif;color:#3B3E44\">酒店大堂内会有同事领您前往面试地点。<span lang=\"EN-US\"><o:p></o:p></span></span></p>\n\n<p class=\"MsoNormal\" align=\"left\" style=\"text-indent: 31.5pt; line-height: 17.85pt;\"><span lang=\"EN-US\" style=\"font-family:&quot;微软雅黑&quot;,sans-serif;color:#3B3E44\">&nbsp;3. </span><span style=\"font-family:&quot;微软雅黑&quot;,sans-serif;color:#3B3E44\">收到面试邀请邮件后，请回复确认，谢谢。<span lang=\"EN-US\"><o:p></o:p></span></span></p>\n                <p style=\"font-size: 16px; color: #888\"><br></p>\n                <p style=\"font-size: 16px; color: #888; margin-top: 40px\">Aibee</p>\n              </div>', '2018-09-05 12:54:16', '2018-09-06 17:00:03');
INSERT INTO `templates` VALUES (5, 'Aibee校招宣讲会-华科站', '<p style=\"font-size: 20px;\">{username}同学,你好!</p><p></p><p style=\"font-size: 16px; color: rgb(136, 136, 136);\">Aibee诚邀您参加2019校招宣讲会-华中科技大学站！</p><p style=\"font-size: 16px; color: rgb(136, 136, 136);\"><br></p><p \"=\"\" style=\"font-size: 16px; color: rgb(136, 136, 136);\">宣讲时间：{time}</p><p \"=\"\" style=\"font-size: 16px; color: rgb(136, 136, 136);\">宣讲地点：华中科技大学&nbsp; 六号楼三楼多功能厅</p><p \"=\"\" style=\"font-size: 16px; color: rgb(136, 136, 136);\">宣讲流程：大牛分享-互动答疑-现场抽奖</p><p \"=\"\" style=\"\"><span style=\"color: rgb(136, 136, 136); font-size: 16px;\">备注：</span><font color=\"#3b3e44\" face=\"微软雅黑, sans-serif\">宣讲会现场接收简历，现场笔试，更有多台kindle抽奖放送！</font></p>', '2018-09-12 20:36:28', '2018-09-12 20:36:28');
COMMIT;

-- ----------------------------
-- Table structure for user_roles
-- ----------------------------
DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `departmentId` bigint(20) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `iden` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` VALUES (1, 'aibee_admin', 'mxrR9rq6C9exooOmMdv860TIIRMTqQIY', 'xlin@aibee.com', 'fe', 0, '2018-08-15 00:00:00', '2018-08-15 00:00:00', NULL);
INSERT INTO `users` VALUES (2, 'yyang', 'yyang', 'xlin@aibee.com', 'fe', 0, '2018-08-15 00:00:00', '2018-08-15 00:00:00', 'hr');
INSERT INTO `users` VALUES (3, 'lx', 'lx', 'lx@aibee.com', 'fe', NULL, '2019-01-23 13:25:38', '2019-01-23 13:25:42', 'hr');
INSERT INTO `users` VALUES (4, '111', '111', '111', '7', 0, '2019-01-25 12:07:06', '2019-01-25 12:07:06', NULL);
INSERT INTO `users` VALUES (5, '1', '1', '1', '7', 0, '2019-01-25 14:08:45', '2019-01-25 14:08:45', NULL);
INSERT INTO `users` VALUES (6, '1', '1', '1', '7', NULL, '2019-01-25 14:20:50', '2019-01-25 14:20:50', '');
INSERT INTO `users` VALUES (7, '1', '1', '1', '6', 3, '2019-01-25 14:22:39', '2019-01-25 14:22:39', '1');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
