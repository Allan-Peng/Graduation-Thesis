package com.daowen.service;

import org.springframework.stereotype.Service;

import com.daowen.mapper.FriendsMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;
@Service
public class FriendsService extends SimpleBizservice<FriendsMapper>{

	
}
