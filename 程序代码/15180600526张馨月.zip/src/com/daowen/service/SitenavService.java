package com.daowen.service;

import org.springframework.stereotype.Service;

import com.daowen.mapper.SitenavMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;

@Service
public class SitenavService extends SimpleBizservice<SitenavMapper> {

	
	
}
