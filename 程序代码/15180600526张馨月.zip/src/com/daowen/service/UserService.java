package com.daowen.service;

import org.springframework.stereotype.Service;

import com.daowen.mapper.UserMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;
@Service("userService")
public class UserService extends SimpleBizservice<UserMapper> {


	
}
