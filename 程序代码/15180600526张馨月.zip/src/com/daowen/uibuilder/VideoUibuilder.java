package com.daowen.uibuilder;

import java.text.MessageFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.daowen.entity.User;
import com.daowen.entity.Video;
import com.daowen.entity.Type;
import com.daowen.service.VideoService;
import com.daowen.service.TypeService;
import com.daowen.util.BeansUtil;

public class VideoUibuilder  {
	
	private HttpServletRequest request=null;
	private VideoService   videoSrv=null;
	private TypeService  typeSrv=null;
	
	public  VideoUibuilder(HttpServletRequest request){
		this.request=request;
		this.videoSrv=BeansUtil.getBean("videoService", VideoService.class);
		this.typeSrv= BeansUtil.getBean("typeService", TypeService.class);
	}
	
	public  String  buildVideo(int cateid)
	{
		String filter="";
		Type  temType=null;
		if(cateid>0){
			filter="where typeid="+cateid;
			temType=typeSrv.load("where id="+cateid);
		}
		List<Video> list=videoSrv.getEntity(filter);
		return buildVideo(list,temType==null?"视频信息":temType.getName());
		
	}
	public  String  buildTopVideo(int count,String lanmuName)
	{
		List<Video> listyp=videoSrv.getTopEntity("order by id desc", count);
		return buildVideo(listyp, lanmuName);
	}
	
	public String  buildVideo(List<Video> list, String lanmuName){
		if(list==null)
			return "";
		StringBuilder sb=new StringBuilder();
		sb.append(" <div class=\"video-cover-fluid\">");
		sb.append("<div class=\"title\">");
		sb.append(MessageFormat.format("<span>{0}</span>",lanmuName));
		sb.append("</div>");
		sb.append("<ul>");
		for(Video video : list){
			sb.append("<li>");
			sb.append(MessageFormat.format("<a href=\"{0}\\e\\videoinfo.jsp?id={1}\">",request.getContextPath(), video.getId()));
			sb.append(MessageFormat.format("<img src=\"{0}\" width=\"158\" height=\"108\" />", video.getTupian()));
			sb.append(MessageFormat.format("<span>{0}</span>", video.getTitle()));
			sb.append("</a>");
			sb.append("</li>");
		}
		sb.append("</ul>");
		sb.append("</div>");
		return sb.toString();
	}
	
	public VideoUibuilder view(HttpServletResponse response,String id){
		User user=(User)request.getSession().getAttribute("user");
		if(user==null)
			return this;
 		String username=user==null?"":user.getAccountname();
 		//获取历史浏览
 		new ViewHistory("video_browser_"+username).view(request,response,id);
 		return this;
	}

    public String  buildViewedProduct(){
	 		
    	    
	 		StringBuilder sb=new StringBuilder();
	 		User user=(User)request.getSession().getAttribute("user");
	 		if(user==null)
	 			return "";
	 		String username=user==null?"":user.getAccountname();
	 		
	 		//获取历史浏览
	 		List<String> ids=new ViewHistory("video_browser_"+username).HistoryView(request);
	 		String temids="";
	 		int i=0;
	 		for(String id : ids){
	 			temids+=id;
	 			if(i<ids.size()-1){
	 				temids+=",";
	 			}
	 			i++;
	 		
	 		}
	 		if(ids!=null&&ids.size()>0){
	 		  List<Video> shangpinlist=videoSrv.getEntity(" where id in ("+temids+")");
	 		//得到最新商品信息 
	 		  sb.append(buildVideo(shangpinlist, "猜你感兴趣视频"));
	 		}
	     	return sb.toString();
	 	} 
	
	
	
}
