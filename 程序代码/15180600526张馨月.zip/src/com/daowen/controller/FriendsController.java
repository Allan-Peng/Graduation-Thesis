package com.daowen.controller;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.daowen.entity.Friends;
import com.daowen.service.FriendsService;
import com.daowen.ssm.simplecrud.SimpleController;
import com.daowen.webcontrol.PagerMetal;
@Controller
public class FriendsController extends SimpleController {

	@Override
	@RequestMapping("/admin/friendsmanager.do")
	public void mapping(HttpServletRequest request, HttpServletResponse response) {
		
		mappingMethod(request,response);

	}
	/********************************************************
	 ****************** 信息注销监听支持*****************************
	 *********************************************************/
	public void delete() {
		String forwardurl = request.getParameter("forwardurl");
		String[] ids = request.getParameterValues("ids");
		String id = request.getParameter("id");
		if (id != null) {
			friendsSrv.delete("where id = " + id);
		}
		if (ids != null) {
			String spliter = ",";
			String SQL = " where id in(" + join(spliter, ids) + ")";
			System.out.println("sql=" + SQL);
			friendsSrv.delete(SQL);
		}
	}

	/*************************************************************
	 **************** 保存动作监听支持******************************
	 **************************************************************/
	public void save() {
		String forwardurl = request.getParameter("forwardurl");
		// 验证错误url
		String errorurl = request.getParameter("errorurl");
		String hyaccount = request.getParameter("hyaccount");
		String gzaccount = request.getParameter("gzaccount");
		SimpleDateFormat sdffriends = new SimpleDateFormat("yyyy-MM-dd");
		Friends friends = new Friends();
		friends.setHyaccount(hyaccount == null ? "" : hyaccount);
		friends.setGzaccount(gzaccount == null ? "" : gzaccount);
		// 产生验证
		Boolean validateresult = saveValidate(MessageFormat.format("where hyaccount=''{0}'' and  gzaccount=''{1}'' " ,hyaccount,gzaccount));
				
		if (validateresult) {
			try {
				request.setAttribute("errormsg",
						"<label class='error'>已关注了该微博</label>");
				request.setAttribute("friends", friends);
				request.setAttribute("actiontype", "save");
				request.getRequestDispatcher(errorurl).forward(request,
						response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return;
		}
		friendsSrv.save(friends);
		if (forwardurl == null) {
			forwardurl = "/admin/friendsmanager.do?actiontype=get";
		}
		redirect(forwardurl);
	}

	// 新增验证
	private boolean saveValidate(String filter) {
		return friendsSrv.isExist(filter);
	}

	
	/******************************************************
	 *********************** 更新内部支持*********************
	 *******************************************************/
	public void update() {
		String forwardurl = request.getParameter("forwardurl");
		String id = request.getParameter("id");
		if (id == null)
			return;
		Friends friends = (Friends) friendsSrv.load(new Integer(id));
		if (friends == null)
			return;
		String hyaccount = request.getParameter("hyaccount");
		String gzaccount = request.getParameter("gzaccount");
		SimpleDateFormat sdffriends = new SimpleDateFormat("yyyy-MM-dd");
		friends.setHyaccount(hyaccount);
		friends.setGzaccount(gzaccount);
		friendsSrv.update(friends);
		if (forwardurl == null) {
			forwardurl = "/admin/friendsmanager.do?actiontype=get";
		}
		redirect(forwardurl);
	}

	/******************************************************
	 *********************** 加载内部支持*********************
	 *******************************************************/
	public void load() {
		//
		String id = request.getParameter("id");
		String actiontype = "save";
		dispatchParams(request, response);
		if (id != null) {
			Friends friends = friendsSrv.load( "where id="+ id);
			if (friends != null) {
				request.setAttribute("friends", friends);
			}
			actiontype = "update";
			request.setAttribute("id", id);
		}
		request.setAttribute("actiontype", actiontype);
		String forwardurl = request.getParameter("forwardurl");
		System.out.println("forwardurl=" + forwardurl);
		if (forwardurl == null) {
			forwardurl = "/admin/friendsadd.jsp";
		}
		forward(forwardurl);
	}

	/******************************************************
	 *********************** 数据绑定内部支持*********************
	 *******************************************************/
	public void binding() {
		String filter = "where 1=1 ";
		String hyaccount = request.getParameter("hyaccount");
		if (hyaccount != null)
			filter += "  and hyaccount like '%" + hyaccount + "%'  ";
		//
		int pageindex = 1;
		int pagesize = 10;
		// 获取当前分页
		String currentpageindex = request.getParameter("currentpageindex");
		// 当前页面尺寸
		String currentpagesize = request.getParameter("pagesize");
		// 设置当前页
		if (currentpageindex != null)
			pageindex = new Integer(currentpageindex);
		// 设置当前页尺寸
		if (currentpagesize != null)
			pagesize = new Integer(currentpagesize);
		List<Friends> listfriends = friendsSrv.getPageEntitys(filter,
				pageindex, pagesize);
		int recordscount = friendsSrv.getRecordCount(
				filter == null ? "" : filter);
		request.setAttribute("listfriends", listfriends);
		PagerMetal pm = new PagerMetal(recordscount);
		// 设置尺寸
		pm.setPagesize(pagesize);
		// 设置当前显示页
		pm.setCurpageindex(pageindex);
		// 设置分页信息
		request.setAttribute("pagermetal", pm);
		// 分发请求参数
		dispatchParams(request, response);
		String forwardurl = request.getParameter("forwardurl");
		System.out.println("forwardurl=" + forwardurl);
		if (forwardurl == null) {
			forwardurl = "/admin/friendsmanager.jsp";
		}
		forward(forwardurl);
	}
	@Autowired
	private FriendsService friendsSrv=null;

}
