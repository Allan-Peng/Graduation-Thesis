package com.daowen.controller;

import java.io.IOException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.daowen.entity.Video;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.daowen.entity.Attachement;
import com.daowen.service.AttachementService;
import com.daowen.service.VideoService;
import com.daowen.service.TypeService;
import com.daowen.ssm.simplecrud.SimpleController;
import com.daowen.webcontrol.PagerMetal;

/**************************
 *
 * 视频控制
 *
 */
@Controller
public class VideoController extends SimpleController {
    @Autowired
    private VideoService videoSrv = null;
    @Autowired
    private TypeService typeSrv = null;
    @Autowired
    private AttachementService attachementSrv = null;

    @Override
    @RequestMapping("/admin/videomanager.do")
    public void mapping(HttpServletRequest request, HttpServletResponse response) {
        mappingMethod(request, response);
    }

    private void jump() {
        String forwardurl = request.getParameter("forwardurl");
        if (forwardurl == null) {
            forwardurl = "/admin/videomanager.do?actiontype=get";
        }
        redirect(forwardurl);
    }

    private void agree() {
        String id = request.getParameter("id");
        if (id == null) {
            return;
        }
        Video video = videoSrv.load(new Integer(id));
        if (video == null) {
            return;
        }
        video.setAgreecount(video.getAgreecount() + 1);
        videoSrv.update(video);
        response.setContentType("application/x-www-form-urlencoded; charset=UTF-8");
        try {
            response.getWriter().write(
                    new Integer(video.getAgreecount()).toString());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    private void against() {
        String id = request.getParameter("id");
        if (id == null) {
            return;
        }
        Video video = videoSrv.load(new Integer(id));
        if (video == null) {
            return;
        }
        video.setAgainstcount(video.getAgainstcount() + 1);
        videoSrv.update(video);
        response.setContentType("application/x-www-form-urlencoded; charset=UTF-8");
        try {
            response.getWriter().write(
                    new Integer(video.getAgainstcount()).toString());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /********************************************************
     ****************** 信息注销监听支持*****************************
     *********************************************************/
    public void delete() {
        String forwardurl = request.getParameter("forwardurl");
        String[] ids = request.getParameterValues("ids");
        String id = request.getParameter("id");
        if (id != null) {
            videoSrv.delete("where id = " + id);
        }
        if (ids != null) {
            String spliter = ",";
            String SQL = " where id in(" + join(spliter, ids) + ")";
            System.out.println("sql=" + SQL);
            videoSrv.delete(SQL);
        }
        if (forwardurl == null) {
            forwardurl = "/admin/videomanager.do?actiontype=get";
        }
        redirect(forwardurl);
    }

    /*************************************************************
     **************** 保存动作监听支持******************************
     **************************************************************/
    public void save() {
        String forwardurl = request.getParameter("forwardurl");
        String title = request.getParameter("title");
        String typename = request.getParameter("typename");
        String pubren = request.getParameter("pubren");
        String pubtime = request.getParameter("pubtime");
        String clickcount = request.getParameter("clickcount");
        String alphabetindex = request.getParameter("alphabetindex");
        String des = request.getParameter("des");
        String xshowtype = request.getParameter("xshowtype");
        String remoteurl = request.getParameter("remoteurl");
        String tupian = request.getParameter("tupian");
        String typeid = request.getParameter("typeid");
        String subtitle = request.getParameter("subtitle");
        String dqid = request.getParameter("dqid");
        String dqname = request.getParameter("dqname");
        String ndid = request.getParameter("ndid");
        String ndname = request.getParameter("ndname");
        String tags = request.getParameter("tags");
        SimpleDateFormat sdfvideo = new SimpleDateFormat("yyyy-MM-dd");
        Video video = new Video();

        video.setTitle(title == null ? "" : title);
        video.setTypename(typename == null ? "" : typename);
        video.setPubren(pubren == null ? "" : pubren);
        if (pubtime != null) {
            try {
                video.setPubtime(sdfvideo.parse(pubtime));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        } else {
            video.setPubtime(new Date());
        }
        video.setAgainstcount(0);
        video.setAgreecount(0);
        video.setClickcount(clickcount == null ? 0 : new Integer(clickcount));
        video.setDes(des == null ? "" : des);
        video.setXshowtype(xshowtype == null ? 0 : new Integer(xshowtype));
        video.setRemoteurl(remoteurl == null ? "" : remoteurl);
        video.setTupian(tupian == null ? "" : tupian);
        video.setTypeid(typeid == null ? 0 : new Integer(typeid));
        video.setSubtitle(subtitle == null ? "" : subtitle);
        video.setAlphabetindex(alphabetindex == null ? "" : alphabetindex);
        video.setDqid(dqid == null ? 0 : new Integer(dqid));
        video.setDqname(dqname == null ? "" : dqname);
        video.setNdid(ndid == null ? 0 : new Integer(ndid));
        video.setNdname(ndname == null ? "" : ndname);
        video.setTags(tags == null ? "" : tags);
        videoSrv.save(video);
        attachements(new Integer(video.getId()).toString());
        if (forwardurl == null) {
            forwardurl = "/admin/videomanager.do?actiontype=get";
        }
        redirect(forwardurl);
    }

    /******************************************************
     *********************** 内部附件支持*********************
     *******************************************************/
    public void attachements(String belongid) {
        attachementSrv.delete(MessageFormat.format(" where belongid=''{0}'' and belongtable=''video'' ",
                belongid));
        String[] photos = request.getParameterValues("fileuploaded");
        if (photos == null) {
            return;
        }
        for (int i = 0; i < photos.length; i++) {
            Attachement a = new Attachement();
            a.setType("images");
            a.setPubtime(new Date());
            a.setBelongfileldname("id");
            a.setFilename(photos[i]);
            a.setBelongid(belongid);
            a.setBelongtable("video");
            a.setUrl(request.getContextPath() + "/upload/temp/"
                    + a.getFilename());
            a.setTitle(a.getFilename());
            attachementSrv.save(a);
        }
    }


    /******************************************************
     *********************** 更新内部支持*********************
     *******************************************************/
    public void update() {
        String forwardurl = request.getParameter("forwardurl");
        String id = request.getParameter("id");
        if (id == null) {
            return;
        }
        Video video = videoSrv.load(new Integer(id));
        if (video == null) {
            return;
        }
        String xshowtype = request.getParameter("xshowtype");
        String remoteurl = request.getParameter("remoteurl");
        String title = request.getParameter("title");
        String typename = request.getParameter("typename");
        String typeid = request.getParameter("typeid");
        String pubren = request.getParameter("pubren");
        String alphabetindex = request.getParameter("alphabetindex");
        String pubtime = request.getParameter("pubtime");
        String clickcount = request.getParameter("clickcount");
        String des = request.getParameter("des");
        String tupian = request.getParameter("tupian");
        String subtitle = request.getParameter("subtitle");
        String dqid = request.getParameter("dqid");
        String dqname = request.getParameter("dqname");
        String ndid = request.getParameter("ndid");
        String ndname = request.getParameter("ndname");
        String tags = request.getParameter("tags");
        SimpleDateFormat sdfvideo = new SimpleDateFormat("yyyy-MM-dd");
        video.setTitle(title);
        video.setXshowtype(xshowtype == null ? 0 : new Integer(xshowtype));
        video.setRemoteurl(remoteurl == null ? "" : remoteurl);
        video.setTypename(typename);
        video.setAlphabetindex(alphabetindex == null ? "" : alphabetindex);
        video.setTypeid(typeid == null ? 0 : new Integer(typeid));
        video.setSubtitle(subtitle == null ? "" : subtitle);
        video.setDqid(dqid == null ? 0 : new Integer(dqid));
        video.setDqname(dqname == null ? "" : dqname);
        video.setNdid(ndid == null ? 0 : new Integer(ndid));
        video.setNdname(ndname == null ? "" : ndname);
        if (pubtime != null) {
            try {
                video.setPubtime(sdfvideo.parse(pubtime));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        video.setClickcount(clickcount == null ? 0 : new Integer(clickcount));
        video.setDes(des);
        video.setTupian(tupian);
        video.setTags(tags == null ? "" : tags);
        videoSrv.update(video);
        attachements(new Integer(video.getId()).toString());
        if (forwardurl == null) {
            forwardurl = "/admin/videomanager.do?actiontype=get";
        }
        redirect(forwardurl);
    }

    /******************************************************
     *********************** 加载内部支持*********************
     *******************************************************/
    public void load() {
        //
        String id = request.getParameter("id");
        String actiontype = "save";
        dispatchParams(request, response);
        if (id != null) {
            Video video = videoSrv.load("where id=" + id);
            if (video != null) {
                request.setAttribute("video", video);
            }
            actiontype = "update";
            request.setAttribute("id", id);
        }
        request.setAttribute("actiontype", actiontype);
        List<Object> typeid_datasource = typeSrv.getEntity("");
        request.setAttribute("typeid_datasource", typeid_datasource);
        String forwardurl = request.getParameter("forwardurl");
        System.out.println("forwardurl=" + forwardurl);
        if (forwardurl == null) {
            forwardurl = "/admin/videoadd.jsp";
        }
        forward(forwardurl);
    }

    /******************************************************
     *********************** 数据绑定内部支持*********************
     *******************************************************/
    public void get() {
        String filter = "where 1=1 ";
        String pubren = request.getParameter("pubren");
        String title = request.getParameter("title");
        if (title != null)
            filter += "  and title like '%" + title + "%'  ";
        //
        if (pubren != null)
            filter += " and pubren='" + pubren + "'";
        //
        int pageindex = 1;
        int pagesize = 10;
        // 获取当前分页
        String currentpageindex = request.getParameter("currentpageindex");
        // 当前页面尺寸
        String currentpagesize = request.getParameter("pagesize");
        // 设置当前页
        if (currentpageindex != null)
            pageindex = new Integer(currentpageindex);
        // 设置当前页尺寸
        if (currentpagesize != null)
            pagesize = new Integer(currentpagesize);
        List<Video> videoList = videoSrv.getPageEntitys(filter,
                pageindex, pagesize);
        int recordscount = videoSrv.getRecordCount(filter == null ? ""
                : filter);
        request.setAttribute("videoList", videoList);
        PagerMetal pm = new PagerMetal(recordscount);
        // 设置尺寸
        pm.setPagesize(pagesize);
        // 设置当前显示页
        pm.setCurpageindex(pageindex);
        // 设置分页信息
        request.setAttribute("pagermetal", pm);
        // 分发请求参数
        dispatchParams(request, response);
        String forwardurl = request.getParameter("forwardurl");
        System.out.println("forwardurl=" + forwardurl);
        if (forwardurl == null) {
            forwardurl = "/admin/videomanager.jsp";
        }
        forward(forwardurl);
    }
}
