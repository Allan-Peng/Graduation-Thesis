package com.daowen.mapper;
import com.daowen.entity.Type;
import com.daowen.ssm.simplecrud.SimpleMapper;
public interface TypeMapper extends SimpleMapper<Type> {
}
