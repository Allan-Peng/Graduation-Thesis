package com.daowen.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.daowen.entity.Sitenav;
import com.daowen.ssm.simplecrud.SimpleMapper;
@Mapper
public interface SitenavMapper extends SimpleMapper<Sitenav>{

	
}
