package com.daowen.mapper;

import java.util.List;

import com.daowen.entity.Sysconfig;
import com.daowen.ssm.simplecrud.SimpleMapper;

public interface SysconfigMapper extends SimpleMapper<Sysconfig> {

	

}
