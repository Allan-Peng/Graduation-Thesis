package com.daowen.mapper;
import com.daowen.entity.Video;
import com.daowen.ssm.simplecrud.SimpleMapper;
public interface VideoMapper extends SimpleMapper<Video> {
}
