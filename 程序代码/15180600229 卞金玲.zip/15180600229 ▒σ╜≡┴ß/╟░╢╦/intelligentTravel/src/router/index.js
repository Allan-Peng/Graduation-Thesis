import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/index'
import Mine from '@/components/mine/mine'
import MyCollect from '@/components/mine/myCollect'
import UserInfo from '@/components/mine/userInfo'
import ShareNote from '@/components/mine/shareNote'
import Home from '@/components/home/home'
import ChooseDestination from '@/components/home/chooseDestination'
import ChooseDeparture from '@/components/home/chooseDeparture'
import ChooseTime from '@/components/home/chooseTime'
import RecommendInfo from '@/components/home/recommendInfo'
import Search from '@/components/search/search'
import NoteDetail from '@/components/search/noteDetail'
import AttractionList from '@/components/search/attractionList'
import Recommend from '@/components/recommend/recommend'
import Demo from '@/components/recommend/demo'
import RecomDetail from '@/components/recommend/recomDetail'
import AttrMap from '@/components/recommend/attrMap'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: Index
    },
    {
      path: '/mine',
      name: 'mine',
      component: Mine
    },
    {
      path: '/myCollect',
      name: 'myCollect',
      component: MyCollect
    },
    {
      path: '/shareNote',
      name: 'shareNote',
      component: ShareNote
    },
    {
      path: '/userInfo',
      name: 'userInfo',
      component: UserInfo
    },
    {
      path: '/search',
      name: 'search',
      component: Search
    },
    {
      path: '/attractionList',
      name: 'attractionList',
      component: AttractionList
    },
    {
      path: '/home',
      name: 'home',
      component: Home
    },
    {
      path: '/chooseTime',
      name: 'chooseTime',
      component: ChooseTime
    },
    {
      path: '/chooseDestination',
      name: 'chooseDestination',
      component: ChooseDestination
    },
    {
      path: '/chooseDeparture',
      name: 'chooseDeparture',
      component: ChooseDeparture
    },
    {
      path: '/recommendInfo',
      name: 'recommendInfo',
      component: RecommendInfo
    },
    {
      path: '/recommend/recomDetail',
      name: 'recomDetail',
      component: RecomDetail
    },
    {
      path: '/recommend/attrMap',
      name: 'attrMap',
      component: AttrMap
    },
    {
      path: '/recommend/',
      name: 'recommend',
      component: Recommend
    },
    {
      path: '/noteDetail',
      name: 'noteDetail',
      component: NoteDetail
    },
    {
      path: '/demo',
      name: 'demo',
      component: Demo
    }
  ]
})
