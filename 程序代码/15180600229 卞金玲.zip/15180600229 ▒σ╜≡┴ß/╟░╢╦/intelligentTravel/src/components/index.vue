<template>
  <div>
    <div class="header-div"><button class="header-btn" @click="jumpToHome">随便逛逛</button></div>
    <div class="login-div">登录</div>
    <div>
      <el-input class="login-user-name" v-model="userName" placeholder="请输入用户名"></el-input>
      <el-input type="password" class="login-user-pass" v-model="password" placeholder="登录密码"></el-input>
      <div class="login-btn-div">
        <el-button type="primary" round @click="login">登录</el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      userName: '',
      password: '',
      loginMsg: ''
    }
  },
  methods: {
    login: function () {
      var that = this

      if (that.userName == null || that.userName === '' || that.password == null || that.password === '') {
        that.$message({
          message: '请输入用户名和密码',
          type: 'warning'
        })
      } else {
        that.$ajax.get(// 调用接口
          '/user/login?login=' + that.userName // this指data
        ).then(function (response) { // 接口返回数据
          that.loginMsg = response.data
          if (response.data == null || response.data === '') {
            that.$message.error('用户名不存在')
          } else if (response.data.cPassword !== that.password) {
            that.$message.error('您的密码输入错误，请重新输入')
          } else {
            sessionStorage.setItem('userName',that.userName)
            sessionStorage.setItem('userId',response.data.nId)
            sessionStorage.setItem('usercName',response.data.cName)
            that.$router.push(
              {
                path: '/home',
                name: 'home'
              })
          }
        })
      }
    },
    jumpToHome: function () {
      this.$router.push({
        name: 'home'
      })
    }
  }
}
</script>

<style scoped>
.header-btn{
  border: none;
  background-color: #ffffff;
  right: 20px;
  position: absolute;
  border-bottom: 1px solid #e1e1e1;
}
.login-div{
  height: 110px;
  text-align: center;
  padding-top: 60px;
  font-size: 30px;
}
.login-user-name{
  margin: 0px 5% 15px 5%;
  width: 90% !important;
}

.login-user-pass{
  margin: 0px 5%;
  width: 90% !important;
}

.login-user-name .el-input__inner{
  border: none;
  border-bottom: 1px solid #dcdfe6;
}

.login-user-pass .el-input__inner{
  border: none;
  border-bottom: 1px solid #dcdfe6;
}

.login-btn-div{
  text-align: center;
  margin-top: 25px;
}

.login-btn-div .el-button{
  width: 80%;
  border-radius: 5px;
}
</style>
