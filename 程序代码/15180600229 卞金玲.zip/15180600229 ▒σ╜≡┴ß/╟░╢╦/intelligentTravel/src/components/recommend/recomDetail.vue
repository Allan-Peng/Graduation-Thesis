<template>
  <div>
    <Header title="景点详情"></Header>
    <div style="margin-top:55px">
      <img class="img" :src="attraction.cImg">
    </div>
    <div class="detail-div">
      <div>
        <span class="name">{{attraction.cName}}</span>
        <div v-show="isCollected===true" class='is_collected' @click="doCollect"></div>
        <div v-show="isCollected===false" class='is_not_collected' @click="doCollect"></div>
        <span class="rating-all">
          <span class="rating">{{attraction.nRating}}</span>
        </span>
      </div>
      <div class="discription-div">
        <span class="discription">{{attraction.cDiscription}}</span>
      </div>
      <div class="big-title">
        <span>景点指南</span>
      </div>
      <div id="attrMap" class="map"></div>
      <div class="title">
        <div class="title-before"></div>
        <span class="title-content">景点介绍</span>
      </div>
      <div>
        <span>{{attraction.cDiscription}}</span>
        <span v-show="!attraction.cDiscription">暂无</span>
      </div>
      <div class="title">
        <div class="title-before"></div>
        <span class="title-content">建议游玩时长</span>
      </div>
      <div>
        <span>{{attraction.cPlayTime}}</span>
        <span v-show="!attraction.cPlayTime">暂无</span>
      </div>
      <div class="title">
        <div class="title-before"></div>
        <span class="title-content">门票价格</span>
      </div>
      <div>
        <span>{{attraction.dPrice}}</span>
        <span v-show="!attraction.dPrice">暂无</span>
      </div>
      <div class="title">
        <div class="title-before"></div>
        <span class="title-content">交通攻略</span>
      </div>
      <div>
        <span>{{attraction.cTravel}}</span>
        <span v-show="!attraction.cTravel">暂无</span>
      </div>
      <div class="title">
        <div class="title-before"></div>
        <span class="title-content">开放时间</span>
      </div>
      <div>
        <span>{{attraction.cOpenTime}}</span>
        <span v-show="!attraction.cOpenTime">暂无</span>
      </div>
      <div class="title">
        <div class="title-before"></div>
        <span class="title-content">景区联系方式</span>
      </div>
      <div>
        <span>{{attraction.cTel}}</span>
        <span v-show="!attraction.cTel">暂无</span>
      </div>
    </div>
    <div class="all-comment">
      <div>网友点评</div>
      <div
        v-for="comment in commentList"
        :key="comment.id"
        class="note-detail-comment-div"
        v-show="!commentIsNull"
      >
        <img :src="comment.img" class="note-detail-comment-img">
        <div class="note-detail-comment-name-div">
          <span class="note-detail-comment-name">{{comment.userName}}</span>
          <span class="note-detail-comment-time">{{comment.createTime}}</span>
        </div>
        <span
          class="note-detail-comment-del"
          v-if="comment.isDel"
          @click="delComment(comment.id)"
        >删除</span>
        <span class="note-detail-comment-cont">{{comment.content}}</span>
      </div>
      <div v-show="commentIsNull">暂无评论</div>
      <div class="comment-div">
        <textarea class="comment-text" placeholder="千头万绪，汇成一句话" v-model="addComment.content"></textarea>
        <button class="comment-sub" @click="addCommentFunc">评论</button>
      </div>
    </div>
  </div>
</template>
<script>
import Header from '../header.vue'
export default {
  components:{Header},
  data () {
    return {
      isCollected:false,
      attraction: [],
      attrId: this.$route.query.attrId,
      addComment: {
        attrId: this.$route.query.attrId,
        userId: sessionStorage.getItem('userId'),
        content: '',
        type: 1 // 景点
      }, // 添加评论
      commentList: '', // 评论列表
      commentIsNull: false
    }
  },
  mounted () {
    this.load()
  },
  methods: {
    load () {
      var that = this
      this.attrId = this.$route.query.attrId
      this.addComment.content = ''
      this.addComment.attrId = this.$route.query.attrId
      this.addComment.userId = sessionStorage.getItem('userId')
      that.$ajax
        .get(
          // 调用接口
          '/attraction/getAttractionById?nId=' + that.attrId+'&userId=' + that.addComment.userId // this指data
        )
        .then(function (response) {
          // 接口返回数据
          that.attraction = response.data
          if(response.data.collectId!=0) {
            that.isCollected = true
          }
          if(that.attraction.cDiscription===null){
          that.attraction.cDiscription = '强烈推荐'
          }

          // 创建地图实例
          var map = new BMap.Map('attrMap')
          // 初始化地图，设置中心点坐标和地图级别
          map.centerAndZoom(that.attraction.cName, 12)
          // 添加地图类型控件
          map.addControl(new BMap.MapTypeControl({
            mapTypes: [
              BMAP_NORMAL_MAP,
              BMAP_HYBRID_MAP
            ]}))
          // 添加鼠标滚轮缩放
          map.enableScrollWheelZoom(true)
        })

      that.$ajax
        .get(
          // 调用接口
          '/comment/getComments?commentId=' + that.attrId + '&type=1'
        )
        .then(function (response) {
          that.commentList = response.data
          if (that.commentList == null || that.commentList.length === 0) {
            that.commentIsNull = true
          } else {
            for (var i = 0; i < that.commentList.length; i++) {
              that.commentList[i].isDel = false
              that.commentList[i].createTime = that.$moment(that.commentList[i].createTime).format('YYYY-MM-DD HH:mm:ss')
              if (that.commentList[i].userId.toString() === that.addComment.userId) {
                that.commentList[i].isDel = true
              }
            }
          }
        })
    },
    addCommentFunc () {
      var that = this
      if (that.addComment.userId === '') {
        that.$message({
          message: '请先登录',
          type: 'warning'
        })
      } else {
        if (this.addComment.content.trim() === '') {
          that.$message({
            message: '请填写评论内容',
            type: 'warning'
          })
        } else {
          that.$ajax
            .post(
              // 调用接口
              '/comment/addComment',
              { comment: that.addComment }
            )
            .then(function (response) {
              that.load()
              that.commentIsNull = false
            })
        }
      }
    },
    delComment (id) {
      var that = this
      this.$ajax
        .get(
          // 调用接口
          '/comment/delComment?commentId=' + id
        )
        .then(function (response) {
          // 接口返回数据
          if (response.data === 1) {
            that.$message({
              message: '删除成功',
              type: 'success'
            })
            that.load()
          }
        })
    },
    doCollect: function () {
      var that = this
      if(this.addComment.userId === ''){
        const h = this.$createElement;
        this.$msgbox({
          title: '消息',
          message: h('p', null, [
            h('span', null, '请先登录'),
          ]),
          showCancelButton: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          beforeClose: (action, instance, done) => {
            if (action === 'confirm') {
              this.$router.push({
                name: 'index'
              })
              done()
            } else {
              done()
            }
          }
        })
      }else{
        if(that.isCollected){
              that.$ajax.get(// 调用接口
                '/collect/deleteCollect?collectId=' + that.attraction.collectId+'&attrId=' + that.attrId
              ).then(function (response) {
                if(response.data===1){
                  that.$message({
                    message: '取消收藏成功',
                    type: 'success'
                  });
                  that.load()
                  that.isCollected = false
                }
              })
        }else{
          that.$ajax.get(// 调用接口
            '/collect/doCollect?collectId=' + that.attrId + '&userId=' + that.addComment.userId+'&type=1'
          ).then(function (response) {
            if(response.data===1){
              that.isCollected = true
              that.$message({
                message: '收藏成功',
                type: 'success'
              })
              that.load()
            }
          })
        }
      }
    },
  }
}
</script>

<style scoped>
.img {
  width: 100%;
}
.map{
  height: 200px;
}
.detail-div {
  padding: 15px;
}
.name {
  font-size: 22px;
}
.rating-all {
  float: right;
}
.rating {
  color: #ff8361;
  font-size: 20px;
}
.discription {
  color: #09b5f0;
  font-size: 14px;
  border: 1px solid;
  border-radius: 5px;
  padding: 0px 5px;
}
.discription-div {
  padding-bottom: 20px;
  border-bottom: 1px solid #e1e1e1;
}
.big-title {
  text-align: center;
  font-size: 18px;
  margin: 5px 0px;
}
.title {
  margin: 10px 0px;
  font-size: 18px;
}
.title-before {
  background: linear-gradient(#c8e8f2, #0aa3f4);
  width: 7px;
  height: 25px;
  border-radius: 5px;
  float: left;
}
.title-content {
  display: inline-block;
  margin-left: 8px;
}
.all-comment{
  padding: 0 10px;
}
.note-detail-comment-img {
  width: 50px;
  height: 50px;
  border-radius: 50px;
}

.note-detail-comment-title {
  font-size: 20px;
  margin: 20px 0 5px 0;
  display: block;
}

.note-detail-comment-name-div {
  display: inline-block;
}

.note-detail-comment-name {
  display: block;
  margin-bottom: 10px;
}
.note-detail-comment-del {
  float: right;
  margin-right: 15px;
  color: #1183dd;
}
.note-detail-comment-time {
  color: #8f8f8f;
  margin-bottom: 12px;
  display: block;
}

.note-detail-comment-cont {
  display: block;
}

.note-detail-comment-div {
  padding: 15px 0;
  border-bottom: 1px solid #e6e6e6;
}
.comment-div {
  margin-top: 15px;
}
.comment-text {
  width: 80%;
  height: 30px;
  border-radius: 10px;
  border-color: #e1e1e1;
  line-height: 32px;
  font-size: 13px;
}
.comment-sub {
  color: #000000;
  background: none;
  width: 15%;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
  float: right;
}
.is_collected{
  background: url("../../../static/images/isCollect.png") no-repeat center;
  background-size: 25px 25px;
  width: 25px;
  height: 25px;
  float: right;
  margin: 2px 20px;
}

.is_not_collected{
  background: url("../../../static/images/isNotCollect.png") no-repeat center;
  background-size: 25px 25px;
  width: 25px;
  height: 25px;
  float: right;
  margin: 2px 20px;
}
</style>
