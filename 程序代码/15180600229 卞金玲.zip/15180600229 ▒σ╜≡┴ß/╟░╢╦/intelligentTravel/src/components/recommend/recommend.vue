<template>
   <div id="recommend" style="height: calc(100% - 58px);margin-bottom: 50px;">
      <pullRefresh ref="myscrollfull" @load="load" scrollDataListId="messList">
        <div class="bigger-div">
          <div class="cheap-div">
          <div class="cheap-title-div">
            <span class="cheap-title">超值特惠</span>
            <span class="cheap-title-more">更多 ></span>
            </div>
          <div class="cheap-info border-right">
            <div class="cheap-info-title">特价酒店</div>
            <div class="cheap-info-context">限时抢购</div></div>
          <div class="cheap-info border-right"><div class="cheap-info-title">特价旅游</div><div class="cheap-info-context">超值3折起</div></div>
          <div class="cheap-info"><div class="cheap-info-title">春节特惠</div><div class="cheap-info-context">立减1000</div></div>
          </div>
          <div class="recom-div">
            <div>推荐</div>
            <div class="note-left" v-for="attr in attrList" :key="attr.nNoteId" @click="jumpToDetail(attr)">
            <div class="note-img-div"><img :src="attr.cImg" class="note-img"></div>
            <div class="note-title">{{attr.cName}}</div>
            <div class="note-msg"><span class="note-msg-span">{{attr.cDiscription}}</span></div>
            <div>
              <span class="note-price-all"><span class="note-price-span">￥</span><span class="note-price">{{attr.dPrice}}</span><span class="note-price-span">起</span></span>
              <span class="note-rating">{{attr.nRating}} 喜欢</span>
            </div>
            </div>
          </div>
        </div>
      </pullRefresh>
    <foot-nav></foot-nav>
   </div>
</template>

<script>
import footNav from '../foot-nav.vue'
import vueWaterfallEasy from 'vue-waterfall-easy'
export default {
  components: {
    footNav,
    vueWaterfallEasy
  },
  data () {
    return {
      attrList: [],
      imgsArr: '',
      fetchImgsArr: ''
    }
  },
  mounted () {
  },
  methods: {
    load (page) {
      var that = this
      that.$ajax.get(// 调用接口
        '/attraction/getAttractions?pageNo=' + page.num + '&pageSize=' + page.size// this指data
      ).then(function (response) { // 接口返回数据
        var attrList = response.data
        for (var i = 0; i < attrList.length; i++) {
          if (attrList[i].cDiscription === null) {
            attrList[i].cDiscription = '强烈推荐'
          }
          if (attrList[i].cImg === null) {
            attrList[i].cImg = '../../../static/images/search-city0.jpg'
          }
        }
        that.successCallback && that.successCallback(page, attrList) // 成功回调
      })
    },
    jumpToDetail (attr) {
      this.$router.push({
        name: 'recomDetail',
        query: {
          attrId: attr.nId
        }
      })
    },
    successCallback (page, curPageData) {
      let self = this

      // curPageData = [] // 打开本行注释,可演示列表无任何数据empty的配置

      // 如果是第一页需手动制空列表 (代替clearId和clearEmptyId的配置)
      if (page.num === 1) {
        self.attrList = []
      }
      // 更新列表数据
      self.attrList = self.attrList.concat(curPageData)
      // 列表更新成功，刷新列表
      self.$refs.myscrollfull.endSuccess(curPageData.length)
    },
    errorCallback () {
    // 联网失败的回调,隐藏下拉刷新和上拉加载的状态;
      this.$refs.myscrollfull.getScrollInstance().endErr()
    }
  }
}
</script>
<style scoped>
.border-right{
  border-right: 1px solid #e1e1e1;
}
.bigger-div{
  margin-bottom: 55px;
  padding: 10px 10px 0 10px;
  background-color: #f8f8f8;
}
.cheap-div{
  background-color:#ffffff;
  box-shadow: 0 0 1px #e6e6e6;
  border-radius: 5px;
  margin-bottom: 10px;
}
.cheap-info{
  display: inline-block;
  width: 32%;
  height: 60px;
  text-align: right;
  padding-top: 10px;
  padding-left: 10px;
  background: url(../../../static/images/recom-back.jpg);
  background-size:100% 100%;

}
.cheap-info-title{
  display: block;
  text-align: left;
}
.cheap-info-context{
  color: red;
  font-size: 13px;
  text-align: left;
}
.cheap-title-div{
  height: 42px;
  padding: 10px 10px 0 10px;
  border-bottom: 1px solid #e1e1e1;
}
.cheap-title{
  font-size: 20px;
}
.cheap-title-more{
  float: right ;
  color: #8f8f8f;
}

.note-div{
  margin-left: 10px;
}

.note-img{
  width: 100%;
  border-radius: 4px;
}
.note-left{
  width: 47%;
  display: inline-block;
  margin: 5px 5px 10px 5px;
  background-color: #ffffff;
  border-radius: 5px;
}

.note-title{
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 1.7;
  padding-left: 5px;
}

.note-msg{
  font-size: 12px;
  line-height: 1.7;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  padding-left: 5px;
  margin-bottom: 5px;
}

.note-msg-span{
  background: linear-gradient(to right , #fa2222, #ec9973);
  color: #ffffff;
  padding: 1px 5px;
}

.note-img-div{
  display: inline-block;
  width: 100%;
  margin-right: 10px;
}
.note-price-all{
  margin-left: 3px;
}
.note-price{
  font-size: 16px;
  color: #e7481d;
}
.note-price-span{
  font-size: 12px;
  color: #e7481d;
}
.note-rating{
  font-size: 13px;
  color: #949393;
  margin-top: 3px;
  margin-left: 10px;
}
</style>
