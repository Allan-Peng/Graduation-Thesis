<template>
  <div>
    <Header title="游记"></Header>
    <img :src="note.img" class="note-detail-img">
    <div class="note-detail-big-div">
      <div class="note-detail-div">
        <span style="font-size:24px">{{note.cTitle}}</span>
        <div class="note-detail-rating-div">
          <span class="note-autor">{{note.createTime}}</span>
          <span class="note-detail-rating"> 浏览数 {{note.rating}}</span>
        </div>
        <div>
          <img :src="note.img" class="note-detail-comment-img">
          <div v-show="isCollected===true" class='is_collected' @click="doCollect"></div>
          <div v-show="isCollected===false" class='is_not_collected' @click="doCollect"></div>
          <div class="note-detail-autor-div">
            <span class="note-detail-autor">{{note.autor}}</span>
          </div>
          <div class="note-detail-content-div">
            <!-- <span>为什么说结婚前,</span>
            <span>必须先去一趟旅行,</span>
            <span>一场前途未卜的双人旅行,</span>
            <span>多像是婚姻关系？</span>
            <span>停不下的一站又一站,</span>
            <span>就像是婚姻里的一天又一天,</span>
            <span style="font-weight: bold;">层出不穷的问题等待处理,</span>
            <span style="font-weight: bold;">而又有那么多美丽的景色与奇遇,</span>
            <span style="font-weight: bold;">等待着被发现。</span>
            <span style="font-weight: bold;font-size:20px">1、云南大理</span>
            <span>你们可以在风和日丽的早上,</span>
            <span>租一辆电动车,</span>
            <span>背上行囊,</span>
            <span>听着音乐,</span>
            <span>沿着洱海骑行。</span>
            <span>（图片均来自图虫网，版权归作者所有）</span> -->
            {{note.cText}}
          </div>
        </div>
        <div>
            <span class="note-detail-comment-title">最新评论</span>
            <div v-for="comment in commentList" :key="comment.id" class="note-detail-comment-div" v-show="!commentIsNull">
              <img :src="comment.img" class="note-detail-comment-img">
              <div class="note-detail-comment-name-div">
                <span class="note-detail-comment-name">{{comment.userName}}</span>
                <span class="note-detail-comment-time">{{comment.createTime}}</span>
              </div>
              <span
                class="note-detail-comment-del"
                v-if="comment.isDel"
                @click="delComment(comment.id)"
              >删除</span>
              <span class="note-detail-comment-cont">{{comment.content}}</span>
            </div>
            <div v-show="commentIsNull">暂无评论</div>
            <div class="comment-div">
              <textarea class="comment-text" placeholder="千头万绪，汇成一句话" v-model="addComment.content"></textarea>
              <button class="comment-sub" @click="addCommentFunc">评论</button>
            </div>
          </div>
      </div>
    </div>
  </div>
</template>

<script>
import Header from '../header.vue'
export default {
  components:{Header},
  data () {
    return {
      isCollected:false,
      noteId: this.$route.query.noteId,
      addComment: {
        noteId: this.$route.query.noteId,
        userId: sessionStorage.getItem('userId'),
        content: '',
        type: 0 // 游记
      }, // 添加评论
      note: {},
      commentList: [],
      commentIsNull: false,
      userId: ''
    }
  },
  mounted () {
    this.load()
  },
  methods: {
    load () {
      var that = this
      that.commentIsNull = false
      this.userId = sessionStorage.getItem('userId')
      that.$ajax.get(// 调用接口
        '/travelNote/getOneTravelNote?nNoteId=' + that.noteId + '&userId=' + that.userId
      ).then(function (response) {
        that.note = response.data
        if(response.data.collectId!=0) {
          that.isCollected = true
        }
      })
      this.noteId = this.$route.query.noteId
      this.addComment.content = ''
      this.addComment.noteId = this.$route.query.noteId
      this.addComment.userId = sessionStorage.getItem('userId')
      that.$ajax
        .get(
          // 调用接口
          '/comment/getComments?commentId=' + that.noteId + '&type=0'
        )
        .then(function (response) {
          that.commentList = response.data
          if (that.commentList == null || that.commentList.length === 0) {
            that.commentIsNull = true
          } else {
            for (var i = 0; i < that.commentList.length; i++) {
              that.commentList[i].isDel = false
              that.commentList[i].createTime = that.$moment(that.commentList[i].createTime).format('YYYY-MM-DD HH:mm:ss')
              if (that.commentList[i].userId.toString() === that.addComment.userId) {
                that.commentList[i].isDel = true
              }
            }
          }
        })
    },
    doCollect: function () {
      var that = this
      if(this.userId === ''){
        const h = this.$createElement;
        this.$msgbox({
          title: '消息',
          message: h('p', null, [
            h('span', null, '请先登录'),
          ]),
          showCancelButton: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          beforeClose: (action, instance, done) => {
            if (action === 'confirm') {
              this.$router.push({
                name: 'index'
              })
              done()
            } else {
              done()
            }
          }
        })
      }else{
        if(that.isCollected){
              that.$ajax.get(// 调用接口
                '/collect/deleteCollect?collectId=' + that.note.collectId
              ).then(function (response) {
                if(response.data===1){
                  that.$message({
                    message: '取消收藏成功',
                    type: 'success'
                  });
                  that.load()
                  that.isCollected = false
                }
              })
        }else{
          that.$ajax.get(// 调用接口
            '/collect/doCollect?collectId=' + that.noteId + '&userId=' + that.userId+'&type=0'
          ).then(function (response) {
            if(response.data===1){
              that.isCollected = true
              that.$message({
                message: '收藏成功',
                type: 'success'
              })
              that.load()
            }
          })
        }
      }
    },
    addCommentFunc () {
      var that = this
      if (that.addComment.userId === '') {
        that.$message({
          message: '请先登录',
          type: 'warning'
        })
      } else {
        if (this.addComment.content.trim() === '') {
          that.$message({
            message: '请填写评论内容',
            type: 'warning'
          })
        } else {
          that.$ajax
            .post(
              // 调用接口
              '/comment/addComment',
              { comment: that.addComment }
            )
            .then(function (response) {
              that.$message({
                message: '添加成功',
                type: 'success'
              })
              that.load()
              that.commentIsNull = false
            })
        }
      }
    },
    delComment (id) {
      var that = this
      this.$ajax
        .get(
          // 调用接口
          '/comment/delComment?commentId=' + id
        )
        .then(function (response) {
          // 接口返回数据
          if (response.data === 1) {
            that.$message({
              message: '删除成功',
              type: 'success'
            })
            that.load()
          }
        })
    }
  }
}
</script>

<style scoped>
.is_collected{
  background: url("../../../static/images/isCollect.png") no-repeat center;
  background-size: 25px 25px;
  width: 25px;
  height: 25px;
  float: right;
  margin-top: 10px;
  margin-right: 20px;
}

.is_not_collected{
  background: url("../../../static/images/isNotCollect.png") no-repeat center;
  background-size: 25px 25px;
  width: 25px;
  height: 25px;
  float: right;
  margin-top: 10px;
  margin-right: 20px;
}

.note-detail-img{
  margin-top: 55px;
  width: 100%;
  z-index: 1;
}

.note-detail-big-div{
  margin: -30px 0 10px 0;
  position: absolute;
  background: #fff;
  border-radius: 20px;
  width: 100%;
}

.note-detail-div{
  margin: 0 10px 10px 10px;
}

.note-detail-rating-div{
  margin: 10px 0;
}

.note-detail-rating{
  font-size: 13px;
  color: #949393;
  margin-left: 15px;
}

.note-detail-autor{
  font-size: 16px;
  color: #8ea0ef;
  display: block;
  margin: 16px 0 20px 0;
}

.note-detail-autor-div{
  float: right;
  text-align: left;
  width: 70%;
}

.note-detail-content-div{
  margin-top: 15px;
  display: block;
  font-size: 15px;
}

.note-detail-comment-img{
  width: 50px;
  height: 50px;
  border-radius: 50px;
}

.note-detail-comment-title{
  font-size: 20px;
  margin: 20px 0 5px 0;
  display: block;
}

.note-detail-comment-name-div{
  display: inline-block;
}

.note-detail-comment-name{
  display: block;
  margin-bottom: 10px;
}

.note-detail-comment-time{
  color: #8f8f8f;
  margin-bottom: 12px;
  display: block;
}

.note-detail-comment-cont{
  display: block;
}

.note-detail-comment-div{
  padding: 15px 0;
  border-bottom: 1px solid #e6e6e6;
}
.comment-div {
  margin-top: 15px;
}
.comment-text {
  width: 80%;
  height: 30px;
  border-radius: 10px;
  border-color: #e1e1e1;
  line-height: 32px;
  font-size: 13px;
}
.comment-sub {
  color: #000000;
  background: none;
  width: 15%;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
  float: right;
}
.note-detail-comment-del {
  float: right;
  margin-right: 15px;
  color: #1183dd;
}
</style>
