<template>
  <div>
    <Header title="分享游记"></Header>
    <form @submit.prevent="submit" style="margin-top: 55px;">
      <div class="rz-picter">
        <img :src="note.img" class="img-avatar">
        <input type="file" name="avatar" id="uppic" accept="image/gif,image/jpeg,image/jpg,image/png" @change="changeImage($event)" ref="avatarInput" class="uppic">
      </div>
      <div class="input-div">标题：<input class="input" v-model="note.cTitle"/></div>
      <div class="input-div">简介：<input class="input" v-model="note.cContent"/></div>
      <div class="input-div"><span class="span">正文：</span><textarea class="textarea" v-model="note.cText"></textarea></div>
      <div><input type="submit" value="提交" class="note-sub"/></div>
    </form>
  </div>
</template>

<script>
import Header from '../header.vue'
export default {
  components:{Header},
  data () {
    return {
      note: {
        cTitle: '',
        cContent: '',
        img: require('../../assets/logo.png'),
        cText: '',
        autor:sessionStorage.getItem('usercName'),
        imgName: ''
      }
    }
  },
  methods: {
    changeImage (e) {
      var file = e.target.files[0]
      this.note.imgName = file.name
      var reader = new FileReader()
      var that = this
      reader.readAsDataURL(file)
      reader.onload = function (e) {
        that.note.img = this.result
      }
    },
    submit: function () {
      var that = this
      that.note.img = that.note.img.split(",")[1]
      // that.note.img = that.note.img.replace("data:image/png;base64,", "")
      that.$ajax.post(
        // 调用接口
        '/travelNote/insertNote',
         that.note
      )
        .then(function (response) {
          if (response.data === 1) {
            that.$router.go(-1)
            that.$message({
              message: '分享成功',
              type: 'success'
            })
          }
        })
    }
  }
}
</script>

<style scoped>
.img-avatar{
  width: 80%;
  margin: 10px 10%;
}
.uppic{
  margin: 0 0 10px 17%;
}
.input{
  width: 70%;
  height: 30px;
  margin: 0px 10% 15px 0;
}
.textarea{
  width: 70%;
  height: 100px;
  margin: 0px 10% 15px 0;
}
.input-div{
  padding-left: 5%;
}
.span{
  float: left;
}
.note-sub{
  width: 70%;
  height: 30px;
  margin: 0 15%;
}
</style>
