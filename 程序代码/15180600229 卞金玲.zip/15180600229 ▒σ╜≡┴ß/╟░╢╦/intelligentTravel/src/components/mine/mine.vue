<template>
   <div class='mine' style="margin-bottom: 50px;">
     <div>
       <div class="mine-title-div" v-show="isNotLogin">
        <div class="mine-login-div"><span class="mine-title-span">登录XX,开启旅程</span></div>
        <div class="mine-btn-div">
          <el-button class="mine-btn-login" @click="jumpToLogin">登录</el-button>
          <el-button class="mine-btn-reg">注册</el-button>
        </div>
       </div>
       <div class="mine-title-div" v-show="!isNotLogin">
         <div class="mine-login-div"><span class="mine-title-span"> 欢迎  {{userName}}</span></div>
       </div>
     </div>
     <div class="mine-middle-big-div">
     <div class="mine-middle-div" @click="getUserInfo">
       <div class="mine-div">
         <span class="mine-span1">个人信息</span>
         <img src="../../assets/mine-jt.png"  class="mine-img">
         <span class="mine-span2">修改个人信息</span>
       </div>
     </div>
     <div class="mine-middle-div" @click="getMyCollect">
       <div class="mine-div">
         <span class="mine-span1">我的收藏</span>
         <img src="../../assets/mine-jt.png"  class="mine-img">
         <span class="mine-span2">收藏后反对发射点发生</span>
       </div>
       </div>
     <div class="mine-middle-div">
       <div class="mine-div">
         <span class="mine-span1">浏览历史</span>
         <img src="../../assets/mine-jt.png"  class="mine-img">
         <span class="mine-span2">保留15天，你浏览过的都在这</span>
       </div>
       </div>
     <div class="mine-middle-div">
       <div class="mine-div">
         <span class="mine-span1">常用信息</span>
         <img src="../../assets/mine-jt.png"  class="mine-img">
         <span class="mine-span2">旅客/地址</span>
       </div>
       </div>
     <div class="mine-middle-div" @click="jumpToShare">
       <div class="mine-div">
         <span class="mine-span1">分享游记</span>
         <img src="../../assets/mine-jt.png"  class="mine-img">
         <span class="mine-span2">在这里分享你的旅游心得</span>
       </div>
     </div>
     <button v-show="!isNotLogin" class="logout" @click="logout">退出登录</button>
     </div>
    <foot-nav></foot-nav>
   </div>
</template>

<script>
import footNav from '../foot-nav.vue'
export default {
  components: {
    footNav
  },
  data () {
    return {
      isNotLogin: false,
      userName: ''
    }
  },
  mounted () {
    this.userName = sessionStorage.getItem('usercName')

    if (this.userName === 'undefine' || this.userName == null || this.userName === '') {
      this.isNotLogin = true
    }
  },
  methods: {
    jumpToLogin: function () {
      this.$router.push(
        {
          name: 'index'
        }
      )
    },
    jumpToShare: function () {
      this.$router.push(
        {
          name: 'shareNote'
        }
      )
    },
    getMyCollect: function () {
      this.$router.push(
        {
          name: 'myCollect'
        }
      )
    },
    getUserInfo: function () {
      this.$router.push(
        {
          name: 'userInfo'
        }
      )
    },
    logout:function (){
      sessionStorage.clear()
      this.$router.go(0)

    }
  }
}
</script>
<style>
.mine{
  background: #e6e6e6;
  height: calc(100% - 40px);;
}
.mine-btn-login{
  border-radius: 18px;
  width: 115px;
  margin-right: 20px;
}
.mine-btn-reg{
  border-radius: 18px;
  width: 115px;
  margin-left: 20px;
}
.mine-title-div{
  background: url('../../../static/images/mine-title.jpg');
  background-size: 100% auto;
  height: 184px;
}

.mine-title-span{
  font-size: 22px;
  margin: auto;
  position: absolute;
  top: 20px;
  bottom: 0;
  left: 0;
  right: 0;
  width: 60%;
  height: 35%;
}
.mine-btn-div{
  display: inline-block;
  width: 100%;
  text-align: center;
}
.mine-middle-big-div{
  margin-top: 10px;
}

.mine-middle-div{
  height: 45px;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #e6e6e6;
  background: #fff;
}
.mine-div{
  padding-left: 20px;
  width: 100%;
}

.mine-span1{
  margin: 5px 0;
  float: left;
}

.mine-span2{
  margin: 5px 0;
  float: right;
  font-size: 14px;
  color: #acabab;
}

.mine-img{
  float: right;
  margin: 8px 10px;
}

.mine-login-div{
  width: 100%;
  height: 55%;
  position: relative;
  text-align: center;
}
.logout{
  width: 80%;
  margin: 10px 10%;
  height: 40px;
  border-radius: 20px;
  border: 1px solid #e1e1e1 !important;
  background-color: #fff;
}
</style>
