<template>
   <div style="height:100%;margin-bottom: 50px;">
       <el-carousel :interval="5000" arrow="always">
          <el-carousel-item v-for="item in 4" :key="item">
            <img :src="imgs[item]" class="lunbo"/>
          </el-carousel-item>
        </el-carousel>
    <div class="big-div">
      <div class="header-div">
        <span class="header-span">来一场说走就走的定制旅行吧~~</span>
      </div>
      <div class="middle-all-div">
        <div class="middle-div middle-div-second">
          <div class="middle-title">Step1</div>
          <div class="middle-content">提交需求</div>
        </div>
        <div class="middle-div middle-div-second">
          <div class="middle-title">Step2</div>
          <div class="middle-content">提交需求</div>
        </div>
        <div class="middle-div">
          <div class="middle-title">Step3</div>
          <div class="middle-content">系统推荐</div>
        </div>
      </div>
      <div class="button-div">
        <button class="button" @click="JumpChoose">快速定制</button>
      </div>
    </div>
    <foot-nav></foot-nav>
   </div>
</template>

<script>
import footNav from '../foot-nav.vue'
export default {
  components: {
    footNav
  },
  data () {
    return {
      imgs:[
        '../../../static/images/lunbo1.jpg',
        '../../../static/images/lunbo1.jpg',
        '../../../static/images/lunbo2.jpg',
        '../../../static/images/lunbo3.jpg',
        '../../../static/images/lunbo4.jpg'
      ]
    }
  },
  methods: {
    JumpChoose: function () {
      this.$router.push(
        {
          name: 'chooseDestination'
        }
      )
    }
  }
}
</script>
<style scoped>
.lunbo{
  width: 100%;
  /* height: 236px; */
}
.el-carousel__item h3 {
  color: #475669;
  font-size: 18px;
  opacity: 0.75;
  line-height: 300px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n+1) {
  background-color: #d3dce6;
}
.big-div{
  background-color: #05e5dd;
  height: calc(100% - 260px);
}
.header-div{
  height: 130px;
  color: #ffffff;
  font-size: 28px;
  vertical-align: middle;
  width: 100%;
}
.header-span{
  width: 70%;
  display: block;
  margin-left: 10%;
  height: 100%;
  padding: 30px 0px;
}
.middle-all-div{
  padding-left: 10%;
}
.middle-div{
  height: 80px;
  width: 80px;
  display: inline-block;
  border: 3px solid #FFFFFF;
  border-radius: 15px;
}
.middle-div-second{
  margin-right: calc((80% - 224px)/2);
}
.middle-div-second::before {
  background: url(../../../static/images/to.png) no-repeat ;
  content: '';
  position: absolute;
  z-index: 2;
  width: calc((80% - 240px)/4);
  height: 16px;
  background-size: 10px 10px;
  margin-left: calc(80px + (80% - 240px)/8);
  margin-top: 40px;
}
.middle-title{
  margin: 10px 0 0 10px;
  color: #ffffff;
  font-weight: bold;
}
.middle-content{
  margin: 20px 0 0px 10px;
  color: #ffffff;
}
.button-div{
  height: 100px;
  text-align: center;
}
.button{
  background-color: #ffffff;
  border: none;
  color: #05e5dd;
  width: 80%;
  height: 40px;
  border-radius: 25px;
  margin-top: 20px;
  font-size: 16px;
}
</style>
