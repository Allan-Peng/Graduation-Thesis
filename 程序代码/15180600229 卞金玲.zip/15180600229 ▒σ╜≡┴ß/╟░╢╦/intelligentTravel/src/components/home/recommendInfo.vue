<template>
  <div>
    <Header :title="title"></Header>
    <div style="height: 350px;margin-top: 55px;">
      <el-steps direction="vertical" :active="1" style="margin: 10px;">
        <el-step :title="key" v-for="(key,index) in keys" :key="key" :description="attrList[index]">
        </el-step>
      </el-steps>
    </div>
    <!-- <div v-for="(key,index) in keys" :key="key">
      <div class="hot-div" v-for="attr in rec[key]" :key="attr.nId">
        <span >{{attrList[index]}}</span>
      </div>
    </div> -->
  </div>
</template>

<script>
import Header from '../header.vue'
export default {
  components:{Header},
  data () {
    return {
      title:'推荐',
      destination: this.$route.query.destination,
      rec: '',
      keys:[],
      attrList:[]
    }
  },
  mounted () {
    var that = this
    that.$ajax.get(// 调用接口
      '/attraction/getTravels?destination=' + this.destination// this指data
    ).then(function (response) { // 接口返回数据
      that.rec = response.data.attr
      that.keys = response.data.lu.split('->')
      for(var i=0;i<that.keys.length;i++){
        var cityName = that.keys[i]
        var attrLists = that.rec[that.keys[i]]
        if(attrLists!=null){
          var aa = ''
          for(var j=0;j<attrLists.length;j++){
            aa += attrLists[j].cName + ','
          }
          aa = aa.substring(0,aa.length-1)
          that.attrList[i] = aa
        }
      }
    })
  },
  methods: {
    jumpToAttrDetail(id){
      this.$router.push({
        name: 'recomDetail',
        query: {
          attrId: id
        }
      })
    }
  }
}
</script>

<style>
</style>
