import PullRefresh from './PullRefresh.vue'

const pullRefresh = {
  install: function (Vue) {
    Vue.component('pullRefresh', PullRefresh)
  }
}

export default pullRefresh
