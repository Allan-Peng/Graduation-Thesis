// 登录用户名
let loginUserName = ''
let loginId = ''

var getLoginUserName = function () {
  return loginUserName
}

var setLoginUserName = function (userName) {
  loginUserName = userName
}

var getLoginId = function () {
  return loginId
}

var setLoginId = function (nId) {
  loginId = nId
}

export default {
  loginUserName,
  getLoginUserName,
  setLoginUserName,
  loginId,
  getLoginId,
  setLoginId
}
