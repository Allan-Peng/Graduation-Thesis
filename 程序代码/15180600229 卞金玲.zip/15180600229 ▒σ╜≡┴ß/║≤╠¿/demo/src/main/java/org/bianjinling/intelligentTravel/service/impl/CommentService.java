package org.bianjinling.intelligentTravel.service.impl;

import java.util.List;

import org.bianjinling.intelligentTravel.dao.ICommentDao;
import org.bianjinling.intelligentTravel.entity.Comment;
import org.bianjinling.intelligentTravel.service.ICommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("CommentService")
public class CommentService implements ICommentService{

	@Autowired
	ICommentDao commentDao;
	
	@Override
	public List<Comment> selectCommentById(int commentId,int type){
		return commentDao.selectCommentById(commentId,type);
	}

	@Override
	public int addComment(Comment comment) {
		return commentDao.addComment(comment);
	}

	@Override
	public int delComment(int commentId) {
		return commentDao.delComment(commentId);
	}
}
