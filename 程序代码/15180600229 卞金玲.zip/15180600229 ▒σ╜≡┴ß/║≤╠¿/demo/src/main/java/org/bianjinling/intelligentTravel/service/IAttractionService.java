package org.bianjinling.intelligentTravel.service;

import java.util.List;

import org.bianjinling.intelligentTravel.basic.pagehelper.CustomPageInfo;
import org.bianjinling.intelligentTravel.entity.Attraction;
import org.springframework.web.bind.annotation.RequestParam;

public interface IAttractionService {
	
	/**
	 * 获取当前id景点
	 * @param nId id
	 * @return
	 */
	public Attraction selectByPrimaryKey(int nId,Integer userId);
	
	/**
	 * 获取全部景点信息
	 * @return
	 */
	public CustomPageInfo<Attraction> selectOrderByRating(int pageNo,int pageSize);
	
	List<Attraction> getCitys();
	
	List<Attraction> getAttrByCitys(String city);
	
}
