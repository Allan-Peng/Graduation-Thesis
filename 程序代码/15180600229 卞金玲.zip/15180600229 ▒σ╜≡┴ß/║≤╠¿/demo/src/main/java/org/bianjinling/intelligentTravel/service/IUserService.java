package org.bianjinling.intelligentTravel.service;

import org.bianjinling.intelligentTravel.entity.User;

public interface IUserService {
	
	public User getDemoTest(int id);

	public User getUserByLogin(String login);

	public int updateInfo(User user);
	
}
