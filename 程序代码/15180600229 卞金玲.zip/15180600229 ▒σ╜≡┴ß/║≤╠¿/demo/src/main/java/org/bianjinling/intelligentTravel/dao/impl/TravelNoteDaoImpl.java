package org.bianjinling.intelligentTravel.dao.impl;

import java.util.List;

import org.bianjinling.intelligentTravel.dao.ITravelNoteDao;
import org.bianjinling.intelligentTravel.entity.TravelNote;
import org.bianjinling.intelligentTravel.mapper.TravelNoteMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class TravelNoteDaoImpl implements ITravelNoteDao {

	@Autowired
	TravelNoteMapper mTravelNoteMapper;
	
	@Override
	public TravelNote selectByPrimaryKey(int nNoteId,Integer userId) {
		return mTravelNoteMapper.selectByPrimaryKey(nNoteId,userId);
	}
	
	@Override
	public List<TravelNote> selectOrderByRating(){
		return mTravelNoteMapper.selectOrderByRating();
	}

	@Override
	public int insert(TravelNote travelNote) {
		return mTravelNoteMapper.insert(travelNote);
	}
}
