package org.bianjinling.intelligentTravel.util;

import java.util.Set;

public class MapBuilder {
    public Node build(Set<Node> open, Set<Node> close){
        Node nodeA=new Node("安徽");
        Node nodeB=new Node("澳门");
        Node nodeC=new Node("广西");
        Node nodeD=new Node("北京市");
        Node nodeE=new Node("甘肃");
        Node nodeF=new Node("福建");
        Node nodeG=new Node("广东");
        Node nodeH=new Node("海南");
        Node nodeI=new Node("贵州");
        Node nodeJ=new Node("四川");
        nodeA.getChild().put(nodeB, 5);
        nodeA.getChild().put(nodeC, 4);
        nodeA.getChild().put(nodeD, 8);
        nodeA.getChild().put(nodeJ, 5);
        nodeA.getChild().put(nodeF, 6);
        nodeB.getChild().put(nodeA, 5);
        nodeB.getChild().put(nodeD, 10);
        nodeB.getChild().put(nodeC, 3);
        nodeB.getChild().put(nodeG, 5);
        nodeC.getChild().put(nodeA, 4);
        nodeC.getChild().put(nodeG, 2);
        nodeC.getChild().put(nodeB, 3);
        nodeD.getChild().put(nodeA, 8);
        nodeD.getChild().put(nodeE, 7);
        nodeD.getChild().put(nodeB, 10);
        nodeD.getChild().put(nodeF, 15);
        nodeE.getChild().put(nodeD, 7);
        nodeE.getChild().put(nodeG, 5);
        nodeF.getChild().put(nodeG, 4);
        nodeF.getChild().put(nodeJ, 6);
        nodeF.getChild().put(nodeH, 8);
        nodeF.getChild().put(nodeD, 15);
        nodeF.getChild().put(nodeA, 6);
        nodeG.getChild().put(nodeC, 2);
        nodeG.getChild().put(nodeB, 5);
        nodeG.getChild().put(nodeE, 5);
        nodeG.getChild().put(nodeF, 4);
        nodeG.getChild().put(nodeJ, 7);
        nodeH.getChild().put(nodeF, 8);
        nodeH.getChild().put(nodeI, 7);
        nodeI.getChild().put(nodeH, 7);
        nodeI.getChild().put(nodeJ, 3);
        nodeJ.getChild().put(nodeI, 3);
        nodeJ.getChild().put(nodeA, 5);
        nodeJ.getChild().put(nodeF, 6);
        nodeJ.getChild().put(nodeG, 7);
        open.add(nodeB);
        open.add(nodeC);
        open.add(nodeD);
        open.add(nodeE);
        open.add(nodeF);
        open.add(nodeG);
        open.add(nodeH);
        open.add(nodeI);
        open.add(nodeJ);
        close.add(nodeA);
        return nodeA;
    }
}