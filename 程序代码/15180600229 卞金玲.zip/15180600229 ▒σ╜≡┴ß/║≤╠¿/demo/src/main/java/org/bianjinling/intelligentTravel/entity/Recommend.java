package org.bianjinling.intelligentTravel.entity;

import java.util.List;
import java.util.Map;

public class Recommend {
	
	private String lu;
	
	private Map<String, List<Attraction>> attr;

	public String getLu() {
		return lu;
	}

	public void setLu(String lu) {
		this.lu = lu;
	}

	public Map<String, List<Attraction>> getAttr() {
		return attr;
	}

	public void setAttr(Map<String, List<Attraction>> attr) {
		this.attr = attr;
	}
	
	
}
