package org.bianjinling.intelligentTravel.dao.impl;

import org.bianjinling.intelligentTravel.dao.IUserDao;
import org.bianjinling.intelligentTravel.entity.User;
import org.bianjinling.intelligentTravel.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements IUserDao {

	@Autowired
	UserMapper mUserMapper;
	
	@Override
	public User selectByPrimaryKey(int id) {
		return mUserMapper.selectByPrimaryKey(id);
	}
	
	@Override
	public User getUserByLogin(String login) {
		return mUserMapper.getUserByLogin(login);
	}
	
	@Override
	public int updateInfo(User user) {
    	return mUserMapper.updateByPrimaryKeySelective(user);
    }

}
