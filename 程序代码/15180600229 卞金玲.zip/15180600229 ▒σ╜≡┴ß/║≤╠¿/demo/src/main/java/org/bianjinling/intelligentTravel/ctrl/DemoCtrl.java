package org.bianjinling.intelligentTravel.ctrl;

import org.bianjinling.intelligentTravel.entity.User;
import org.bianjinling.intelligentTravel.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class DemoCtrl {

    @Autowired
    IUserService mUserService;

    @ResponseBody
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public User getUserByLogin(String login) {
        return mUserService.getUserByLogin(login);
    }
    
    @RequestMapping(value = "/updateInfo", method = RequestMethod.POST)
    public int updateInfo( @RequestBody User user) {
    	return mUserService.updateInfo(user);
    }
    
}
