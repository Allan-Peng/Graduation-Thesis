package org.bianjinling.intelligentTravel.ctrl;

import java.util.List;

import org.bianjinling.intelligentTravel.entity.Collect;
import org.bianjinling.intelligentTravel.service.ICollectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/collect")
public class CollectCtrl {

	@Autowired
	ICollectService collectSetvice;
	
	
	@ResponseBody
	@RequestMapping(value = "/getAllCollects", method = RequestMethod.GET)
	public List<Collect> getAllCollects(int userId) {
		return collectSetvice.getAllCollects(userId);
	}
	
	@RequestMapping(value = "/deleteCollect", method = RequestMethod.GET)
	public int deleteCollect(int collectId,int attrId) {
		collectSetvice.reduceCollectNum(attrId);
		return collectSetvice.deleteCollect(collectId);
	}
	
	@RequestMapping(value = "/doCollect", method = RequestMethod.GET)
	public int doCollect(int userId,int collectId,int type) {
		collectSetvice.addCollectNum(collectId);
		return collectSetvice.doCollect(userId,collectId,type);
	}
	
}
