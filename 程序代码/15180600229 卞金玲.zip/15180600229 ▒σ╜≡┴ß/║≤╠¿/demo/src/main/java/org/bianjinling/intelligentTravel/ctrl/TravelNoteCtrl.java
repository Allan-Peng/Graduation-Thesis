package org.bianjinling.intelligentTravel.ctrl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.bianjinling.intelligentTravel.entity.TravelNote;
import org.bianjinling.intelligentTravel.service.ITravelNoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/travelNote")
public class TravelNoteCtrl {
	
	@Autowired
	ITravelNoteService travelNoteService;

	@RequestMapping(value="/getOneTravelNote" , method = RequestMethod.GET)
	public TravelNote selectByPrimaryKey(@RequestParam int nNoteId,@RequestParam Integer userId){
		TravelNote aa =  travelNoteService.selectByPrimaryKey(nNoteId,userId);
		return aa;
	}
	
	@ResponseBody
	@RequestMapping(value="/getTravelNotes" , method = RequestMethod.GET)
	public List<TravelNote> selectOrderByRating(){
		return travelNoteService.selectOrderByRating();
	}
	
	@RequestMapping(value="/insertNote" , method = RequestMethod.POST)
	public int insertNote(@RequestBody TravelNote note) throws IOException{
		return travelNoteService.insert(note);
	}
}