package org.bianjinling.intelligentTravel.dao;

import java.util.List;

import org.bianjinling.intelligentTravel.entity.Attraction;

import com.github.pagehelper.Page;

public interface IAttractionDao {
	/**
	 * 获取当前id景点
	 * @param nId id
	 * @return
	 */
	public Attraction selectByPrimaryKey(int nId,Integer userId);
	
	/**
	 * 获取全部景点信息
	 * @return
	 */
	public Page<Attraction> selectOrderByRating(int pageNo,int pageSize);
	
	List<Attraction> getCitys();

	public List<Attraction> getAttrByCitys(String city);
}
