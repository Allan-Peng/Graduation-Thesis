package org.bianjinling.intelligentTravel.service;

import java.util.List;

import org.bianjinling.intelligentTravel.entity.Comment;

public interface ICommentService {
	
	/**
	 * 获取当前景点或游记的评价
	 * @param commentId 评价id
	 * @param type 0：游记，1：景点
	 * @return
	 */
	public List<Comment> selectCommentById(int commentId,int type) ;
	
	/**
	 * 添加评论
	 * @param comment
	 * @return
	 */
	int addComment(Comment comment);

	int delComment(int commentId);
}
