package com.lixingyong.meneusoft.modules.xcx.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.lixingyong.meneusoft.modules.xcx.entity.ContactBook;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ContactBookDao extends BaseMapper<ContactBook> {
}
