package com.lixingyong.meneusoft.modules.xcx.service;

public interface ScheduledService {
    void getContactBooksAndTeachers();

    void getLectures();

    void getTerms();

    void computeCourse();
}
