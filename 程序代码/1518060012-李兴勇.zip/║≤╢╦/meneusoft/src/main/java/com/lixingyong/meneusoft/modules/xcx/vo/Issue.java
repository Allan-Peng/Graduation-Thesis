package com.lixingyong.meneusoft.modules.xcx.vo;

import lombok.Data;

@Data
public class Issue {
    private String title;
    private String body;
    private String state;
}
