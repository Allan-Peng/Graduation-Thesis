package com.lixingyong.meneusoft.api.evaluate.VO;

import lombok.Data;

@Data
public class HiddenInput {
    private String name;
    private String value;
}
