// pages/profile/index.js
import ty from '../../utils/request'
import util from '../../utils/storage'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    isLogin: false,
    username: null,
    password: null,
    un: null,
    pw: null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let ret = util.get('login')
    if (ret) {
      this.setData({
        isLogin: true
      })
    }
    // this.getInfo()
  },
  logout() {
    util.remove('login')
    this.setData({
      isLogin: false
    })
  },
  willDo() {
    wx.showToast({
      title: '我是待开发的功能',
      icon: 'none',
      duration: 1000
    })
  },
  signup() {
    let ret = this.isinput()
    if (ret) {
      ty.request({
        url: 'http://localhost:9000/api/user/signup',
        data: {
          username: this.data.username,
          password: this.data.password
        },
        method: 'post'
      }).then((res) => {
        console.log(res)
        if (res.data.data.msg === "注册成功~") {
          this.setData({
            un: null,
            pw: null
          })
          wx.showToast({
            title: res.data.data.msg,
            icon: 'none',
            duration: 2000
          })
        }
      }).catch((err) => {
        console.log(err, '55')
      })
    }
  },
  login() {
    let ret = this.isinput()
    if (ret) {
      ty.request({
        url: 'http://localhost:9000/api/user/signin',
        data: {
          username: this.data.username,
          password: this.data.password
        },
        method: 'post'
      }).then((res) => {
        console.log(res)
        if (res.data.data.username === this.data.username) {
          this.setData({
            isLogin: true
          })
          this.setStorage('login')
          wx.showToast({
            title: '登陆成功',
            icon: 'none',
            duration: 2000
          })
        } else {
          wx.showToast({
            title: res.data.data.msg,
            icon: 'none',
            duration: 2000
          })
        }
      }).catch((err) => {
        console.log(err, '55')
      })
    }
  },
  isinput() {
    let name = this.data.username
    let word = this.data.password
    if (!name) {
      wx.showToast({
        title: '请输入账号',
        icon: 'none',
        duration: 2000
      })
      return false
    }
    if (!word) {
      wx.showToast({
        title: '请输入密码',
        icon: 'none',
        duration: 2000
      })
      return false
    }
    if (name && word) return true
  },
  setvalue(evt) {
    if (evt.currentTarget.id === 'name') {
      this.setData({
        username: evt.detail.value
      })
    } else {
      this.setData({
        password: evt.detail.value
      })
    }
  },
  // 种下7天的token
  setStorage (key) {
    let status = util.get(key)
    if (!status) {
      util.put(key, true, 604800)
    }
  },
  bindGetUserInfo(res) {
    console.log(res)
    if (res.detail.userInfo) {
      this.setData({
        isLogin: true,
        userInfo: res.detail.userInfo
      })
    } else {
      wx.showToast({
        title: '不登陆没法看好看的哦～',
        icon: 'none',
        duration: 3000
      })
    }
  },
  getInfo() {
    console.log(17265)
    wx.getUserInfo({
      success: (res) => {
        console.log(res)
        this.setData({
          isLogin: true,
          userInfo: res.userInfo
        })
      },
      fail(e) {
        console.log(123)
      }
    })
    // wx.getSetting({
    //   success(res) {
    //     console.log(res)
    //     if (res.authSetting['scope.userInfo']) {
    //       wx.authorize({
    //         scope: 'scope.userInfo',
    //         success() {
    //         }
    //       })
    //     }
    //   },
    //   fail(e) {
    //     console.log(e)
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})