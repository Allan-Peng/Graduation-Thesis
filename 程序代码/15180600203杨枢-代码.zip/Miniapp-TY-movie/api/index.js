import * as common from './list/common'

export default {
  common
}