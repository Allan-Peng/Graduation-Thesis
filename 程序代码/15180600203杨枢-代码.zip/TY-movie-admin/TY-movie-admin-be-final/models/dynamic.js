const mongoose = require('../utils/database')

// 创建Schema，创建集合
const dynamicSchema = new mongoose.Schema({
  userLogo: String,
  userName: String,
  date: String,
  content: String,
  score: String,
  createDate: String
})
const dynamicModel = mongoose.model('dynamics', dynamicSchema)

// 保存一条评论信息
const save = (data) => {
  return new dynamicModel(data)
    .save()
    .then((result) => {
      return result
    })
}

// 取到单页评论信息
const list = ({
  start,
  count,
  keywords
}) => {
  let reg = new RegExp(keywords, 'gi')
  return dynamicModel
    // 关键字模糊查询
    .find({
      $or: [
        {
          'userName': reg
        }
      ]
    })
    .sort({
      _id: -1
    })
    .skip(start)
    .limit(count)
    .then((result) => {
      return result
    })
    // catch表示find操作出错了，空数据并不代表出错
    .catch((err) => {
      return false
    })
}
// 取到全部评论信息
const listall = ({keywords}) => {
  let reg = new RegExp(keywords, 'gi')
  return dynamicModel
    .find({
      $or: [{
          'userName': reg
        },
        {
          'score': reg
        }
      ]
    })
    .sort({
      _id: -1
    })
    // .count()
    .then((result) => {
      return result
    })
    // catch表示find操作出错了，空数据并不代表出错
    .catch((err) => {
      return false
    })
}

// 显示单条信息
const listone = (id) => {
  return dynamicModel
    .findById(id)
    .then((result) => {
      return result
    })
}

// 删除评论信息
const remove = (id) => {
  return dynamicModel
    .findByIdAndDelete(id)
    .then((result) => {
      return result
    })
}

// 修改评论信息
const update = async ({
  id,
  data
}) => {
  // 方案一
  // if (!!data.companyLogo) {
  //   return dynamicModel
  //     .findByIdAndUpdate(id, data)
  //     .then((result) => {
  //       return result
  //     })
  // } else {
  //   let {
  //     companyName,
  //     dynamicName,
  //     salary,
  //     city
  //   } = data
  //   return dynamicModel
  //     .findByIdAndUpdate(id, {
  //       companyName,
  //       dynamicName,
  //       salary,
  //       city
  //     })
  //     .then((result) => {
  //       return result
  //     })
  // }

  // 方案二
  // return dynamicModel
  //   .findByIdAndUpdate(id, data)
  //   .then((result) => {
  //     return result
  //   })

  // 方案三
  // return dynamicModel
  //   .findByIdAndUpdate(id, data)
  //   .then((result) => {
  //     return result
  //   })

  // 方案四
  return dynamicModel
    .findByIdAndUpdate(id, data)
    .then((result) => {
      return result
    })
}

module.exports = {
  list,
  listall,
  listone,
  save,
  remove,
  update
}