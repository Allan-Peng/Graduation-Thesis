<template>
  <div>theaters</div>
</template>
