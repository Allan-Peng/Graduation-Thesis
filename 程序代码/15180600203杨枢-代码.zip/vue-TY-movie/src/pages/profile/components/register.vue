<template>
    <div class="div">
        <div class="header">
            <a href="./home/profile"><img src="./img/back.png" alt="" class="back"></a>
            <span class="register">注册</span>
        </div>
        <div class="content">
            <div class="inputdiv">
                <input class="input" placeholder="请输入账号" v-model="userinfo"/>
            </div>
            <div class="inputdiv">
                <input class="input" placeholder="请输入密码" v-model="password" type="password"/>
            </div>
            <button class="login_btn" @click="register">注册</button>
        </div>
    </div>
</template>

<script>
import http from 'utils/http'
export default {
    data () {
        return {
            userinfo: null,
            password: null
        }
    },
    methods: {
        async register() {
            console.log(this.userinfo,this.password)
            let Rusult = await http({
            method: 'post',
            url: '/api/user/signup',
            params: {
                username: this.userinfo,
                password: this.password
            }
            }).then((res)=>{
                console.log(res)
            }).catch((err) => {
                console.log(err)
            })
            console.log(Rusult)
        },
    },
    mounted() {
    }
}
</script>

<style lang="stylus" scoped>
.div
    background #fff
    height 100%
.header
    height: 0.5rem;
    font-weight: 100;
    background: #e54847;
    color: #fff;
    font-size: 0.18rem;
    line-height: 0.5rem;
    text-align: center;
    z-index: 999;
.back
    position absolute;
    left .1rem;
    top .12rem
    width: .25rem;
    height: .25rem;
    vertical-align: middle;
    z-index: 1000;
.content
    margin-top 5%
.inputdiv
    border-bottom  1px solid #999
    margin 0 .1rem
.input 
    width 100%
    height .4rem
.login_btn
    margin 0 .1rem
    width 95%
    height: .45rem;
    line-height: .45rem;
    font-size: .2rem;
    background #DF2D36
    text-align center
    margin-top .14rem
    border 0
    color #fff
    border-radius .03rem
</style>
