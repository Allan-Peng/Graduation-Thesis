
/*! niewei 最后发布于： 2017-10-30 */$("body").on("click",".box-item .box-name",function(){var a=$(this);a.stop().toggleClass("active"),a.parent(".box-item").find(".box-cnt").stop().slideToggle(300)});