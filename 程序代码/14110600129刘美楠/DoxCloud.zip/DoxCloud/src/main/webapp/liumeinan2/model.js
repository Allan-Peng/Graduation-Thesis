/*! niewei 最后发布于： 2017-10-30 */
var list = "", captchaSrc1 = getUrl("login/reg/captcha");
for (var i in countryCode)list += '<li class="record clearfix">' +
    '<span class="record-country" data-code="+' + countryCode[i].code + '">' + countryCode[i].country + "</span>" +
    "</li>";
var cityLine = '<li class="model_tel"><label class="phoneCode">+86</label>' +
    '<input type="text" placeholder="请输入您的手机号码" class="lch_inp">' +
    '<span class="success" style="opacity:0;"></span>' +
    '<span class="warnin regWarning" style="opacity:0;">手机号格式错误</span>' +
    '<i class="modelcirarr">中国</i><div class="country-container">' +
    '<span class="delta-country"></span><ul class="list">' + list + "</ul>" +
    "</div></li>", reg_model = '<ul class="model_box">' + cityLine + '' +
    '<li style="position: relative"><input type="text" placeholder="请输入图形验证码" id="signin_captcha">' +
    '<img id="captchaImg" width="72" height="38" class="txyzm" src="' + captchaSrc1 + '" onclick="c_server.widget.getNewCode()">' +
    '</li><li class="model_msm"><input type="text" class="smscode" placeholder="请输入短信验证码" onfocus="$(this).val(\'\').css(\'color\',\'#000\')">' +
    '<button type="button" class="getCodeBtn" onclick="c_server.widget.sendSmsCode(\'reg\')" >获取验证码</button></li><li class="model_in model_password">' +
    '<input type="password" placeholder="设置6位以上数字或字符密码" class="pwd" onfocus="$(this).next().hide();">' +
    '<span class="warnin pwdWarning" style="opacity:0;">密码格式不正确</span></li><li class="model_in model_password">' +
    '<input type="password" placeholder="请再输入一遍密码" class="repwd" onfocus="$(this).next().hide();">' +
    '<span class="warnin repwdWarning" style="opacity:0;">两次密码不一致</span></li><li class="model_btn">' +
    '<button type="button" onclick="c_server.widget.findPwdOrRegUser(\'reg\', this)">注册</button></li>' +
    '<li class="model_link"><div style="line-height:24px;">' +
    '<input id="checkbox" style="height:18px;width:18px;vertical-align:middle;-webkit-appearance: checkbox;" type="checkbox" name="xys" checked value="fuwuzhengce" /><label>我已阅读并同意<a href="http://app.veryzhun.com/h5/service" style="line-height:24px" target="_blank"><<飞常准服务协议>></a>和<a href="http://app.veryzhun.com/h5/privacy" target="_blank" style="line-height:24px"><<隐私政策>></a></label></div><div class="pull-right">' +
    '<a href="javascript:feeyo.openModel(\'用户登录\',log_model)"class="">用户登录' +
    '</a></div></li></ul>', reg_model2 = '<ul class="model_box">' + cityLine + '' +
    '<li style="position: relative"><input type="text" placeholder="请输入图形验证码" id="signin_captcha">' +
    '<img id="captchaImg" width="72" height="38" class="txyzm" src="' + captchaSrc1 + '" onclick="c_server.widget.getNewCode()"></li>' +
    '<li class="model_msm">' +
    '<input type="text" class="smscode" placeholder="请输入短信验证码" onfocus="$(this).val(\'\').css(\'color\',\'#000\')">' +
    '<button type="button" class="getCodeBtn" onclick="c_server.widget.sendSmsCode(\'findPwd\');">获取验证码</button></li><' +
    'li class="model_in model_password"><input type="password" placeholder="设置6位以上数字或字符密码" class="pwd" onfocus="$(this).next().hide();">' +
    '<span class="warnin pwdWarning" style="opacity:0;">密码格式不正确</span></li><li class="model_in model_password">' +
    '<input type="password" placeholder="请再输入一遍密码" class="repwd" onfocus="$(this).next().hide();">' +
    '<span class="warnin repwdWarning" style="opacity:0;">两次密码不一致</span></li><li class="model_btn">' +
    '<button type="button" onclick="c_server.widget.findPwdOrRegUser(\'findPwd\', this)">确定</button></li>' +
    '<li class="model_link"><a href="javascript:feeyo.openModel(\'用户登录\',log_model)" class="pull-right">用户登录</a>' +
    '</li></ul>', log_model = '<ul class="model_box"><li class="model_in model_tel">' +
    '<input type="text" placeholder="请输入您的手机号码" class="lch_inp" style="padding-left:6px;">' +
    '<span class="success" style="opacity:0;"></span><span class="warnin regWarning" style="opacity:0;">手机号格式错误</span>' +
    '<span href="javascript:;" class="pcIcon_tip internation_tip" id="internation_tip"> ' +
    '<div class="pcIcon_tipBox" id="internationTipBox" style="display: none;"><i class="pcIcon_triangle"></i>国际用户登录</div> </span></li>' +
    ' <li class="model_in model_password"><input type="password" placeholder="请输入您的密码" class="pwd" onfocus="$(this).next().hide();">' +
    '<span class="warnin pwdWarning" style="opacity:0;max-width:200px;">设置6位以上数字或字符密码</span></li><li class="model_btn">' +
    '<button type="button" id="c_sign_btn" onclick="c_server.widget.signIn(this)">登录</button></li><li class="model_link">' +
    '<span class="pull-left" style="vertical-align: middle;line-height: 1">' +
    '<input type="checkbox" id="sevenDay" name="keepLogin" value="1" checked style="width:15px;height:15px;vertical-align: top;">' +
    '<label for="sevenDay" style="color: #9a9a9a">下次自动登录</label></span>' +
    '<a href="javascript:feeyo.openModel(\'快速注册\',reg_model)" class="pull-right">快速注册</a>' +
    '<a href="javascript:feeyo.openModel(\'重置密码\',reg_model2)" class="pull-right" style="margin-right:10px;">忘记密码</a>   </li>' +
    '</ul>', url = window.location.pathname;
if (url.indexOf("solution") >= 0)var subsrcibe_model = '<ul class="model_box subs_box"><li class="model_in mr30"><input type="text" placeholder="邮箱" id="email" onblur="validStr(\'email\')"><span class="warnin repwdWarning err-email" ></span></li><li class="model_in"><input type="text" placeholder="姓名" id="cname" onblur="validStr(\'cname\')"><span class="warnin repwdWarning err-cname" ></span></li><li class="model_in mr30"><input type="text" placeholder="电话" id="phone" onblur="validStr(\'phone\')"><span class="warnin repwdWarning err-phone" ></span></li><li class="model_in"><select id="mTradetype" onblur="validStr(\'mTradetype\')"><option value="">请选择行业</option><option value="1">商旅</option><option value="2">政府</option><option value="3">物流</option><option value="4">保险</option><option value="5">租车</option><option value="6">民航</option><option value="7">机票代理</option><option value="8">媒体</option><option value="9">地图导航</option><option value="10">软件</option><option value="11">酒店</option><option value="12">广告</option><option value="13">银行</option><option value="14">运营商</option><option value="15">学校</option><option value="16">门户网站</option><option value="17">广电系统</option><option value="18">协会</option><option value="30">其它</option></select><span class="warnin repwdWarning err-mTradetype" ></span></li><li class="model_in mr30"><input type="text" placeholder="公司" id="companyname" onblur="validStr(\'companyname\')"><span class="warnin repwdWarning err-companyname" ></span></li><li class="model_in"><input type="text" placeholder="职位" id="job" onblur="validStr(\'job\')"><span class="warnin repwdWarning err-job" ></span></li><li class="model_msm"><input type="text" id="imgcode" placeholder="请输入验证码" onblur="yzmblur(\'imgcode\')"><img  height="45" src="' + imgurl + '" id="ImgauthCode" onclick="reFreshCode()"> <span class="warnin repwdWarning err-imgcode" ></span></li><li class="model_btn"><button type="button" onclick="send_subs()" style="margin-right:30px;">确定</button><button i="close" title="取消">取消</button></li></ul>';
$("#phoneList").append(list);