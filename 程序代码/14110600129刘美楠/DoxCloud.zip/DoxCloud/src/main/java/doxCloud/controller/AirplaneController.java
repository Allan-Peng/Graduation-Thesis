package doxCloud.controller;


import doxCloud.model.Airplane;
import doxCloud.service.ManagerService;
import doxCloud.service.impl.ManagerServiceImpl;
import doxCloud.utils.BigDecimalConvert;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * 管理员管理班机信息：查询班机，添加班机，删除班机
 */
@Controller
@RequestMapping("/airplane")
public class AirplaneController extends BaseController {
	/**
	 * 查询班机信息列表
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/listAirplane",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String listAirplane(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ManagerService managerService = new ManagerServiceImpl();
		List<Airplane> airplaneList = managerService.listAllAirplane();
		request.setAttribute("airplaneList", airplaneList);
		request.setAttribute("airplaneListLength", airplaneList.size());
		
		return "AirPlaneManage.jsp";
	}

	/**
	 * 添加班机列表
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/addAirplane",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String addAirplane(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String[]> map = request.getParameterMap();
		Airplane airplane = new Airplane();
		ConvertUtils.register(new BigDecimalConvert(), Number.class);
		BeanUtils.populate(airplane, map);

		ManagerService airplaneService = new ManagerServiceImpl();
		// 通过异常判断是否添加成功
		try {
			airplaneService.addAirplane(airplane);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "添加失败，请重试！");
			return "addAirPlane.jsp";
		}
		response.sendRedirect(request.getContextPath() + "/airPlaneManage.jsp");
		//重定向
		return "";
	}

	/**
	 * 删除班机
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/delAirplane",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public String delAirplane(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int aid=Integer.parseInt(request.getParameter("aid"));
		Airplane airplane = new Airplane();
		airplane.setAid(aid);
		ManagerService airplaneService = new ManagerServiceImpl();
		airplaneService.delAirplane(airplane);
		
		response.sendRedirect(request.getContextPath() + "/airPlaneManage.jsp");
		// response.sendRedirect("airplaneManager.jsp"); 重定向
		return "";
	}

}
