package doxCloud.controller;




public class ManagerController extends BaseController {
	
}
