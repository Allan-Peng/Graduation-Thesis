package doxCloud.dao.impl;


import doxCloud.dao.FlightsDao;
import doxCloud.model.Airplane;
import doxCloud.model.Flight;
import doxCloud.model.Price;
import doxCloud.utils.DataSourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;



import java.util.List;

public class FlightsDaoImpl implements FlightsDao {
	

	@Override
	public List<Flight> getFlights(Flight flight) throws Exception {

		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "SELECT * FROM flight WHERE start_point=? AND end_point=?";
		List<Flight> list = qr.query(sql, new BeanListHandler<Flight>(Flight.class), flight.getStart_point(),flight.getEnd_point());
		
		List<Price> priceList = qr.query("select * from price", new BeanListHandler<Price>(Price.class));
		Airplane airplane=null;
		for (Flight f : list) {
			sql = "SELECT * FROM airplane WHERE aid=?";
			airplane= qr.query(sql, new BeanHandler<Airplane>(Airplane.class), f.getAid());
			airplane.setPrice(priceList);
			f.setAirplane(airplane);
		}
		return list;  
	}

	@Override
	public List<Flight> regetFlights(int  oid) throws Exception {

		
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "SELECT start_point,end_point FROM flight WHERE fid=(select fid from orders where oid=?)";
		
		return getFlights(qr.query(sql, new BeanHandler<Flight>(Flight.class), oid));
		
	}

	
	

}
