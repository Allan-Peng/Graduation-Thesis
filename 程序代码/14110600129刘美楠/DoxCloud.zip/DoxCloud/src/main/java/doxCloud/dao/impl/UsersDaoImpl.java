package doxCloud.dao.impl;

import doxCloud.dao.UsersDao;
import doxCloud.model.*;
import doxCloud.utils.DataSourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.util.List;

public class UsersDaoImpl implements UsersDao {

	/**
	 * 普通用户 1、登陆-- getUser 2、注册-- addUser 3、修改-- recharge
	 */

	@Override
	public UserInfo getUser(UserInfo userInfo) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "SELECT * FROM userinfo WHERE username=? AND passwd=?";
		return qr.query(sql, new BeanHandler<UserInfo>(UserInfo.class), userInfo.getUsername(), userInfo.getPasswd());
	}

	@Override
	public void addUser(UserInfo userInfo) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "INSERT INTO userinfo (ccid, username, passwd, name, phone, address) VALUES (?,?,?,?,?,?)";
		qr.insert(sql, new BeanHandler<UserInfo>(UserInfo.class), userInfo.getCcid(), userInfo.getUsername(),
				userInfo.getPasswd(), userInfo.getName(), userInfo.getPhone(), userInfo.getAddress());
	}

	@Override
	public void recharge(UserInfo userInfo) throws Exception {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
//		String sql = "REPLACE INTO userinfo(ccid, username, passwd, name, phone, address) VALUES (?,?,?,?,?,?) where uid=?";
		String sql = "update userinfo set ccid=?, username = ?, passwd =?, name=?, phone=?, address=? where uid = ?";
		userInfo.getUid();
		qr.update(sql,  userInfo.getCcid(), userInfo.getUsername(),
				userInfo.getPasswd(), userInfo.getName(), userInfo.getPhone(), userInfo.getAddress(),userInfo.getUid());

	}

	/**
	 * 管理员
	 */
	@Override
	public Manager getUser2(Manager manager) throws Exception {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "SELECT * FROM manager WHERE account=? AND passwd=?";
		return qr.query(sql, new BeanHandler<Manager>(Manager.class), manager.getAccount(), manager.getPasswd());
	}

	@Override
	public List<Orders> userOrder(UserInfo userInfo) throws Exception {
		// TODO Auto-generated method stub
		
		List<Orders> userOrderList =null;
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "SELECT * FROM orders WHERE uid=? order by oid desc ";
		
		userOrderList = qr.query(sql, new BeanListHandler<Orders>(Orders.class),userInfo.getUid());
		
		Flight flight = null;
		for (Orders o : userOrderList) {
			flight = qr.query("SELECT * FROM flight WHERE fid=?", new BeanHandler<Flight>(Flight.class), o.getFid());
			o.setFlight(flight);
		}
		Price price = null;
		for (Orders p : userOrderList) {
			price = qr.query("SELECT * FROM price WHERE pid=?", new BeanHandler<Price>(Price.class), p.getPid());
			p.setPrice(price);
		}
		return userOrderList;
	}

	@Override
	public void cancelOrder(Orders orders) throws Exception {
		// TODO Auto-generated method stub
		
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
//		String sql = "delete from orders where oid=?";
		String sql = "update orders set status=3 where oid=?";
		qr.update(sql, orders.getOid());

		String sql2 = "select * from orders where oid = ?";
		Orders orders1 = qr.query(sql2, new BeanHandler<Orders>(Orders.class),orders.getOid());
		String sql4 = "select * from flight where fid = ? ";
		Flight flight = qr.query(sql4, new BeanHandler<Flight>(Flight.class), orders1.getFid());
		if (orders1.getPid() == 1){
			String sql3 = "update airplane set f_class_cnt = f_class_cnt+1 where aid = ?";
			qr.update(sql3,flight.getAid());

		}else if(orders1.getPid() == 4){

			String sql3 = "update airplane set b_class_cnt = b_class_cnt+1 where aid = ?";
			qr.update(sql3,flight.getAid());
		}
		else if(orders1.getPid() == 5){
			String sql3 = "update airplane set e_class_cnt = e_class_cnt+1 where aid = ?";
			qr.update(sql3,flight.getAid());

		}




	}

	@Override
	public void addOrder(Orders orders) throws Exception {
		// TODO Auto-generated method stub
		 QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
	        String sql="INSERT INTO orders ( status,  fid, pid, prices, uid, days) VALUES (?,?,?,?,?,?)";
	        qr.insert(sql,new BeanHandler<Orders>(Orders.class),orders.getStatus(),orders.getFid(),orders.getPid(),
	        		orders.getPrices(),orders.getUid(),orders.getDays());
		String sql2 = "select * from flight where fid = ? ";
		Flight flight = qr.query(sql2, new BeanHandler<Flight>(Flight.class), orders.getFid());
		if (orders.getPid() == 1){
			String sql3 = "update airplane set f_class_cnt = f_class_cnt-1 where aid = ?";
			qr.update(sql3,flight.getAid());

		}else if(orders.getPid() == 4){

			String sql3 = "update airplane set b_class_cnt = b_class_cnt-1 where aid = ?";
			qr.update(sql3,flight.getAid());
		}
		else if(orders.getPid() == 5){
			String sql3 = "update airplane set e_class_cnt = e_class_cnt-1 where aid = ?";
			qr.update(sql3,flight.getAid());

		}







	}

	@Override
	public void reOrder(Orders orders) throws Exception {
		// TODO Auto-generated method stub
		 QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
	        String sql="INSERT INTO orders ( status,  fid, pid, prices, uid, days) VALUES (?,?,?,?,?,?)";
	        qr.update("update orders set status = 2 where oid =?",orders.getOid());
	        qr.insert(sql,new BeanHandler<Orders>(Orders.class),orders.getStatus(),orders.getFid(),orders.getPid(),
	        		orders.getPrices(),orders.getUid(),orders.getDays());



		String sql2 = "select * from orders where oid = ?";
		Orders orders1 = qr.query(sql2, new BeanHandler<Orders>(Orders.class),orders.getOid());


		String sql4 = "select * from flight where fid = ? ";
		Flight flight = qr.query(sql4, new BeanHandler<Flight>(Flight.class), orders1.getFid());
		if (orders1.getPid() == 1){
			String sql3 = "update airplane set f_class_cnt = f_class_cnt+1 where aid = ?";
			qr.update(sql3,flight.getAid());

		}else if(orders1.getPid() == 4){

			String sql3 = "update airplane set b_class_cnt = b_class_cnt+1 where aid = ?";
			qr.update(sql3,flight.getAid());
		}
		else if(orders1.getPid() == 5){
			String sql3 = "update airplane set e_class_cnt = e_class_cnt+1 where aid = ?";
			qr.update(sql3,flight.getAid());

		}


		String sql5 = "select * from flight where fid = ? ";
		Flight flight1 = qr.query(sql5, new BeanHandler<Flight>(Flight.class), orders.getFid());
		if (orders.getPid() == 1){
			String sql3 = "update airplane set f_class_cnt = f_class_cnt-1 where aid = ?";
			qr.update(sql3,flight1.getAid());

		}else if(orders.getPid() == 4){

			String sql3 = "update airplane set b_class_cnt = b_class_cnt-1 where aid = ?";
			qr.update(sql3,flight1.getAid());
		}
		else if(orders.getPid() == 5){
			String sql3 = "update airplane set e_class_cnt = e_class_cnt-1 where aid = ?";
			qr.update(sql3,flight1.getAid());

		}










	        
	        
	}

	@Override
	public void payOrder(Orders orders) throws Exception {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		qr.update("update orders set status = 0 where oid = ?",orders.getOid());
		
		
	}

	

}
