package doxCloud.controller;


import doxCloud.model.*;
import doxCloud.service.FlightService;
import doxCloud.service.ManagerService;
import doxCloud.service.PriceService;
import doxCloud.service.UserService;
import doxCloud.service.impl.FlightServiceImpl;
import doxCloud.service.impl.ManagerServiceImpl;
import doxCloud.service.impl.PriceServiceImpl;
import doxCloud.service.impl.UserServiceImpl;
import doxCloud.utils.BigDecimalConvert;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/order")
public class OrderController extends BaseController {
	/**
	 * 查询所有的订单信息
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/listAllOrder",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String listAllOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//创建service对象
		ManagerService managerService = new ManagerServiceImpl();
		//查询所有订单信息
		List<Orders> orderList = managerService.listAllOrder();

		request.setAttribute("orderList", orderList);
		request.setAttribute("orderListLength", orderList.size());
		return "orderManage.jsp";// 转发
	}

	@RequestMapping(value = "/userOrder",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public String userOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {

		HttpSession userSession = request.getSession();
		UserInfo userInfo = (UserInfo) userSession.getAttribute("userInfo");
		List<Orders> userOrderList = null;
		UserService userService = new UserServiceImpl();
		//查询用户的订单信息
		userOrderList = userService.userOrder(userInfo);
		request.setAttribute("userOrderList", userOrderList);
		request.setAttribute("userOrderListLength", userOrderList.size());
		return "order.jsp";// 转发
	}

	/**
	 * 取消订单
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/cancelOrder",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public String cancelOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {

		Manager manager = (Manager) request.getSession().getAttribute("manager");

		int oid = Integer.parseInt(request.getParameter("oid"));
		int id = Integer.parseInt(request.getParameter("id"));
		Orders orders = new Orders();
		orders.setOid(oid);

		UserService userService = new UserServiceImpl();
		userService.cancelOrder(orders);

		HttpSession userSession = request.getSession();
		UserInfo userInfo = (UserInfo) userSession.getAttribute("userInfo");

		if (id == 0 && manager != null) {
			response.sendRedirect(request.getContextPath() + "/orderManage.jsp");
		} else {
			List<Orders> userOrderList = null;
			userOrderList = userService.userOrder(userInfo);
			request.setAttribute("userOrderList", userOrderList);
			request.setAttribute("userOrderListLength", userOrderList.size());
			return "order.jsp";// 转发地址
		}
		return "";// 转发地址
	}

	/**
	 * 添加订单
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/addOrder",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String addOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String[]> map = request.getParameterMap();
		Orders order = new Orders();
		ConvertUtils.register(new BigDecimalConvert(), Number.class);
		BeanUtils.populate(order, map);

		UserInfo userInfo = (UserInfo) request.getSession().getAttribute("userInfo");

		UserService orderService = new UserServiceImpl();
		order.setUid(userInfo.getUid());
		order.setStatus(1);
		System.out.println(order);
		orderService.addOrder(order);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().print(200);
		return "";
	}

	@RequestMapping(value = "/payOrder",method = RequestMethod.GET,produces = "application/json; charset=utf-8")

	public String payOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int oid=Integer.parseInt(request.getParameter("oid"));

		UserService userService = new UserServiceImpl();
		Orders order = new Orders();
		order.setOid(oid);
		userService.payOrder(order);

		HttpSession userSession = request.getSession();
		UserInfo userInfo = (UserInfo) userSession.getAttribute("userInfo");
		List<Orders> userOrderList = null;

		userOrderList = userService.userOrder(userInfo);
		request.setAttribute("userOrderList", userOrderList);
		request.setAttribute("userOrderListLength", userOrderList.size());

		return"order.jsp";
	}

	// 改签-1、查询后返回航班  2、改签航班
	@RequestMapping(value = "/reOrder",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public String reOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String method = request.getMethod();
		String flage = request.getParameter("flage");
		System.out.print(flage);
		if (flage.equals("1")) {
			System.out.print(method);
			int oid = Integer.parseInt(request.getParameter("oid"));
			String days = request.getParameter("days");
			//查询fid
			FlightService flightService = new FlightServiceImpl();
			List<Flight> flights = flightService.regetFlights(oid);
			
			/*FlightService flightService = new FlightServiceImpl();
			List<Flight> flights = flightService.getFlights(flight);*/
			PriceService priceService = new PriceServiceImpl();
			List<Price> allPrices = priceService.getAllPrices();
			request.setAttribute("days", days);
			request.setAttribute("flight", flights);
			
			return "reOrder.jsp";
			
		} else {
			Map<String, String[]> map = request.getParameterMap();
//			System.out.print(request.getParameter("oid"));
			
			Orders order = new Orders();
			ConvertUtils.register(new BigDecimalConvert(), Number.class);
			BeanUtils.populate(order, map);

			UserInfo userInfo = (UserInfo) request.getSession().getAttribute("userInfo");

			UserService orderService = new UserServiceImpl();
			order.setUid(userInfo.getUid());
			order.setStatus(4);
			
			System.out.println(order);
			
			orderService.reOrder(order);
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(200);
			return "";
		}

	}

}
