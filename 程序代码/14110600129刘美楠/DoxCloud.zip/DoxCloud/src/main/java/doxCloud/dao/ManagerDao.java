package doxCloud.dao;


import doxCloud.model.Airplane;
import doxCloud.model.Flight;
import doxCloud.model.Orders;
import doxCloud.model.UserInfo;

import java.util.List;

/**
 * 后台管理的dao接口
 */
public interface ManagerDao {
    //查询用户
    public List<UserInfo> queryUsers() throws Exception;

    //查寻客机
    public List<Airplane> queryAirplane() throws Exception;

    //查询航班
    public List<Flight> queryFlight() throws Exception;

    //查询订单信息
    public List<Orders> queryOrder() throws Exception;

    //添加客机信息
    public void addAirplane(Airplane airplane) throws Exception;

    //删除客机信息
    public void delAirplane(Airplane airplane) throws Exception;

    //添加航班
    public void addFlight(Flight flight) throws Exception;

    //修改航班
    public void updateflight(Flight flight) throws Exception;

    //删除航班
    public void delflight(Flight flight) throws Exception;
}
