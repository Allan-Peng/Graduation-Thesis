package doxCloud.service;

import doxCloud.model.*;

import java.util.List;

public interface PriceService {
	public List<Price> getAllPrices() throws Exception;

}
