package doxCloud.dao;

import doxCloud.model.*;

import java.util.List;

public interface PriceDao {
	List<Price> getAllPrices() throws Exception;

}
