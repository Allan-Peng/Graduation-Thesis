package doxCloud.service.impl;

import doxCloud.dao.impl.PriceDaoImpl;
import doxCloud.model.*;
import doxCloud.service.PriceService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service("PriceService")
public class PriceServiceImpl implements PriceService {

	@Override
	public List<Price> getAllPrices() throws Exception {
		// TODO Auto-generated method stub
		return new PriceDaoImpl().getAllPrices();
	}

}
