package doxCloud.controller;


import doxCloud.model.Flight;
import doxCloud.model.Manager;
import doxCloud.model.UserInfo;
import doxCloud.service.FlightService;
import doxCloud.service.UserService;
import doxCloud.service.impl.FlightServiceImpl;
import doxCloud.service.impl.UserServiceImpl;
import doxCloud.utils.DataConvert;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 功能：用户，管理员注册，登录，退出
 */
@Controller
@RequestMapping("/user")
public class UserController extends BaseController {

	/**
	 * 用户注册
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/register",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String register(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// 使用map接收前台传入的所有参数
		Map<String, String[]> map = request.getParameterMap();
		// 注册时间转换器（前台日期是string类型，BeanUtils无法直接封装，需要转换）
		ConvertUtils.register(new DataConvert(), Date.class);
		UserInfo userInfo = new UserInfo();
		// 使用BeanUtils的populate把接收的map封装到userinfo对象中
		BeanUtils.populate(userInfo, map);
		UserService userService = new UserServiceImpl();
		// 通过异常判断是否添加成功
		try {
			userService.addUser(userInfo);
			request.setAttribute("result","注册成功");
			request.setAttribute("href", request.getContextPath() + "/index.jsp");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "注册失败，请重试！");
			return "register.jsp";
		}
		//response.sendRedirect(request.getContextPath() + "/index.jsp");
		// response.sendRedirect(); 重定向
		return "result.jsp";
	}

	public String loginUI(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return "login.jsp";
	}

	/**
	 * 普通用户登录
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/login",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String login(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//使用map接收前台的数据
		Map<String, String[]> map = request.getParameterMap();

		UserInfo userInfo = new UserInfo();
		// 使用BeanUtils的populate把接收的map封装到userinfo对象中
		BeanUtils.populate(userInfo, map);
		UserService usersService = new UserServiceImpl();
		//获取user用户
		UserInfo user = usersService.getUser(userInfo);

		String flage = request.getParameter("flage");
		String days = request.getParameter("days");
		Flight flight = new Flight();
		BeanUtils.populate(flight, map);
		FlightService flightService = new FlightServiceImpl();
		List<Flight> flights = flightService.getFlights(flight);
		request.setAttribute("flight", flights);
		request.setAttribute("flightLength", flights.size());
		request.setAttribute("days", days);

		if (user != null) {
			request.getSession().setAttribute("userInfo", user);
			if (flage.equals("0")){
				return "index.jsp";
			}else {
				return "queryFlight.jsp";
			}

		}else {
			request.setAttribute("error", "用户或密码不正确！");
			if (flage.equals("0")){
				return "index.jsp";
			}else {
				return "queryFlight.jsp";
			}

		}

	}

	/**
	 * 更新用户
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateUser",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String updateUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String[]> map = request.getParameterMap();
		UserInfo userInfo = new UserInfo();
		BeanUtils.populate(userInfo, map);
		UserService userService = new UserServiceImpl();
		try {
			userService.recharge(userInfo);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "修改失败，请重试！");
			return "updateUser.jsp";
		}
		request.getSession().invalidate();
		request.setAttribute("success", "修改成功！");
		request.getSession().setAttribute("userInfo", userInfo);
		
		response.sendRedirect(request.getContextPath() + "/updateUser.jsp");
		return "";
	}

	/**
	 * 管理员登录
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/login2",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String login2(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String[]> map = request.getParameterMap();

		Manager managerForm = new Manager();
		BeanUtils.populate(managerForm, map);
		UserService usersService = new UserServiceImpl();
		//获取管理员用户
		Manager manager = usersService.getUser2(managerForm);

		if (manager != null) {
			request.getSession().setAttribute("manager", manager);
			response.sendRedirect(request.getContextPath() + "/manager.jsp");
			return "";
		}
		request.setAttribute("error", "用户或密码不正确！");
		return "login2.jsp";
	}

	/**
	 * 退出，返回到首页
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/signOut",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public String signOut(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//清除session信息
		request.getSession().invalidate();
	//	response.sendRedirect(request.getContextPath() + "/index.jsp");
		return "index.jsp";
	}



}
