package doxCloud.service.impl;

import doxCloud.dao.impl.FlightsDaoImpl;
import doxCloud.model.*;
import doxCloud.service.FlightService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("FlightService")
public class FlightServiceImpl implements FlightService {

	@Override
	public List<Flight> getFlights(Flight filght) throws Exception {
		// TODO Auto-generated method stub
		 return new FlightsDaoImpl().getFlights(filght);
	}

	@Override
	public List<Flight> regetFlights(int oid) throws Exception {
		// TODO Auto-generated method stub
		return new FlightsDaoImpl().regetFlights(oid);
	}

	

	

}
