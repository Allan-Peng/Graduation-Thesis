package doxCloud.controller;


import doxCloud.model.Flight;
import doxCloud.model.Price;
import doxCloud.service.FlightService;
import doxCloud.service.ManagerService;
import doxCloud.service.PriceService;
import doxCloud.service.impl.FlightServiceImpl;
import doxCloud.service.impl.ManagerServiceImpl;
import doxCloud.service.impl.PriceServiceImpl;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/flights")
public class FlightController extends BaseController {

	// 查询航班信息
	@RequestMapping(value = "/getFlights",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String getFlights(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String start_point = request.getParameter("start_point");
		String end_point = request.getParameter("end_point");
		String flage = request.getParameter("flage");

		if (start_point.equals(end_point)) {
			request.setAttribute("error1", "出发地和目的地不能相同");
			if (flage.equals("0")){
				return "index.jsp";// 转发
			}else {
				return "queryFlight.jsp";// 转发
			}

		}

		String days = request.getParameter("days");
		Map<String, String[]> map = request.getParameterMap();
		System.out.print("asdasd" + days);
		// ConvertUtils.register(new TimeConvert(), java.sql.Time.class);
		Flight flight = new Flight();
		BeanUtils.populate(flight, map);
		FlightService flightService = new FlightServiceImpl();
		List<Flight> flights = flightService.getFlights(flight);
		PriceService priceService = new PriceServiceImpl();
		List<Price> allPrices = priceService.getAllPrices();

		request.setAttribute("flight", flights);
		request.setAttribute("flightLength", flights.size());
		request.setAttribute("days", days);

		return "queryFlight.jsp";// 转发
	}

	//改签查询
	@RequestMapping(value = "/regetFlights",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String regetFlights(HttpServletRequest request, HttpServletResponse response) throws Exception {

		Map<String, String[]> map = request.getParameterMap();
		// ConvertUtils.register(new TimeConvert(), java.sql.Time.class);

		Flight flight = new Flight();
		BeanUtils.populate(flight, map);
		FlightService flightService = new FlightServiceImpl();
		List<Flight> flights = flightService.getFlights(flight);
		PriceService priceService = new PriceServiceImpl();
		List<Price> allPrices = priceService.getAllPrices();

		request.setAttribute("flight", flights);
		return "reOrder.jsp";// 转发
	}

	// 查询所有航班
	@RequestMapping(value = "/getAllFlight",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String getAllFlight(HttpServletRequest request, HttpServletResponse response) throws Exception {

		ManagerService managerService = new ManagerServiceImpl();
		List<Flight> flightList = managerService.listAllFlight();
		request.setAttribute("flightList", flightList);
		// request.setAttribute("flightListLength", flightList.size());
		return "flightManage.jsp";// 转发
	}

	// 新增航班
	@RequestMapping(value = "/addFlight",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String addFlight(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String[]> map = request.getParameterMap();
		// ConvertUtils.register(new TimeConvert(), java.sql.Time.class);
		Flight flight = new Flight();
		BeanUtils.populate(flight, map);

		ManagerService flightService = new ManagerServiceImpl();
		// 通过异常判断是否添加成功
		try {
			flightService.addFlight(flight);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "添加失败，请重试！");
			return "addAirPlane.jsp";
		}
		response.sendRedirect(request.getContextPath() + "/flightManage.jsp");
		// response.sendRedirect("airplaneManager.jsp"); 重定向

		return "";
	}

	// 更新航班
	@RequestMapping(value = "/updateFlight",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public String updateFlight(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String[]> map = request.getParameterMap();
		Flight flight = new Flight();
		BeanUtils.populate(flight, map);

		ManagerService flightService = new ManagerServiceImpl();

		try {
			flightService.updateFlight(flight);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "修改失败，请重试！");
			return "updateUser.jsp";
		}

		response.sendRedirect(request.getContextPath() + "/flightManage.jsp");
		return "";
	}

	// 删除航班
	@RequestMapping(value = "/delFlight",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	public String delFlight(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int fid = Integer.parseInt(request.getParameter("fid"));
		Flight flight = new Flight();
		flight.setFid(fid);
		ManagerService flightService = new ManagerServiceImpl();
		flightService.delFlight(flight);

		response.sendRedirect(request.getContextPath() + "/flightManage.jsp");
		return "";
	}

}
