package doxCloud.dao;



import doxCloud.model.Flight;

import java.util.List;

//航班信息
public interface FlightsDao {

	List<Flight> getFlights(Flight flight) throws Exception;
	
	
	List<Flight> regetFlights(int oid) throws Exception;
	
}
