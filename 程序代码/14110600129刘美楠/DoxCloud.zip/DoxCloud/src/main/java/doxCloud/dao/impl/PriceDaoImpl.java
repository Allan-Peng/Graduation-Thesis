package doxCloud.dao.impl;


import doxCloud.dao.PriceDao;
import doxCloud.utils.DataSourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import doxCloud.model.*;

import java.util.List;

public class PriceDaoImpl implements PriceDao {

	@Override
	public List<Price> getAllPrices() throws Exception {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from price";
		List<Price> list = qr.query(sql, new BeanListHandler<Price>(Price.class));
		return list;
		

	}
}
