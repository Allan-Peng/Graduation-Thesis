package com.f22pkj31.provider.service;

import com.f22pkj31.community.entity.PostCollection;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author f22pkj31
 * @since 2019-03-16
 */
public interface IPostCollectionService extends IService<PostCollection> {

}
