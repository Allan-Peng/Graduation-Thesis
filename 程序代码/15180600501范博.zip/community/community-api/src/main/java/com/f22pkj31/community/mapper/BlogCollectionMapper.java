package com.f22pkj31.community.mapper;

import com.f22pkj31.community.entity.BlogCollection;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author f22pkj31
 * @since 2019-03-24
 */
public interface BlogCollectionMapper extends BaseMapper<BlogCollection> {

}
