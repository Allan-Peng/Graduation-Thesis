package com.ershou.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ershou.dao.DB;
import com.ershou.entity.User;

public class UserServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public UserServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String uri = request.getServletPath();

		uri = uri.substring(1, uri.lastIndexOf('.'));

		if (uri.equals("login")) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			List<Object> list = new ArrayList<Object>();
			list.add(username);
			list.add(password);
			User user = new DB()
					.getUser(
							"SELECT * FROM USER WHERE USERNAME=? AND PASSWORD=? AND TYPE=0",
							list);

			if (user != null) {
				request.getSession().setAttribute("user", user);
				response.sendRedirect("person.UserServlet");
			} else {
				request.setAttribute("message", "登陆失败，用户名或密码错误");
				request.getRequestDispatcher("login.jsp").forward(request,
						response);
			}

		} else if (uri.equals("register")) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String checkPwd = request.getParameter("checkPwd");
			if(!password.equals(checkPwd)){
				request.setAttribute("message", "密码和确认密码不一致！");
				request.getRequestDispatcher("register.jsp").forward(request,
						response);
				return;
			}
			List<Object> list = new ArrayList<Object>();
			list.add(username);
			User user = new DB().getUser("SELECT * FROM USER WHERE USERNAME=?",
					list);
			if (user == null) {
				list.add(password);
				int result = new DB()
						.ExecuteSql(
								"INSERT INTO USER(USERNAME,PASSWORD,TYPE) VALUES(?,?,0)",
								list);
				if (result >= 1) {
					request.setAttribute("message", "注册成功！");
					request.getRequestDispatcher("login.jsp").forward(request,
							response);
				} else {
					request.setAttribute("message", "注册失败，未知错误！");
					request.getRequestDispatcher("register.jsp").forward(
							request, response);
				}
			} else {
				request.setAttribute("message", "注册失败，该用户已存在！");
				request.getRequestDispatcher("register.jsp").forward(request,
						response);
			}
		}else if(uri.equals("logout")){
			request.getSession().setAttribute("user", null);
			request.setAttribute("message", "注销成功！");
			request.getRequestDispatcher("login.jsp").forward(request,
					response);
		}else if(uri.equals("person")){
			
			if(request.getSession().getAttribute("user")==null){
				request.setAttribute("message", "请登录");
				request.getRequestDispatcher("login.jsp").forward(request, response);
				return;
			}
			
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				request.setAttribute("message", request.getParameter("message"));
			}
			
			request.getRequestDispatcher("person.jsp").forward(request, response);
		}else if(uri.equals("editPerson")){
			if(request.getSession().getAttribute("user")==null){
				request.setAttribute("message", "请登录");
				request.getRequestDispatcher("login.jsp").forward(request, response);
				return;
			}
			
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
			
			}
			
			request.getRequestDispatcher("editPerson.jsp").forward(request, response);
		}else if(uri.equals("editPersons")){
			if(request.getSession().getAttribute("user")==null){
				request.setAttribute("message", "请登录");
				request.getRequestDispatcher("login.jsp").forward(request, response);
				return;
			}
			
			
			String love = request.getParameter("love");
			String content = request.getParameter("content");
			String address = request.getParameter("address");
			
			User user = (User)request.getSession().getAttribute("user");
			String sql = "UPDATE USER SET LOVE=?,CONTENT=?,ADDRESS = ?  WHERE ID=?";
			List<Object> params = new ArrayList<Object>();
			params.add(love);
			params.add(content);
			params.add(address);
			params.add(user.getId());
			
			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = null;
			if(result>=1){
				temp= java.net.URLEncoder.encode("修改成功","UTF-8"); 
				
				user = db.getUser("SELECT * FROM USER WHERE ID="+user.getId(), null);
				request.getSession().setAttribute("user", user);
			}else{
				temp= java.net.URLEncoder.encode("修改失败","UTF-8"); 
				
			}
		
			response.sendRedirect("editPerson.UserServlet?message="+temp);
			
		}else if(uri.equals("editImages")){
			if(request.getSession().getAttribute("user")==null){
				request.setAttribute("message", "请登录");
				request.getRequestDispatcher("login.jsp").forward(request, response);
				return;
			}
			
			String images = request.getParameter("images");

			
			User user = (User)request.getSession().getAttribute("user");
			String sql = "UPDATE USER SET IMAGES=? WHERE ID=?";
			List<Object> params = new ArrayList<Object>();
			
			params.add(images);
			params.add(user.getId());
			
			DB db = new DB();
			db.ExecuteSql(sql, params);
			user = db.getUser("SELECT * FROM USER WHERE ID="+user.getId(), null);
			request.getSession().setAttribute("user", user);
		
			response.sendRedirect("person.UserServlet");
			
		}

	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
