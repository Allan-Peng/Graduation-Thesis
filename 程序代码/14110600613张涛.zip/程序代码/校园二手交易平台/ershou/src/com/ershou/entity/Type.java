package com.ershou.entity;

import java.util.ArrayList;
import java.util.List;

public class Type {
	
	private int id;
	private String typeName;
	private int parentId;
	private String parentName;
	private List<Type> lst = new ArrayList<Type>();
	private String images;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public List<Type> getLst() {
		return lst;
	}
	public void setLst(List<Type> lst) {
		this.lst = lst;
	}
	public String getImages() {
		return images;
	}
	public void setImages(String images) {
		this.images = images;
	}
	
	
	
}
