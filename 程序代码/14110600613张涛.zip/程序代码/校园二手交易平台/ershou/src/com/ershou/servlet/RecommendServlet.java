package com.ershou.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ershou.dao.DB;
import com.ershou.entity.Good;
import com.ershou.entity.Recommend;

public class RecommendServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public RecommendServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String uri = request.getServletPath();

		uri = uri.substring(7, uri.lastIndexOf('.'));
		if(uri.equals("list")){
			String sql = "SELECT * FROM RECOMMEND";
			List<Recommend> lsr = new DB().getRecommendList(sql, null);
			
			request.setAttribute("lsr", lsr);
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			
			request.getRequestDispatcher("recommendList.jsp").forward(request, response);
		}else if(uri.equals("edit")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			String sql = "SELECT * FROM RECOMMEND WHERE ID=?";
			DB db = new DB();
			Recommend recommend = db.getRecommend(sql, params);
			List<Good> lsg = db.getGoodList("SELECT * FROM GOOD WHERE TYPE=0", null, -1, 0);
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			request.setAttribute("lsg", lsg);
			request.setAttribute("recommend", recommend);
			request.getRequestDispatcher("editRecommend.jsp").forward(request, response);
		}else if(uri.equals("edits")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			Integer good_id = Integer.parseInt(request.getParameter("good_id"));
			
			List<Object> params = new ArrayList<Object>();
			
			params.add(good_id);
			params.add(id);
			String sql = "UPDATE RECOMMEND SET GOOD_ID=? WHERE ID=?";
			
			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if (result >= 1) {
				temp = java.net.URLEncoder.encode("修改成功", "UTF-8");

			} else {
				temp = java.net.URLEncoder.encode("修改失败", "UTF-8");

			}
			
			response.sendRedirect("edit.RecommendServlet?id="+id+"&message=" + temp);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
