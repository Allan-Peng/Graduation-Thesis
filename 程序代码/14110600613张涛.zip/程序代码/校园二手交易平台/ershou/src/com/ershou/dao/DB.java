package com.ershou.dao;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.ershou.entity.*;

public class DB {

	private String driver = "com.mysql.jdbc.Driver";

	private String url = "jdbc:mysql://localhost:3306/ershou?useUnicode=true&characterEncoding=utf-8";

	private String user = "root";

	private String password = "root";

	private Connection conn = null;

	private PreparedStatement pstmt = null;

	private ResultSet rs = null;

	public DB() {

		try {

			Class.forName(driver);

			conn = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<User> getUserList(String sql, List<Object> params) {

		List<User> lsu = new ArrayList<User>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				User u = new User();
				u.setId(rs.getInt("id"));
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				u.setType(rs.getInt("type"));
				u.setImages(rs.getString("images"));
				u.setContent(rs.getString("content"));
				u.setLove(rs.getString("love"));
				u.setAddress(rs.getString("address"));

				lsu.add(u);
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lsu;
	}

	public User getUser(String sql, List<Object> params) {

		User u = null;
		List<User> lsu = getUserList(sql, params);
		if (lsu != null && lsu.size() > 0)
			u = lsu.get(0);
		return u;
	}
	public List<Good> getGoodList(String sql, List<Object> params, int start,int size) {
		List<Good> lsg = new ArrayList<Good>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);

			if (start >= 0 && size > 0) {
				sql += " limit ?,?";
				if (params == null) {
					params = new ArrayList<Object>();
				}
				params.add(start);
				params.add(size);
			}

			pstmt = conn.prepareStatement(sql);

			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Good good = new Good();
				good.setId(rs.getInt("id"));
				good.setGoodName(rs.getString("goodName"));
				good.setImages(rs.getString("images"));
				good.setPrice(rs.getFloat("price"));
				good.setType_id(rs.getInt("type_id"));
				good.setType_name(rs.getString("type_name"));
				good.setContent(rs.getString("content"));
				good.setUser_id(rs.getInt("user_id"));
				good.setDate(rs.getDate("date"));
				good.setStatus(rs.getInt("status"));
				good.setType(rs.getInt("type"));

				lsg.add(good);
			}

			for (int i = 0; i < lsg.size(); i++) {
				lsg.get(i).setLsa(
						getAttributeList(
								"SELECT * FROM ATTRIBUTE WHERE GOOD_ID="
										+ lsg.get(i).getId(), null));

				if(lsg.get(i).getUser()==null){
					lsg.get(i).setUser(getUser("SELECT * FROM USER WHERE ID="+lsg.get(i).getUser_id(), null));
				}

			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lsg;
	}
	public List<Good> getGoodList(String sql, List<Object> params, int start,
			int size,boolean loadItem) {
		List<Good> lsg = new ArrayList<Good>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);

			if (start >= 0 && size > 0) {
				sql += " limit ?,?";
				if (params == null) {
					params = new ArrayList<Object>();
				}
				params.add(start);
				params.add(size);
			}

			pstmt = conn.prepareStatement(sql);

			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Good good = new Good();
				good.setId(rs.getInt("id"));
				good.setGoodName(rs.getString("goodName"));
				good.setImages(rs.getString("images"));
				good.setPrice(rs.getFloat("price"));
				good.setType_id(rs.getInt("type_id"));
				good.setType_name(rs.getString("type_name"));
				good.setContent(rs.getString("content"));
				good.setUser_id(rs.getInt("user_id"));
				good.setDate(rs.getDate("date"));
				good.setStatus(rs.getInt("status"));
				good.setType(rs.getInt("type"));

				lsg.add(good);
			}

			for (int i = 0; i < lsg.size(); i++) {
				lsg.get(i).setLsa(
						getAttributeList(
								"SELECT * FROM ATTRIBUTE WHERE GOOD_ID="
										+ lsg.get(i).getId(), null));
				
				if(loadItem){
					lsg.get(i).setItem(getItemList("SELECT * FROM ITEM WHERE GOOD_ID="+lsg.get(i).getId(), null).get(0));
				}
				
				if(lsg.get(i).getUser()==null){
					lsg.get(i).setUser(getUser("SELECT * FROM USER WHERE ID="+lsg.get(i).getUser_id(), null));
				}

			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lsg;
	}

	public int getPageSize(String sql, List<Object> params) {

		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);

			pstmt = conn.prepareStatement(sql);

			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			if (rs.next()) {

				return rs.getInt(1);
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}

		return 0;

	}

	public Good getGood(String sql, List<Object> params,boolean loadItem) {

		Good good = null;

		List<Good> lsg = getGoodList(sql, params, -1, 0,loadItem);
		if (lsg != null && lsg.size() > 0)
			good = lsg.get(0);
		return good;
	}

	public Good getGood(String sql, List<Object> params) {

		Good good = null;

		List<Good> lsg = getGoodList(sql, params, -1, 0);
		if (lsg != null && lsg.size() > 0)
			good = lsg.get(0);
		return good;
	}
	
	public List<Type> getTypeList(String sql, List<Object> params) {
		List<Type> lst = new ArrayList<Type>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Type type = new Type();
				type.setId(rs.getInt("id"));
				type.setTypeName(rs.getString("typeName"));
				type.setParentId(rs.getInt("parentId"));
				type.setParentName(rs.getString("parentName"));
				type.setImages(rs.getString("images"));

				lst.add(type);
			}

			for (int i = 0; i < lst.size(); i++) {
				if(lst.get(i).getParentId()==0)
				lst.get(i).setLst(
						getTypeList("SELECT * FROM TYPE WHERE PARENTID="
								+ lst.get(i).getId(), null));

			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lst;
	}

	public Type getType(String sql, List<Object> params) {

		Type type = null;

		List<Type> lst = getTypeList(sql, params);
		if (lst != null && lst.size() > 0)
			type = lst.get(0);
		return type;
	}
	
	public List<Recommend> getRecommendList(String sql, List<Object> params) {
		List<Recommend> lst = new ArrayList<Recommend>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Recommend r = new Recommend();
				r.setId(rs.getInt("id"));
				Good good = new Good();
				good.setId(rs.getInt("good_id"));
				r.setGood(good);

				lst.add(r);
			}

			for (int i = 0; i < lst.size(); i++) {

				lst.get(i).setGood(
						getGood("SELECT * FROM GOOD WHERE ID="
								+ lst.get(i).getGood().getId(), null,false));

			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lst;
	}

	public Recommend getRecommend(String sql, List<Object> params) {

		Recommend r = null;

		List<Recommend> lst = getRecommendList(sql, params);
		if (lst != null && lst.size() > 0)
			r = lst.get(0);
		return r;
	}

	public List<Attribute> getAttributeList(String sql, List<Object> params) {
		List<Attribute> lsa = new ArrayList<Attribute>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Attribute attribute = new Attribute();
				attribute.setId(rs.getInt("id"));
				attribute.setAttName(rs.getString("attName"));
				attribute.setAttValue(rs.getString("attValue"));
				attribute.setGood_id(rs.getInt("good_id"));

				lsa.add(attribute);
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lsa;
	}

	public Attribute getAttribute(String sql, List<Object> params) {

		Attribute attribute = null;
		List<Attribute> lsa = getAttributeList(sql, params);
		if (lsa != null && lsa.size() > 0)
			attribute = lsa.get(0);
		return attribute;

	}

	public List<Item> getItemList(String sql, List<Object> params) {
		List<Item> lsi = new ArrayList<Item>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Item item = new Item();
				item.setId(rs.getInt("id"));
				item.setContent(rs.getString("content"));
				item.setPhone(rs.getString("phone"));
				item.setRealname(rs.getString("realname"));
				item.setUser_id(rs.getInt("user_id"));
				item.setPay_type(rs.getInt("pay_type"));
				item.setStatus(rs.getInt("status"));
				item.setDate(rs.getDate("date"));
				item.setGood_id(rs.getInt("good_id"));
				lsi.add(item);
			}

			for (int i = 0; i < lsi.size(); i++) {
				if(lsi.get(i).getGood()==null)
				lsi.get(i).setGood(
						getGood("SELECT * FROM GOOD WHERE ID="
								+ lsi.get(i).getGood_id(), null,false));
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lsi;
	}
	public List<Collection> getCollectionList(String sql, List<Object> params) {
		List<Collection> lsi = new ArrayList<Collection>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Collection collection = new Collection();
				collection.setId(rs.getInt("id"));
				collection.setUser_id(rs.getInt("userid"));
				collection.setTime(rs.getDate("time"));
				Good good = new Good();
				good.setId(rs.getInt("good_id"));
				collection.setGood(good);
				lsi.add(collection);
			}

			for (int i = 0; i < lsi.size(); i++) {
				lsi.get(i).setGood(
						getGood("SELECT * FROM GOOD WHERE ID="
								+ lsi.get(i).getGood().getId(), null,false));
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lsi;
	}
	
	public List<Reply> getReplyList(String sql, List<Object> params) {
		List<Reply> lsi = new ArrayList<Reply>();
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			rs = pstmt.executeQuery();

			while (rs.next()) {

				Reply reply = new Reply();
				reply.setId(rs.getInt("id"));
				reply.setTime(rs.getDate("time"));
				reply.setInfomation(rs.getString("infomation"));
				Good good = new Good();
				good.setId(rs.getInt("good_id"));
				reply.setGood(good);
				User user = new User();
				user.setId(rs.getInt("user_id"));
				reply.setUser(user);
				lsi.add(reply);
			}

			for (int i = 0; i < lsi.size(); i++) {
				lsi.get(i).setGood(
						getGood("SELECT * FROM GOOD WHERE ID="
								+ lsi.get(i).getGood().getId(), null,false));
				lsi.get(i).setUser(
						getUser("SELECT * FROM User WHERE ID="
								+ lsi.get(i).getUser().getId(), null));
			}
			

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return lsi;
	}

	public int InsertGoods(Good good, String[] attName, String[] attValue,int type) {
		int result = 0;

		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			String sql = "INSERT INTO GOOD(GOODNAME,PRICE,IMAGES,CONTENT,TYPE_ID,TYPE_NAME,USER_ID,DATE,TYPE) VALUES(?,?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			List<Object> params = new ArrayList<Object>();
			params.add(good.getGoodName());
			params.add(good.getPrice());
			params.add(good.getImages());
			params.add(good.getContent());
			params.add(good.getType_id());
			params.add(good.getType_name());
			params.add(good.getUser_id());
			
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式

			params.add(df.format(new java.util.Date()));// new Date()为获取当前系统时间
			params.add(type);
			for (int i = 0; i < params.size(); i++) {

				pstmt.setObject(i + 1, params.get(i));

			}

			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			if (rs.next())
				good.setId(rs.getInt(1));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		InsertAttribute(good.getId(), attName, attValue);

		return result;
	}

	public int InsertAttribute(int goodid, String[] attName, String[] attValue) {
		int result = 0;
		if (attName == null || attName.length <= 0)
			return 0;
		try {

			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);

			String sql = "INSERT INTO ATTRIBUTE(ATTNAME,ATTVALUE,GOOD_ID) VALUES";

			List<Object> params = new ArrayList<Object>();
			for (int i = 0; i < attName.length; i++) {

				sql += "(?,?,?)";
				if (i < attName.length - 1) {
					sql += ",";
				}
				params.add(attName[i]);
				params.add(attValue[i]);
				params.add(goodid);
			}

			pstmt = conn.prepareStatement(sql);
			for (int i = 0; i < params.size(); i++) {

				pstmt.setObject(i + 1, params.get(i));

			}

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}

		return result;
	}

	public int ExecuteSql (String sql, List<Object> params) {
		int result = 0;
		try {
			if (conn.isClosed())
				conn = DriverManager.getConnection(url, user, password);
			pstmt = conn.prepareStatement(sql);
			if (params != null)
				for (int i = 0; i < params.size(); i++) {

					pstmt.setObject(i + 1, params.get(i));

				}

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return result;
	}

	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
