package com.ershou.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ershou.dao.DB;
import com.ershou.entity.Type;
import com.ershou.entity.User;

public class AdminServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public AdminServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		request.setCharacterEncoding("UTF-8");
response.setCharacterEncoding("UTF-8");
		String uri = request.getServletPath();

		uri = uri.substring(7, uri.lastIndexOf('.'));
		if(uri.equals("login")){
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			List<Object> list = new ArrayList<Object>();
			list.add(username);
			list.add(password);
			User user = new DB()
					.getUser(
							"SELECT * FROM USER WHERE USERNAME=? AND PASSWORD=? AND TYPE=1",
							list);

			if (user != null) {
				request.getSession().setAttribute("admin", user);
				response.sendRedirect("Index.AdminServlet");
			} else {
				request.setAttribute("message", "登陆失败，用户名或密码错误");
				request.getRequestDispatcher("login.jsp").forward(request,
						response);
			}

		}else if(uri.equals("Index")){
			response.sendRedirect("List.TypeServlet");
		}else if(uri.equals("userList")){
			String sql = "SELECT * FROM USER WHERE TYPE=0";
			List<User> lsu = new DB().getUserList(sql, null);
			request.setAttribute("lsu", lsu);
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			request.getRequestDispatcher("UserList.jsp").forward(request,
					response);
		} else if (uri.equals("addUser")) {
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			request.getRequestDispatcher("addUser.jsp").forward(request,
					response);
		}else if (uri.equals("addUsers")) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			String sql = "INSERT INTO USER(USERNAME,PASSWORD,TYPE) VALUES(?,?,?)";
			List<Object> params = new ArrayList<Object>();
			params.add(username);
			params.add(password);
			params.add(0);
			

			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if (result >= 1) {
				temp = java.net.URLEncoder.encode("添加成功", "UTF-8");

			} else {
				temp = java.net.URLEncoder.encode("添加失败", "UTF-8");

			}
			
			response.sendRedirect("addUser.AdminServlet?message=" + temp);

		}else if(uri.equals("delUser")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			String sql = "DELETE FROM USER WHERE ID=?";
			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if (result >= 1) {
				temp = java.net.URLEncoder.encode("删除成功", "UTF-8");

			} else {
				temp = java.net.URLEncoder.encode("删除失败", "UTF-8");

			}
			
			response.sendRedirect("userList.AdminServlet?message=" + temp);
		}else if(uri.equals("editUser")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			String sql = "SELECT * FROM USER WHERE ID=?";
			DB db = new DB();
			User user = db.getUser(sql, params);
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			request.setAttribute("users", user);
			request.getRequestDispatcher("editUser.jsp").forward(request, response);
		}else if(uri.equals("editUsers")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			
			List<Object> params = new ArrayList<Object>();
			params.add(username);
			params.add(password);
			params.add(id);
			

			String sql = "UPDATE USER SET USERNAME=?,PASSWORD=? WHERE ID=?";
			
			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if (result >= 1) {
				temp = java.net.URLEncoder.encode("修改成功", "UTF-8");

			} else {
				temp = java.net.URLEncoder.encode("修改失败", "UTF-8");

			}
			
			response.sendRedirect("editUser.AdminServlet?id="+id+"&message=" + temp);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
