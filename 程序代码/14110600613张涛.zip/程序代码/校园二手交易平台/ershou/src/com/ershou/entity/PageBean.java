package com.ershou.entity;

public class PageBean {

	private int pageSize = 10;
	private int totalNum;
	private int totalPage;
	private int currPage;
	private int nextPage;
	private int upPage;
	
	public PageBean(int currPage,int totalNum){
		this.totalPage = (totalNum+this.pageSize-1)/this.pageSize;
		this.currPage = currPage;
		this.totalNum = totalNum;
		
		if(this.currPage<=1){
			this.currPage = 1;
			this.upPage = 1;
			this.nextPage = 2;
		}else if(this.currPage>=this.totalPage){
			this.currPage = this.totalPage;
			this.upPage = this.totalPage - 1;
			this.nextPage = this.totalPage;
		}else{
			this.upPage = this.currPage-1;
			this.nextPage = this.currPage+1;
		}
		
		
		
	}
	
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getTotalNum() {
		return totalNum;
	}
	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getCurrPage() {
		return currPage;
	}
	public void setCurrPage(int currPage) {
		this.currPage = currPage;
	}
	public int getNextPage() {
		return nextPage;
	}
	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}
	public int getUpPage() {
		return upPage;
	}
	public void setUpPage(int upPage) {
		this.upPage = upPage;
	}
	
	
}
