package com.ershou.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ershou.dao.DB;
import com.ershou.entity.Attribute;
import com.ershou.entity.Collection;
import com.ershou.entity.Good;
import com.ershou.entity.Item;
import com.ershou.entity.Reply;
import com.ershou.entity.User;

public class GoodServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public GoodServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if(request.getSession().getAttribute("user")==null){
			request.setAttribute("message", "请登录");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			return;
		}
		User user = (User)request.getSession().getAttribute("user");
		request.setCharacterEncoding("UTF-8");

		String uri = request.getServletPath();

		uri = uri.substring(1, uri.lastIndexOf('.'));

		if (uri.equals("addGood")) {
			
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
				
			}
			request.getRequestDispatcher("addGood.jsp").forward(request, response);
		}else if(uri.equals("addGoods")){
			
			String goodName = request.getParameter("goodName");
			String images = request.getParameter("images");
			Float price = Float.parseFloat(request.getParameter("price"));
			String content = request.getParameter("content");
			String[] attName = request.getParameterValues("attName");
			String[] attValue = request.getParameterValues("attValue");
			
			String goodType = request.getParameter("goodType");
			
			String[] types = goodType.split(",");
			
			Good good = new Good();
			good.setGoodName(goodName);
			good.setImages(images);
			good.setPrice(price);
			good.setType_id(Integer.parseInt(types[0]));
			good.setType_name(types[1]);
			good.setUser_id(user.getId());
			good.setContent(content);
			DB db = new DB();
			int result = db.InsertGoods(good, attName, attValue,0);
			
			String temp = null;
			if(result>=1){
				temp= java.net.URLEncoder.encode("添加成功","UTF-8"); 

			}else{
				temp= java.net.URLEncoder.encode("添加失败","UTF-8"); 

			}
		
			response.sendRedirect("addGood.GoodServlet?message="+temp);
			
			
		}else if(uri.equals("fabu")){
			
			String sql = "SELECT * FROM GOOD WHERE USER_ID=? AND TYPE=0 ORDER BY STATUS,DATE DESC";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			List<Good> lsg = db.getGoodList(sql, params, -1, 0,true);
			request.setAttribute("lsg", lsg);
			request.getRequestDispatcher("fabu.jsp").forward(request, response);
		}else if(uri.equals("chushou")){
			
			String sql = "SELECT * FROM GOOD WHERE USER_ID=? AND TYPE=0 AND STATUS=1 ORDER BY STATUS,DATE DESC";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			List<Good> lsg = db.getGoodList(sql, params, -1, 0,true);
			request.setAttribute("lsg", lsg);
			request.getRequestDispatcher("chushou.jsp").forward(request, response);
		}else if(uri.equals("item")){
			String sql = "SELECT * FROM ITEM WHERE USER_ID=? ORDER BY DATE DESC";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			List<Item> lsi = db.getItemList(sql, params);
			request.setAttribute("lsi", lsi);
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
			
			}
			request.getRequestDispatcher("item.jsp").forward(request, response);
		}else if(uri.equals("itemupdate")){
			String sql = "UPDATE item SET status=1 WHERE ID=?";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			String id = request.getParameter("id");
			params.add(id);
			int resultnum = db.ExecuteSql(sql, params);
			request.getRequestDispatcher("item.GoodServlet").forward(request, response);
		}else if(uri.equals("delGood")){
			String sql = "DELETE FROM GOOD WHERE ID=? AND USER_ID=?";
			Integer id = Integer.parseInt(request.getParameter("id"));
			List<Object> params = new ArrayList<Object>();
			DB db = new DB();
			params.add(id);
			params.add(user.getId());
			int result = db.ExecuteSql(sql, params);
			if(result>=1){
				sql = "SELECT * FROM GOOD WHERE USER_ID=? ORDER BY STATUS,DATE DESC";
				
				params = new ArrayList<Object>();
				params.add(user.getId());
				List<Good> lsg = db.getGoodList(sql, params, -1, 0);
				request.setAttribute("lsg", lsg);
				request.setAttribute("message", "删除成功");
				request.getRequestDispatcher("fabu.jsp").forward(request, response);
			}else{
				sql = "SELECT * FROM GOOD WHERE USER_ID=? ORDER BY STATUS,DATE DESC";
				
				params = new ArrayList<Object>();
				params.add(user.getId());
				List<Good> lsg = db.getGoodList(sql, params, -1, 0);
				request.setAttribute("lsg", lsg);
				request.setAttribute("message", "删除失败");
				request.getRequestDispatcher("fabu.jsp").forward(request, response);
			}
		}else if(uri.equals("editGood")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			String sql = "SELECT * FROM GOOD WHERE ID=? AND USER_ID=?";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			params.add(user.getId());
			Good good = db.getGood(sql, params);
			request.setAttribute("good", good);
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
			
			}
			request.getRequestDispatcher("editGood.jsp").forward(request, response);
		}else if(uri.equals("editGoods")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			String goodName = request.getParameter("goodName");
			String images = request.getParameter("images");
			Float price = Float.parseFloat(request.getParameter("price"));
			String content = request.getParameter("content");
			String[] attId = request.getParameterValues("attId");
			String[] attName = request.getParameterValues("attName");
			String[] attValue = request.getParameterValues("attValue");
			
			String[] attName1 = request.getParameterValues("attName1");
			String[] attValue1 = request.getParameterValues("attValue1");
			
			String goodType = request.getParameter("goodType");
			
			String[] types = goodType.split(",");
			
			Good good = new Good();
			good.setGoodName(goodName);
			good.setImages(images);
			good.setPrice(price);
			good.setType_id(Integer.parseInt(types[0]));
			good.setType_name(types[1]);
			good.setUser_id(user.getId());
			good.setContent(content);
			DB db = new DB();
			String sql = "UPDATE GOOD SET GOODNAME=?,PRICE=?,IMAGES=?,CONTENT=?,TYPE_ID=?,TYPE_NAME=? WHERE ID=?";
			List<Object> params = new ArrayList<Object>();
			params.add(goodName);
			params.add(price);
			params.add(images);
			params.add(content);
			params.add(types[0]);
			params.add(types[1]);
			params.add(id);
			int result = db.ExecuteSql(sql, params);
			
			String temp = null;
			if(result>=1){
				temp= java.net.URLEncoder.encode("修改成功","UTF-8"); 
			}else{
				temp= java.net.URLEncoder.encode("修改失败","UTF-8"); 
			}
			if (attName != null && attName.length > 0){
				
			for(int i=0;i<attName.length;i++){
				params = new ArrayList<Object>();
				sql = "UPDATE ATTRIBUTE SET ATTNAME=?,ATTVALUE=? WHERE ID=?";
				params.add(attName[i]);
				params.add(attValue[i]);
				params.add(attId[i]);
				db.ExecuteSql(sql, params);
			}
			}
			db.InsertAttribute(id, attName1, attValue1);
		
			response.sendRedirect("editGood.GoodServlet?id="+id+"&message="+temp);
		}else if(uri.equals("delAttr")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			Integer goodid = Integer.parseInt(request.getParameter("goodid"));
			String sql = "DELETE FROM ATTRIBUTE WHERE ID=?";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			int result = db.ExecuteSql(sql, params);
			String temp = null;
			if(result>=1){
				temp= java.net.URLEncoder.encode("删除成功","UTF-8"); 
				
			}else{
				temp= java.net.URLEncoder.encode("删除失败","UTF-8"); 
				
			}
			response.sendRedirect("editGood.GoodServlet?id="+goodid+"&message="+temp);
		}else if(uri.equals("buy")){
			Integer id= Integer.parseInt(request.getParameter("id"));
			DB db = new DB();
			String sql = "SELECT * FROM GOOD WHERE ID=?";
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			Good good = db.getGood(sql, params);
			request.setAttribute("good", good);
			request.getRequestDispatcher("buy.jsp").forward(request, response);
		}else if(uri.equals("buys")){
			Integer id= Integer.parseInt(request.getParameter("id"));
			DB db = new DB();
			String sql = "INSERT INTO ITEM(REALNAME,PHONE,CONTENT,GOOD_ID,USER_ID,DATE,PAY_TYPE,STATUS) VALUES(?,?,?,?,?,?,?,?)";
			List<Object> params = new ArrayList<Object>();
			params.add(request.getParameter("realname"));
			params.add(request.getParameter("phone"));
			params.add(request.getParameter("content"));
			params.add(id);
			params.add(user.getId());
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			params.add(df.format(new java.util.Date()));// new Date()为获取当前系统时间
			params.add(request.getParameter("pay_type"));
			params.add(0);
			int result = db.ExecuteSql(sql, params);
			String temp = null;
			if(result>=1){
				temp= java.net.URLEncoder.encode("购买成功","UTF-8"); 
			}else{
				temp= java.net.URLEncoder.encode("购买失败","UTF-8"); 
			}
			sql = "UPDATE GOOD SET STATUS=1 WHERE ID=?";
			params = new ArrayList<Object>();
			params.add(id);
			db.ExecuteSql(sql, params);
			response.sendRedirect("item.GoodServlet?message="+temp);
		}else if (uri.equals("qiugou")){
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
				
			}
			request.getRequestDispatcher("addQiugou.jsp").forward(request, response);
		}else if(uri.equals("qiugous")){
			String goodName = request.getParameter("goodName");
			String images = request.getParameter("images");
			Float price = Float.parseFloat(request.getParameter("price"));
			String content = request.getParameter("content");
			String[] attName = request.getParameterValues("attName");
			String[] attValue = request.getParameterValues("attValue");
			
			String goodType = request.getParameter("goodType");
			
			String[] types = goodType.split(",");
			
			Good good = new Good();
			good.setGoodName(goodName);
			good.setImages(images);
			good.setPrice(price);
			good.setType_id(Integer.parseInt(types[0]));
			good.setType_name(types[1]);
			good.setUser_id(user.getId());
			good.setContent(content);
			DB db = new DB();
			int result = db.InsertGoods(good, attName, attValue,1);
			
			String temp = null;
			if(result>=1){
				temp= java.net.URLEncoder.encode("发布成功","UTF-8"); 

			}else{
				temp= java.net.URLEncoder.encode("发布失败","UTF-8"); 

			}
		
			response.sendRedirect("qiugou.GoodServlet?message="+temp);
		}else if(uri.equals("qiugouList")){
			String sql = "SELECT * FROM GOOD WHERE USER_ID=? AND TYPE=1 ORDER BY STATUS,DATE DESC";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			List<Good> lsg = db.getGoodList(sql, params, -1, 0);
			request.setAttribute("lsg", lsg);
			request.getRequestDispatcher("qiugouList.jsp").forward(request, response);
		}else if(uri.equals("addshoucang")){

			Integer goods_id= Integer.parseInt(request.getParameter("goods_id"));
			String sql = "INSERT INTO COLLECTION(userid,good_id,time) VALUES(?,?,?)";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			params.add(goods_id);
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			params.add(df.format(new java.util.Date()));// new Date()为获取当前系统时间
			int result = db.ExecuteSql(sql, params);
			String message = null;
			if(result>=1){
				message= "收藏成功";
			}else{
				message= "收藏失败";
			}
			request.setAttribute("message", message);
			request.getRequestDispatcher("jieguo.jsp").forward(request, response);
		}else if(uri.equals("shoucangList")){

			String sql = "SELECT * FROM COLLECTION WHERE USERID=? ORDER BY time DESC";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			List<Collection> lsi = db.getCollectionList(sql, params);
			request.setAttribute("lsi", lsi);
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
			
			}
			request.getRequestDispatcher("collection.jsp").forward(request, response);
		}
		
		if(uri.equals("addhuifu")){

			String huifu= request.getParameter("huifu").toString();
			Integer goods_id= Integer.parseInt(request.getParameter("good_id"));
			String sql = "INSERT INTO reply(good_id,user_id,infomation,time) VALUES(?,?,?,?)";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(goods_id);
			params.add(user.getId());
			params.add(huifu);
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			params.add(df.format(new java.util.Date()));// new Date()为获取当前系统时间
			int result = db.ExecuteSql(sql, params);
			String message = null;
			if(result>=1){
				message= "回复成功";
			}else{
				message= "回复失败";
			}
			request.setAttribute("message", message);
			request.getRequestDispatcher("jieguo.jsp").forward(request, response);
		}else if(uri.equals("huifuList")){

			String sql = "SELECT * FROM reply WHERE USER_ID=? ORDER BY time DESC";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			List<Reply> lsi = db.getReplyList(sql, params);
			request.setAttribute("lsi", lsi);
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
			
			}
			request.getRequestDispatcher("reply.jsp").forward(request, response);
		}else if(uri.equals("addCart")){
			Integer id= Integer.parseInt(request.getParameter("id"));
			DB db = new DB();
			String sql = "INSERT INTO ITEM(REALNAME,PHONE,CONTENT,GOOD_ID,USER_ID,DATE,PAY_TYPE,STATUS) VALUES(?,?,?,?,?,?,?,?)";
			List<Object> params = new ArrayList<Object>();
			params.add(request.getParameter("realname"));
			params.add(request.getParameter("phone"));
			params.add(request.getParameter("content"));
			params.add(id);
			params.add(user.getId());
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			params.add(df.format(new java.util.Date()));// new Date()为获取当前系统时间
			params.add(3);
			params.add(0);
			int result = db.ExecuteSql(sql, params);
			String temp = null;
			if(result>=1){
				temp= java.net.URLEncoder.encode("加入购物车成功","UTF-8"); 
			}else{
				temp= java.net.URLEncoder.encode("加入购物车失败","UTF-8"); 
			}
			
			response.sendRedirect("cart.GoodServlet?message="+temp);
		}else if(uri.equals("cart")){
			String sql = "SELECT * FROM ITEM WHERE USER_ID=? AND PAY_TYPE=3 ORDER BY DATE DESC";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			List<Item> lsi = db.getItemList(sql, params);
			request.setAttribute("lsi", lsi);
			if(request.getParameter("message")!=null&&!request.getParameter("message").equals("")){
				
				request.setAttribute("message", new String(request.getParameter("message").getBytes("ISO-8859-1"),"UTF-8"));
			
			}
			request.getRequestDispatcher("cart.jsp").forward(request, response);
		}else if(uri.equals("delCart")){
			Integer id= Integer.parseInt(request.getParameter("id"));
			String sql = "DELETE FROM ITEM WHERE USER_ID=? AND ID=?";
			DB db = new DB();
			List<Object> params = new ArrayList<Object>();
			params.add(user.getId());
			params.add(id);
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if(result>=1){
				temp= java.net.URLEncoder.encode("删除成功","UTF-8"); 
			}else{
				temp= java.net.URLEncoder.encode("删除失败","UTF-8"); 
			}
			
			response.sendRedirect("cart.GoodServlet?message="+temp);
		}else if(uri.equals("cartBuy")){
			
			DB db = new DB();
			String temp = null;
			int id = 0;
			String sql = "SELECT * FROM ITEM WHERE USER_ID=? AND PAY_TYPE=3";
			List<Object> params = new ArrayList<Object>();
			List<Item> lsi = new ArrayList<Item>();
			params.add(user.getId());
			lsi = db.getItemList(sql, params);
			for(int i=0;i<lsi.size();i++){
			id = lsi.get(i).getGood().getId();
			params.clear();
			sql = "UPDATE ITEM SET REALNAME=?,PHONE=?,CONTENT=?,DATE=?,PAY_TYPE=? WHERE ID=? AND USER_ID=?";
			
			params.add(request.getParameter("realname"));
			params.add(request.getParameter("phone"));
			params.add(request.getParameter("content"));
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 设置日期格式
			params.add(df.format(new java.util.Date()));// new Date()为获取当前系统时间
			params.add(request.getParameter("pay_type"));
			params.add(id);
			params.add(user.getId());

			db.ExecuteSql(sql, params);
			params.clear();
				sql = "UPDATE GOOD SET STATUS=1 WHERE ID=?";
				params = new ArrayList<Object>();
				params.add(id);
				db.ExecuteSql(sql, params);
				
				sql = "DELETE FROM ITEM WHERE GOOD_ID=? AND PAY_TYPE=3";
				db.ExecuteSql(sql, params);
				temp= java.net.URLEncoder.encode("购买成功","UTF-8"); 
			}
			response.sendRedirect("item.GoodServlet?message="+temp);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
