package com.ershou.entity;

public class Recommend {

	private int id;
	private Good good;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Good getGood() {
		return good;
	}
	public void setGood(Good good) {
		this.good = good;
	}
	
}
