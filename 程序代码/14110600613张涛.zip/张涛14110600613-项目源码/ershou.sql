/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50145
Source Host           : localhost:3306
Source Database       : ershou

Target Server Type    : MYSQL
Target Server Version : 50145
File Encoding         : 65001

Date: 2015-05-20 11:05:11
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `attribute`
-- ----------------------------
DROP TABLE IF EXISTS `attribute`;
CREATE TABLE `attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attName` varchar(20) DEFAULT NULL,
  `attValue` varchar(20) DEFAULT NULL,
  `good_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of attribute
-- ----------------------------
INSERT INTO `attribute` VALUES ('1', '尺寸', '17寸', '1');
INSERT INTO `attribute` VALUES ('2', '重量', '5kg', '1');
INSERT INTO `attribute` VALUES ('7', '测试1', '测试11', '6');
INSERT INTO `attribute` VALUES ('13', '12', '13', '8');
INSERT INTO `attribute` VALUES ('14', 'as', 'fe', '9');
INSERT INTO `attribute` VALUES ('15', '123', '123', '10');
INSERT INTO `attribute` VALUES ('16', '尺寸', '40', '13');
INSERT INTO `attribute` VALUES ('17', '', '', '16');

-- ----------------------------
-- Table structure for `collection`
-- ----------------------------
DROP TABLE IF EXISTS `collection`;
CREATE TABLE `collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `good_id` int(11) DEFAULT NULL,
  `good_name` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of collection
-- ----------------------------
INSERT INTO `collection` VALUES ('21', '2', '10', null, null, null, '2015-04-27 23:03:56');
INSERT INTO `collection` VALUES ('22', '5', '15', null, null, null, '2015-05-20 10:44:51');

-- ----------------------------
-- Table structure for `good`
-- ----------------------------
DROP TABLE IF EXISTS `good`;
CREATE TABLE `good` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goodName` varchar(50) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `content` text,
  `type_id` int(11) DEFAULT NULL,
  `type_name` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of good
-- ----------------------------
INSERT INTO `good` VALUES ('6', '测试数据', '50', '/ershou/upload/image/20150407/20150407184350_247.png', 'sdfawertsrg', '4', '洗衣机', '2', '2015-04-07 19:05:08', '1', '0');
INSERT INTO `good` VALUES ('8', '测试1', '222', '/ershou/upload/image/20150407/20150407234832_523.png', '啊首发身份', '4', '洗衣机', '5', '2015-04-07 23:48:42', '0', '0');
INSERT INTO `good` VALUES ('9', '测试2', '123', '/ershou/upload/image/20150407/20150407234855_447.png', 'sdfsdf', '16', '苹果', '5', '2015-04-07 23:49:02', '0', '0');
INSERT INTO `good` VALUES ('10', '测试3', '123123', '/ershou/upload/image/20150407/20150407234914_553.png', '123123', '24', '自行车', '5', '2015-04-07 23:49:23', '0', '0');
INSERT INTO `good` VALUES ('11', 'sdf', '3424', '/ershou/upload/image/20150407/20150407184350_247.png', 'sewf', '1', '电器', '2', '2015-04-08 00:09:23', '0', '1');
INSERT INTO `good` VALUES ('12', '海贼王', '5000', '/ershou/upload/image/20150505/20150505170409_98.jpg', '测试', '1', '数码', '5', '2015-05-05 17:06:20', '0', '0');
INSERT INTO `good` VALUES ('13', '素雅抱枕', '30', '/ershou/upload/image/20150520/20150520103213_421.jpeg', '<p>\r\n	用了不到半年，八成新。\r\n</p>\r\n<p>\r\n	非常舒服的真丝抱枕，很漂亮很素雅。\r\n</p>\r\n<p>\r\n	有意可联系：手机：18810370510\r\n</p>\r\n<p>\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;QQ：764615462\r\n</p>', '14', '日常用品', '2', '2015-05-20 10:34:39', '0', '0');
INSERT INTO `good` VALUES ('14', '复古笔记本', '10', '/ershou/upload/image/20150520/20150520103518_72.jpeg', '<p>\r\n	买了没用过的笔记本，比较小巧精致，转手。\r\n</p>\r\n<p>\r\n	<p>\r\n		有意可联系：手机：18810370510\r\n	</p>\r\n	<p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;QQ：764615462\r\n	</p>\r\n</p>', '13', '文具', '2', '2015-05-20 10:35:50', '0', '0');
INSERT INTO `good` VALUES ('15', '索尼单反', '2000', '/ershou/upload/image/20150520/20150520103631_418.jpg', '<p>\r\n	精致小巧的一款单反，比市场价便宜了一半，适合新手用，我用了1年，现在换新的，这个出掉。\r\n</p>\r\n<p>\r\n	<p>\r\n		有意可联系：手机：18810370510\r\n	</p>\r\n	<p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;QQ：764615462\r\n	</p>\r\n</p>', '2', '单反', '2', '2015-05-20 10:37:31', '1', '0');
INSERT INTO `good` VALUES ('16', '四级词汇书', '10', '/ershou/upload/image/20150520/20150520103845_145.jpg', '<p>\r\n	四级词汇，人手必备。\r\n</p>\r\n<p>\r\n	<p>\r\n		有意可联系：手机：18810370510\r\n	</p>\r\n	<p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;QQ：764615462\r\n	</p>\r\n</p>', '27', '教材教辅', '2', '2015-05-20 10:39:09', '0', '0');
INSERT INTO `good` VALUES ('17', '自行车', '3000', '/ershou/upload/image/20150520/20150520103928_881.png', '<p>\r\n	超级炫酷的飞车，半新。\r\n</p>\r\n<p>\r\n	<p>\r\n		有意可联系：手机：18810370510\r\n	</p>\r\n	<p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;QQ：764615462\r\n	</p>\r\n</p>', '24', '自行车', '2', '2015-05-20 10:39:44', '1', '0');
INSERT INTO `good` VALUES ('18', '乌克丽丽', '300', '/ershou/upload/image/20150520/20150520104012_212.jpeg', '<p>\r\n	用了不到一年，基本新，玫瑰木的，声音很悦耳，质量不错。\r\n</p>\r\n<p>\r\n	<p>\r\n		有意可联系：手机：18810370510\r\n	</p>\r\n	<p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;QQ：764615462\r\n	</p>\r\n</p>', '11', '乐器', '2', '2015-05-20 10:40:55', '0', '0');
INSERT INTO `good` VALUES ('19', '黑色长裙', '30', '/ershou/upload/image/20150520/20150520104738_924.jpeg', '<p>\r\n	超级仙的裙子，M码，时候160-168的姑娘。\r\n</p>\r\n<p>\r\n	<p>\r\n		有意可联系：手机：18810370510\r\n	</p>\r\n	<p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;QQ：764615462\r\n	</p>\r\n</p>', '12', '衣服鞋帽', '5', '2015-05-20 10:48:10', '1', '0');

-- ----------------------------
-- Table structure for `item`
-- ----------------------------
DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `realname` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `good_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `pay_type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of item
-- ----------------------------
INSERT INTO `item` VALUES ('2', 'zxc', 'zxc', 'zxc', '6', '2', '2015-04-07 21:30:40', null, '1');
INSERT INTO `item` VALUES ('4', '果果', '1991001010', '38号楼', '17', '5', '2015-05-20 10:45:19', '1', '0');
INSERT INTO `item` VALUES ('5', '郭梦妮', '18810370510', '48号楼', '19', '2', '2015-05-20 10:48:42', '1', '0');

-- ----------------------------
-- Table structure for `recommend`
-- ----------------------------
DROP TABLE IF EXISTS `recommend`;
CREATE TABLE `recommend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `good_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of recommend
-- ----------------------------
INSERT INTO `recommend` VALUES ('1', '13');
INSERT INTO `recommend` VALUES ('2', '16');
INSERT INTO `recommend` VALUES ('3', '18');
INSERT INTO `recommend` VALUES ('4', '17');

-- ----------------------------
-- Table structure for `reply`
-- ----------------------------
DROP TABLE IF EXISTS `reply`;
CREATE TABLE `reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `good_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `infomation` varchar(2000) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reply
-- ----------------------------
INSERT INTO `reply` VALUES ('1', '10', '2', 'c', '2015-04-28 09:57:27');
INSERT INTO `reply` VALUES ('2', '9', '2', 'test', '2015-04-28 09:49:50');

-- ----------------------------
-- Table structure for `type`
-- ----------------------------
DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typeName` varchar(20) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `parentName` varchar(20) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of type
-- ----------------------------
INSERT INTO `type` VALUES ('1', '数码', '0', '无', '');
INSERT INTO `type` VALUES ('2', '单反', '1', '数码', '');
INSERT INTO `type` VALUES ('3', '游戏机', '1', '数码', '');
INSERT INTO `type` VALUES ('4', '配件', '1', '数码', '');
INSERT INTO `type` VALUES ('5', '电脑', '0', '无', '');
INSERT INTO `type` VALUES ('6', '台式机', '5', '电脑', '');
INSERT INTO `type` VALUES ('7', '笔记本', '5', '电脑', '');
INSERT INTO `type` VALUES ('8', '平板电脑', '5', '电脑', '');
INSERT INTO `type` VALUES ('9', '一体机', '5', '电脑', '');
INSERT INTO `type` VALUES ('10', '生活娱乐', '0', '无', '');
INSERT INTO `type` VALUES ('11', '乐器', '10', '生活娱乐', '');
INSERT INTO `type` VALUES ('12', '衣服鞋帽', '10', '生活娱乐', '');
INSERT INTO `type` VALUES ('13', '文具', '10', '生活娱乐', '');
INSERT INTO `type` VALUES ('14', '日常用品', '10', '生活娱乐', '');
INSERT INTO `type` VALUES ('15', '手机', '0', '无', '');
INSERT INTO `type` VALUES ('16', '苹果', '15', '手机', '');
INSERT INTO `type` VALUES ('17', '小米', '15', '手机', '');
INSERT INTO `type` VALUES ('18', '三星', '15', '手机', '');
INSERT INTO `type` VALUES ('19', '体育用品', '0', '无', '');
INSERT INTO `type` VALUES ('20', '球类', '19', '体育用品', '');
INSERT INTO `type` VALUES ('21', '瑜伽垫', '19', '体育用品', '');
INSERT INTO `type` VALUES ('22', '轮滑', '19', '体育用品', '');
INSERT INTO `type` VALUES ('23', '校园代步', '0', '无', '');
INSERT INTO `type` VALUES ('24', '自行车', '23', '校园代步', '');
INSERT INTO `type` VALUES ('25', '代步车', '23', '校园代步', '');
INSERT INTO `type` VALUES ('26', '图书', '0', '无', '');
INSERT INTO `type` VALUES ('27', '教材教辅', '26', '图书', '');
INSERT INTO `type` VALUES ('28', '课外读物', '26', '图书', '');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  `content` varchar(50) DEFAULT NULL,
  `love` varchar(50) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', 'admin', '1', null, null, null, null);
INSERT INTO `user` VALUES ('2', 'zx', 'zx', '0', '/ershou/upload/image/20150520/20150520103123_743.jpg', '你好', '音乐，游戏这些', null);
INSERT INTO `user` VALUES ('5', 'aaa1', 'aaa1', '0', '/ershou/upload/image/20150407/20150407234603_580.png', '123', '123', null);
INSERT INTO `user` VALUES ('7', '2', '2', '0', null, null, null, null);
INSERT INTO `user` VALUES ('8', 'ceshi3', '123456', '0', null, null, null, null);
