package com.ershou.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminFilter implements Filter{

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		  //把ServletRequest和ServletResponse转换成真正的类型
        HttpServletRequest req = (HttpServletRequest)request;
        HttpSession session = req.getSession();

        //由于web.xml中设置Filter过滤全部请求，可以排除不需要过滤的url
        String requestURI = req.getRequestURI();
        System.out.println(requestURI);
        if(requestURI.equals("login.jsp")||requestURI.endsWith("login.AdminServlet")){
            chain.doFilter(request, response);
            return;
        }

        //判断用户是否登录，进行页面的处理
        if(null == session.getAttribute("admin")){
            //未登录用户，重定向到登录页面
        	req.setAttribute("message", "请登录");
        	req.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        } else {
            //已登录用户，允许访问
        	chain.doFilter(request, response);
        }
		
	}

	public void init(FilterConfig arg0) throws ServletException {
		
	}

}
