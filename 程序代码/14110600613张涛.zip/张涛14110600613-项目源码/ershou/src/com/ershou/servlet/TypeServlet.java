package com.ershou.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ershou.dao.DB;
import com.ershou.entity.Type;

public class TypeServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public TypeServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		String uri = request.getServletPath();

		uri = uri.substring(7, uri.lastIndexOf('.'));

		if (uri.equals("List")) {
			String sql = "SELECT * FROM TYPE";
			List<Type> lst = new DB().getTypeList(sql, null);
			request.setAttribute("lst", lst);
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			request.getRequestDispatcher("TypeList.jsp").forward(request,
					response);
		} else if (uri.equals("add")) {
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			request.getRequestDispatcher("addType.jsp").forward(request,
					response);
		} else if (uri.equals("adds")) {
			String typeName = request.getParameter("typeName");
			String parentType = request.getParameter("parentType");
			String images = request.getParameter("images");
			String[] types = parentType.split(",");
			String sql = "INSERT INTO TYPE(TYPENAME,PARENTID,PARENTNAME,IMAGES) VALUES(?,?,?,?)";
			List<Object> params = new ArrayList<Object>();
			params.add(typeName);
			params.add(types[0]);
			params.add(types[1]);
			params.add(images);

			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if (result >= 1) {
				temp = java.net.URLEncoder.encode("添加成功", "UTF-8");

			} else {
				temp = java.net.URLEncoder.encode("添加失败", "UTF-8");

			}
			loadType();
			response.sendRedirect("add.TypeServlet?message=" + temp);

		}else if(uri.equals("del")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			String sql = "DELETE FROM TYPE WHERE ID=?";
			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if (result >= 1) {
				temp = java.net.URLEncoder.encode("删除成功", "UTF-8");

			} else {
				temp = java.net.URLEncoder.encode("删除失败", "UTF-8");

			}
			loadType();
			response.sendRedirect("List.TypeServlet?message=" + temp);
		}else if(uri.equals("edit")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			List<Object> params = new ArrayList<Object>();
			params.add(id);
			String sql = "SELECT * FROM TYPE WHERE ID=?";
			DB db = new DB();
			Type type = db.getType(sql, params);
			if (request.getParameter("message") != null
					&& !request.getParameter("message").equals("")) {

				request.setAttribute("message", new String(request
						.getParameter("message").getBytes("ISO-8859-1"),
						"UTF-8"));

			}
			request.setAttribute("type", type);
			request.getRequestDispatcher("editType.jsp").forward(request, response);
		}else if(uri.equals("edits")){
			Integer id = Integer.parseInt(request.getParameter("id"));
			String images = request.getParameter("images");
			String typeName = request.getParameter("typeName");
			String parentType = request.getParameter("parentType");
			String[] types = parentType.split(",");
			List<Object> params = new ArrayList<Object>();
			
			params.add(typeName);
			params.add(types[0]);
			params.add(types[1]);
			params.add(images);
			params.add(id);
			String sql = "UPDATE TYPE SET TYPENAME=?,PARENTID=?,PARENTNAME=?,IMAGES=? WHERE ID=?";
			
			DB db = new DB();
			int result = db.ExecuteSql(sql, params);
			String temp = "";
			if (result >= 1) {
				temp = java.net.URLEncoder.encode("修改成功", "UTF-8");

			} else {
				temp = java.net.URLEncoder.encode("修改失败", "UTF-8");

			}
			loadType();
			response.sendRedirect("edit.TypeServlet?id="+id+"&message=" + temp);
		}
	}

	
	private void loadType(){
		List<Type> lst = new DB().getTypeList(
				"SELECT * FROM TYPE WHERE PARENTID=0", null);
		ServletContext application = this.getServletContext();
		application.setAttribute("allType", lst);
		System.out.println("Type Load Success!");
	}
	
	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		loadType();
	}

}
