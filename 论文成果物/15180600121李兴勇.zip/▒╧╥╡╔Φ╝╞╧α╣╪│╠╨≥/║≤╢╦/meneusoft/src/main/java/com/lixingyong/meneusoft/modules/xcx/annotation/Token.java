package com.lixingyong.meneusoft.modules.xcx.annotation;

import java.lang.annotation.*;

/**
 * Token校验
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented

public @interface Token {
}
