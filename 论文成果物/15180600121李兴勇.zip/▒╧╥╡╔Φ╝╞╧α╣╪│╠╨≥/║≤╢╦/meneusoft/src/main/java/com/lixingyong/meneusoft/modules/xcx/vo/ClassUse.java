package com.lixingyong.meneusoft.modules.xcx.vo;

import lombok.Data;

@Data
public class ClassUse {
    private String jsm;

    private String kcm;

    private String teacher;

    private int use;

    private String classNames;
}
