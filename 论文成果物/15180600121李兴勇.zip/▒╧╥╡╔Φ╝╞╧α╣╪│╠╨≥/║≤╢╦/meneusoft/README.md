# me-neusoft-java
``````
MeNeusoft服务器代码，使用Java语言实现。SpringBoot框架

1xxxx: 系统相关错误码
2xxxx: 教务系统相关
20xxx: 成绩相关
3xxxx: 图书馆相关
4xxxx: 用户相关
5xxxx: 资讯相关
6xxxx: 一卡通相关