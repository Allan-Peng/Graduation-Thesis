# MeNeusoft
基于微信小程序的MeNeusoft，整体使用Wepy开发的大东软校园综合小程序，前端开源页面，包含诸多实用功能。
