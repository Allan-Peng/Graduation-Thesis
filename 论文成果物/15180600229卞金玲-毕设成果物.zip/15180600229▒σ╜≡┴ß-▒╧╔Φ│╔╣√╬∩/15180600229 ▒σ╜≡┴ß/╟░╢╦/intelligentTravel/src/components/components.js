import Header from './header'

var Header = {
  components: {
    './header': Header
  },
  template: Header
}
