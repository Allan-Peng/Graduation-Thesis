<template>
  <ul class="nav">
    <li v-for="(item,index) in arr" :key="index" @click="navClick(index)">
      <router-link :to="item.url">
        <i class="icon" :class="index===page?item.iconClassActive:item.iconClass"></i>
        <span :class="{active:index===page}" >{{ item.title }}</span>
      </router-link>
    </li>
  </ul>
</template>
<script>
export default {
  data () {
    return {
      page: '0',
      arr: [
        {
          title: '首页',
          url: '/home',
          iconClass: 'icon_index',
          iconClassActive: 'icon_indexActive'
        },
        {
          title: '猜你喜欢',
          url: '/recommend',
          iconClass: 'icon_recommend',
          iconClassActive: 'icon_recommendActive'
        }, {
          title: '发现',
          url: '/search',
          iconClass: 'icon_search',
          iconClassActive: 'icon_searchActive'
        }, {
          title: '个人中心',
          url: '/mine',
          iconClass: 'icon_mine',
          iconClassActive: 'icon_mineActive'
        }
      ]
    }
  },
  methods: {
    navClick: function (index) {
      this.page = index
    }
  }
}
</script>
<style>
body{
  margin: 0px !important;
}
  .nav{
    position: fixed;
    bottom: 0;
    left: 0;
    height: 55px;
    width: 100%;
    background: #fff;
    border-top: 1px solid #dcdcdc;
    padding: .12rem 0;
    margin: 0 !important;
  }
  .nav li{
    width: 25%;
    float: left;
    text-align: center;
    font-size: 14px;
    list-style-type:none;
  }
  .nav li .icon{
    display: block;
    height: 30px;
    width: 100%;
    margin: 0 auto;
  }
  .nav li .icon_index{
    background: url("../assets/icon_index.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li .icon_indexActive{
    background: url("../assets/icon_indexActive.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li .icon_recommend{
    background: url("../assets/icon_recommend.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li .icon_recommendActive{
    background: url("../assets/icon_recommendActive.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li .icon_search{
    background: url("../assets/icon_search.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li .icon_searchActive{
    background: url("../assets/icon_searchActive.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li .icon_mine{
    background: url("../assets/icon_mine.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li .icon_mineActive{
    background: url("../assets/icon_mineActive.png") no-repeat center;
    background-size: 25px 25px;
  }
  .nav li span{
    display: block;
    color: #747682;
    padding-top: 2px;
  }
  .nav li span.active{
    color: #D2A330;
  }
  a:-webkit-any-link {
    text-decoration:none;
}
</style>
