<template>
  <div>XX热销榜</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
