<template>
  <form>
    <Header title="修改个人信息"></Header>
    <span class="input-name" style="margin-top: 55px;">账号：</span><span class="input readonly">{{user.cLogin}}</span>
    <span class="input-name">用户名：</span><input v-model="user.cName" class="input"/>
    <button class="update" @click="updateInfo">确认修改</button>
  </form>
</template>

<script>
import Header from '../header.vue'
export default {
  components:{Header}, 
  data(){
    return {
      userName: '',
      user:{
        cName:''
      }
    }
  },
  mounted(){
    var that = this
    this.userName = sessionStorage.getItem('userName')
    that.$ajax.get(// 调用接口
      '/user/login?login=' + that.userName // this指data
    ).then(function (response) { // 接口返回数据
      that.user = response.data
    })
  },
  methods:{
    updateInfo() {
      var that = this
      that.$ajax.post(// 调用接口
      '/user/updateInfo',that.user // this指data
    ).then(function (response) { // 接口返回数据
      if(response.data == 1){
        sessionStorage.setItem('usercName',that.user.cName)
        that.$message({
          message: '修改成功',
          type: 'success'
        })
      }
    })
    }
  }
}
</script>

<style scoped>
.input{
  height: 40px;
  width: 80%;
  display: block;
  cursor: not-allowed !important;
  margin: 10px 10%;
}
.input-name{
  width: 80px;
  display: block;
}
.update{
  width: 80%;
  margin: 10px 10%;
  height: 40px;
  border-radius: 20px;
  border: 1px solid #e1e1e1 !important;
  background-color: #fff;
}
</style>
