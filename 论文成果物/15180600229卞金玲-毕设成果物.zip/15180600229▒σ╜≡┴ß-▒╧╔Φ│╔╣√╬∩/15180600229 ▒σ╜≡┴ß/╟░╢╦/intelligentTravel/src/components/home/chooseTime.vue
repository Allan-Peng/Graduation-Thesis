<template>
<div>
  <div class="choose-title">请选择起始时间</div>
  <div>{{destination}}</div>
  <Calendar v-on:choseDay="clickDay"></Calendar>
  <div class="choose-div">
      <button :class="active?chooseClassActive:chooseClass" @click="jumpRecommend">下一步</button>
    </div>
</div>
</template>

<script>
import Calendar from 'vue-calendar-component'
export default {
  components: {
    Calendar
  },
  data () {
    return {
      destination: this.$route.params.destination,
      startTime: '',
      stopTime: '',
      active: false,
      chooseClassActive: 'choose-class-active',
      chooseClass: 'choose-class'
    }
  },
  methods: {
    jumpRecommend () {
      this.$router.push({
        path: '/recommendInfo',
        name: 'recommendInfo',
        params: {
          destination: this.destination,
          startTime: this.startTime,
          stopTime: this.stopTime
        }
      })
      // getList()
    },
    clickDay (data) {
      if (this.startTime === '') {
        this.startTime = data
      } else if (this.stopTime === '') {
        this.stopTime = data
        this.active = true
      } else {
        if (new Date(data).getTime() <= (new Date(this.startTime).getTime() + new Date(this.stopTime).getTime()) / 2) {
          this.startTime = data
        }
        if (new Date(data).getTime() > (new Date(this.startTime).getTime() + new Date(this.stopTime).getTime()) / 2) {
          this.stopTime = data
        }
        this.active = true
      }
      console.log(this.startTime + '--' + this.stopTime)
      // 选中某天
    }
    // getList: function (date, chooseDay, isChosedDay = true) {
    //   const [markDate, markDateMore] = this.forMatArgs()
    //   this.dateTop = `${date.getFullYear()}年${date.getMonth() + 1}月`
    //   let arr = timeUtil.getMonthList(this.myDate)
    //   for (let i = 0; i < arr.length; i++) {
    //     let markClassName = ''
    //     // if(arr[i])
    //     let k = arr[i]
    //     k.chooseDay = false
    //     const nowTime = k.date
    //     const t = new Date(nowTime).getTime() / 1000
    //     // 看每一天的class
    //     for (const c of markDateMore) {
    //       if (c.date === nowTime) {
    //         markClassName = c.className || ''
    //       }
    //     }
    //     // 标记选中某些天 设置class
    //     k.markClassName = markClassName
    //     k.isMark = markDate.indexOf(nowTime) > -1
    //     // 无法选中某天
    //     k.dayHide = t < this.agoDayHide || t > this.futureDayHide
    //     if (k.isToday) {
    //       this.$emit('isToday', nowTime)
    //     }
    //     let flag = !k.dayHide && k.otherMonth === 'nowMonth'
    //     if (chooseDay && chooseDay === nowTime && flag) {
    //       this.$emit('choseDay', nowTime)
    //       this.historyChose.push(nowTime)
    //       k.chooseDay = true
    //     } else if (
    //       this.historyChose[this.historyChose.length - 1] === nowTime &&
    //       !chooseDay &&
    //       flag
    //     ) {
    //       k.chooseDay = true
    //     }
    //   }
    //   this.list = arr
    // }
  }
}
</script>

<style scoped>
.wh_content_item>.wh_isMark {
    background-color: rgb(250, 2, 237) !important;
}
.choose-title{
  font-size: 22px;
  text-align: center;
  background-color: #5aa5d3;
  color: #ffffff;
  height: 50px;
  line-height: 50px;
}
.choose-div{
  height: 50px;
  width: 100%;
  position: fixed;
  bottom: 0;
  z-index: 2;
  background-color: #ffffff;
  padding-top: 10px;
  border-top: 1px solid #e1e1e1;
}
.choose-class-active{
  color: #000000;
  background-color: #e1e1e1;
  width: 80%;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
  margin: 0 10%;
}
.choose-class{
  color: #ffffff;
  background-color: #e1e1e1;
  width: 80%;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
  margin: 0 10%;
}
.choose-input::placeholder{
  color: #acacac;
}
</style>
