<template>
  <div class="header">
    <img src="../../static/images/goBack.png" class="header-img" @click="goBack"/>
    <span class="header-text" >{{title}}</span>
  </div>
</template>

<script>
export default {
  props:["title"],
  data () {
    return {
    }
  },
  methods:{
    goBack(){
      this.$router.go(-1)
    }
  }
}
</script>

<style>
.header{
  width: 100%;
  height: 50px;
  background-color: #329fd5;
  position: fixed;
  top: 0;
  z-index: 99;
}
.header-img{
  width: 30px;
  height: 30px;
  margin: 10px;
}
.header-text{
  width: calc(100% - 50px);
  height: 50px;
  display: block;
  float: right;
  text-align: center;
  line-height: 50px;
  font-size: 18px;
  color: #fff;
}
</style>
