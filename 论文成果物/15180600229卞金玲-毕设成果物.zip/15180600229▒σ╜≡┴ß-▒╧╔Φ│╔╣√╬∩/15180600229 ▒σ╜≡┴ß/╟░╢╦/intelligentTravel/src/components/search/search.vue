<template>
  <div id="search">
    <div class="hot-div">
      <span class="hot-title">精选榜</span>
      <div class="hot">
        <div class="hot-div1" :style="{background: 'url('+cityHot[0].cImg+')'}" @click="jumpToAttraction(cityHot[0])">
          <span class="hot-span">{{cityHot[0].cName}}</span>
          <span class="dis-span">{{cityHot[0].cDiscription}}</span>
        </div>
        <div class="hot-div1" :style="{background: 'url('+cityHot[1].cImg+')'}" @click="jumpToAttraction(cityHot[1])">
          <span class="hot-span">{{cityHot[1].cName}}</span>
          <span class="dis-span">{{cityHot[1].cDiscription}}</span>
        </div>
        <div class="hot-div1" :style="{background: 'url('+cityHot[2].cImg+')'}" @click="jumpToAttraction(cityHot[2])">
          <span class="hot-span">{{cityHot[2].cName}}</span>
          <span class="dis-span">{{cityHot[2].cDiscription}}</span>
        </div>
      </div>
    </div>
    <div>
      <div class="hot-title">游记</div>
      <div v-for="note in noteList" :key="note.nNoteId" class="note-div" @click="jumpToDetail(note)">
        <div class="note-left">
        <div class="note-title">{{note.cTitle}}</div>
        <div class="note-msg">{{note.cContent}}</div>
        </div>
        <div class="note-img-div"><img :src="note.img" class="note-img"></div>
        <div>
          <span class="note-autor">{{note.autor}}</span>
          <span class="note-rating">{{note.rating}} 喜欢</span>
        </div>
      </div>
    </div>
    <foot-nav></foot-nav>
  </div>
</template>
<script src="//cdn.bootcss.com/vue/2.1.0/vue.js" type="text/javascript" charset="utf-8"></script>
<script src="//cdn.bootcss.com/vue-resource/1.0.3/vue-resource.js" type="text/javascript" charset="utf-8"></script>
<script>
import footNav from '../foot-nav.vue'
import attractionListVue from './attractionList.vue';
export default {
  components: {
    footNav
  },
  data () {
    return {
      cityHot:[
        {
          cName: '',
          cDiscription: ''
        },
        {
          cName: '',
          cDiscription: ''
        },{
          cName: '',
          cDiscription: ''
        }
      ],
      noteList: []
    }
  },
  mounted(){
      var that = this;
      that.$ajax.get(//调用接口
        '/travelNote/getTravelNotes',//this指data
      ).then(function(response){  //接口返回数据
        that.noteList=response.data;
      })
      that.$ajax.get(//调用接口
        '/attraction/getAttractions?pageNo=1&pageSize=3',//this指data
      ).then(function(response){  //接口返回数据
        that.cityHot=response.data;
        for(var i=0;i<that.cityHot.length;i++){
        if(that.cityHot[i].cDiscription===null){
          that.cityHot[i].cDiscription = '强烈推荐'
        }
        if(that.cityHot[i].cImg===null){
          that.cityHot[i].cImg = '../../../static/images/search-city0.jpg'
        }
      }
      })
  },
  methods: {
    jumpToDetail: function (note) {
      this.$router.push(
        {
          name: 'noteDetail',
          query: {
            noteId: note.nNoteId
          }
        }
      )
    },
    jumpToAttraction: function (cityHot) {
      // this.$router.push({
      //   name: 'attractionList',
      //   params: cityHot
      // })
      this.$router.push({
        name: 'recomDetail',
        query: {
          attrId: cityHot.nId
        }
      })
    }
  }
}
</script>

<style scoped>
/* #app{
  font-family: "楷体","楷体_GB2312";
} */
#search{
  margin-bottom: 55px;
}
.hot-div{
  margin-top: 10px;
}
.hot-div1{
  display: inline-block;
  width: 30%;
  height: 0;
  padding-bottom: 30%;
  margin: 10px 0 10px 2%;
  border-radius: 5px;
  background-size:100% 100% !important;
}

.hot{
  border-bottom: 1px solid #c7c7c7;
  padding-bottom: 15px;
}

.hot-span{
  display: block;
  font-size: 16px !important;
  margin-top: calc(30% + 30px);
}

.dis-span{
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.hot span{
  color: #fff;
  font-size: 13px;
  margin-left: 20px;
}

.hot-title{
  font-size: 17px;
  margin: 20px 0 10px 10px;
}

.note-div{
  margin-left: 10px;
}

.note-img{
  width: 100%;
  border-radius: 4px;
}
.note-left{
  width: 47%;
  float: left;
  margin-right: 5px;
}

.note-title{
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  margin-bottom: 10px;
  line-height: 1.7;
}

.note-msg{
  font-size: 13px;
  color: #828282;
  line-height: 1.7;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.note-img-div{
  display: inline-block;
  width: 46%;
  margin-right: 10px;
  margin-bottom: 4px;
}

.note-autor{
  font-size: 13px;
  color: #949393;
}

.note-rating{
  font-size: 14px;
  float: right;
  margin-right: 20px;
  color: #949393;
}
</style>
