<template>
  <div style="height:100%">
    <!--滑动区域-->
    <div :id="refName" class="mescroll" :ref="refName">
      <div>
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
// 自定义组件说明：
// props参数：scrollDataListId，列表id，必填；pageSize，每页数据条数，选填，默认10条；autoLoad，列表加载完成后是否自动请求数据，选填，默认true
import MeScroll from '../../../static/mescroll/mescroll.min.js'

export default {
  name: 'PullRefresh',
  props: {
    pageSize: {
      type: Number,
      default: 10
    },
    scrollDataListId: {
      type: String
    },
    autoLoad: {
      tyep: Boolean,
      default: true
    },
    noData: {
      tyep: Boolean,
      default: true
    }
  },
  data () {
    return {
      refName: 'mescroll_' + Date.now(),
      instance: null
    }
  },
  mounted () {
    // vm.$nextTick:等到整个视图都渲染完毕
    this.$nextTick(this.$_init())
  },
  methods: {
    $_init () {
      if (this.instance) {
        this.instance.destroy()
      }
      // 下拉刷新的布局内容
      var htmlContent =
        '<div class="loader"><div class="loader-inner"><hr><hr><hr><hr><hr></div><div class="loader-inner mybox mybox-1"><hr><hr><hr><hr><hr></div><div class="loader-inner mybox mybox-2"><hr><hr><hr><hr><hr></div><div class="loader-inner mybox mybox-3"><hr><hr><hr><hr><hr></div><div class="loader-inner mybox mybox-4"><hr><hr><hr><hr><hr></div><div class="loader-inner mybox mybox-5"><hr><hr><hr><hr><hr></div><div class="loader-inner mybox mybox-6"><hr><hr><hr><hr><hr></div><div class="loader-inner"><hr><hr><hr><hr><hr></div></div>'
      // 上拉加载中的布局内容
      var htmlLoading =
        '<div class="stage"><div class="dot-pulse"></div></div>'
      // 无更多数据的布局内容
      var htmlNodata = ''
      if (this.noData !== 'false') {
        // 允许显示没有更多
        htmlNodata = '<p class="upwarp-nodata">--无更多数据--</p>'
      }
      this.instance = new MeScroll(this.refName, {
        // 请至少在vue的mounted生命周期初始化mescroll,以确保您配置的id能够被找到
        up: {
          auto: false,
          htmlLoading: htmlLoading, // 上拉加载中的布局
          htmlNodata: htmlNodata, // 无数据的布局
          callback: this.$_upCallback, // 上拉回调
          // 以下参数可删除,不配置
          isBounce: false, // 此处禁止ios回弹,解析(务必认真阅读,特别是最后一点): http://www.mescroll.com/qa.html#q10
          noMoreSize: 1,
          page: { size: this.pageSize }, // 每页数据条数
          toTop: {
            warpId: this.refName,
            // 配置回到顶部按钮。因为不是vue项目管理的图片，所以引用路径和代码的其他地方不同
            src: './static/mescroll/img/mescroll-totop.png' // 默认滚动到1000px显示,可配置offset修改
          },
          empty: {
            // 配置列表无任何数据的提示
            warpId: this.scrollDataListId,
            // 因为不是vue项目管理的图片，所以引用路径和代码的其他地方不同
            icon: './static/mescroll/img/mescroll-empty.png'
          }
          // vue的案例请勿配置clearId和clearEmptyId,否则列表的数据模板会被清空
          //                        clearId: "dataList",
          //                        clearEmptyId: "dataList"
        },
        down: {
          auto: this.autoLoad,
          autoShowLoading: false,
          callback: this.$_downCallback,
          htmlContent: htmlContent, // 布局内容
          inited: function (mescroll, downwarp) {
            // 初始化完毕的回调,可缓存dom
            mescroll.downTipDom = downwarp.getElementsByClassName(
              'downwarp-tip'
            )[0]
            mescroll.downProgressDom = downwarp.getElementsByClassName(
              'downwarp-progress'
            )[0]
            mescroll.downManDom = downwarp.getElementsByClassName('loader')[0]
          },
          inOffset: function (mescroll) {
            // 进入指定距离offset范围内那一刻的回调
            if (mescroll.downProgressDom) {
              mescroll.downProgressDom.classList.remove('downwarp-progress')
            }
            if (mescroll.downTipDom) {
              mescroll.downTipDom.innerHTML = '自定义下拉刷新提示文字'
            }
          },
          outOffset: function (mescroll) {
            // 下拉超过指定距离offset那一刻的回调
            if (mescroll.downProgressDom) {
              mescroll.downProgressDom.classList.remove('downwarp-progress')
            }
            if (mescroll.downTipDom) {
              mescroll.downTipDom.innerHTML = '自定义释放更新提示文字'
            }
          }
        }
      })
    },
    // 下拉回调，自动触发一次上拉刷新，但是不显示动画
    $_downCallback () {
      this.instance.resetUpScroll(false)
    },
    // 上拉回调
    $_upCallback (page) {
      this.$emit('load', page)
    },
    // 重置列表为第一页 (常用于列表筛选条件变化或切换菜单时重新刷新列表数据)
    // 内部实现: 把page.num=1,再主动触发up.callback
    // isShowLoading 是否显示进度布局
    // 1.默认null,不传参,则显示上拉加载的进度布局
    // 2.传参true, 则显示下拉刷新的进度布局
    // 3.传参false,则不显示上拉和下拉的进度 (常用于静默更新列表数据)
    resetUpScroll (isShowLoading) {
      this.instance.resetUpScroll(isShowLoading)
    },
    // 主动触发下拉刷新
    triggerDownScroll () {
      this.instance.triggerDownScroll()
    },
    // 返回列表对象
    getScrollInstance () {
      return this.instance
    },
    // 滚动列表到指定位置
    // y=0,则回到列表顶部 如需滚动到列表底部,可设置y很大的值,比如y=99999
    // t时长,单位ms,默认300 如果不需要动画缓冲效果,则传0
    scrollTo (y, t) {
      this.instance.scrollTo(y, t)
    },
    // 锁定下拉刷新 ( isLock=ture,null 锁定  isLock=false 解锁 )
    lockDownScroll (hide) {
      this.instance.lockDownScroll(hide)
    },
    // 锁定上拉加载 ( isLock=ture,null 锁定  isLock=false 解锁 )
    lockUpScroll (hide) {
      this.instance.lockUpScroll(hide)
    },
    endUpScroll (hide) {
      this.instance.endUpScroll(hide)
    },
    // 隐藏回到顶部的按钮
    hideTopBtn () {
      this.instance.hideTopBtn()
    },
    /** 列表更新结束回调: 后台接口有返回列表的总页数 totalPage,必传参数(当前页的数据个数, 总页数) */
    endByPage (curPageDataLength, totalPage) {
      this.instance.endByPage(curPageDataLength, totalPage)
    },
    /** 列表更新结束回调:后台接口有返回列表的总数据量 totalSize,必传参数(当前页的数据个数, 总数据量) */
    endBySize (curPageDataLength, totalSize) {
      this.instance.endBySize(curPageDataLength, totalSize)
    },
    /** 列表更新结束回调:参数(当前页的数据个数-必填,是否有下一页true/false-选填) */
    endSuccess (curPageDataLength, hasNext) {
      this.instance.endSuccess(curPageDataLength, hasNext)
    },
    /** 列表更新结束回调:列表更新失败 */
    endErr () {
      this.instance.endErr()
    }
  }
}
</script>

<style>
/* 上面暂时不能用style scoped，因为mescroll提供的样式有控件外的东西 */
@import "../../../static/mescroll/mescroll.min.css";
@import "../../../static/pull/css/bootstrap-grid.min.css";
@import "../../../static/pull/css/htmleaf-demo.css";
@import "../../../static/pull/css/normalize.css";
@import "../../../static/pull/css/three-dots.min.css";
* {
  margin: 0;
  padding: 0;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -webkit-tap-highlight-color: transparent;
}
body {
  background-color: #f5f8fd;
}

/*mescroll滚动的区域*/
.mescroll {
  top: 44px;
  bottom: 0;
  height: 100%;
  overflow-x: hidden;
}

.snippet {
  position: relative;
  background: #fff;
  padding: 2rem 5%;
  margin: 1.5rem 0;
  box-shadow: 0 0.4rem 0.8rem -0.1rem rgba(0, 32, 128, 0.1), 0 0 0 1px #f0f2f7;
  border-radius: 0.25rem;
}

.stage {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 2rem 0;
  overflow: hidden;
}

.filter-contrast {
  filter: contrast(5);
  background-color: white;
}

.loader {
  width: 46px;
  height: 40px;
  margin: 15px auto;
  position: relative;
  perspective: 100px;
  perspective-origin: 50% 100%;
  transform-style: preserve-3d;
  transform: translateZ(-1px);
}
.loader .loader-inner {
  width: 50%;
  height: 100%;
  background: #fff;
  border: 3px solid #57a0fe;
  position: absolute;
  right: 0;
  transform-origin: 0% 100%;
}
.loader .loader-inner:first-child {
  left: 0;
}
.loader .loader-inner hr {
  margin: 3px 3px 6px;
  border: 1px solid rgba(46, 136, 252, 1);
}
.loader .loader-inner.mybox {
  -webkit-animation: loading-1 3.6s infinite ease-in-out;
  animation: loading-1 3.6s infinite ease-in-out;
}
.loader .loader-inner.mybox-1 {
  animation-delay: 0.2s;
}
.loader .loader-inner.mybox-2 {
  animation-delay: 0.4s;
}
.loader .loader-inner.mybox-3 {
  animation-delay: 0.6s;
}
.loader .loader-inner.mybox-4 {
  animation-delay: 0.8s;
}
.loader .loader-inner.mybox-5 {
  animation-delay: 1.8s;
}
.loader .loader-inner.mybox-6 {
  animation-delay: 2.2s;
}
@-webkit-keyframes loading-1 {
  25%,
  100% {
    transform: translateX(3px) rotateY(-180deg);
  }
}
@keyframes loading-1 {
  25%,
  100% {
    transform: translateX(3px) rotateY(-180deg);
  }
}
</style>
