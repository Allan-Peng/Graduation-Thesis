<template>
  <div id="chooseDestination">
    <div class="choose-title">请选择出发地</div>
    <div style="margin-bottom: 45px;
    position: absolute;">
      <span class="hot-title">精选榜</span>
      <div class="hot">
        <div class="hot-div" v-for="city in cityList" :key="city.nNoteId" :style="{background: 'url('+city.cImg+')'}" @click="chooseCity(city.cName)">
          <span class="hot-span">{{city.cName}}</span>
          <span>{{city.cDiscription}}</span>
        </div>
      </div>
    </div>
    <div class="choose-div">
      <input class="choose-input" v-model="departure" placeholder="选择目的地..." readonly/>
      <button :class="departure.trim()!==''?chooseClassActive:chooseClass" @click="jumpChooseTime">下一步</button>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      cityList: [],
      departure: '',
      chooseClassActive: 'choose-class-active',
      chooseClass: 'choose-class'
    }
  },
  mounted () {
    var that = this
    that.$ajax.get(// 调用接口
      '/attraction/getAttractions?pageNo=1&pageSize=30' // this指data
    ).then(function (response) { // 接口返回数据
      that.cityList = response.data
      for(var i=0;i<that.cityList.length;i++){
        if(that.cityList[i].cDiscription===null){
          that.cityList[i].cDiscription = '强烈推荐'
        }
        if(that.cityList[i].cImg===null){
          that.cityList[i].cImg = '../../../static/images/search-city0.jpg'
        }
      }
    })
  },
  methods: {
    chooseCity (cityName) {
      if (this.departure === cityName) {
        this.departure = ''
      } else {
        this.departure = cityName
      }
    },
    jumpChooseTime () {
      if (this.departure.trim() !== '') {
        this.$router.push(
          {
            name: 'chooseDestination',
            params: {
              departure: this.departure
            }
          }
        )
      }
    }
  }
}
</script>

<style scoped>
#chooseDestination{
  height: 100%;
  margin: 0;
}
.choose-title{
  font-size: 22px;
  text-align: center;
  background-color: #5aa5d3;
  color: #ffffff;
  height: 50px;
  line-height: 50px;
}
.hot-div{
  display: inline-block;
  width: 30%;
  height: 0;
  padding-bottom: 30%;
  margin: 10px 0 10px 2.5%;
  border-radius: 5px;
  background-size:100% 100% !important;
}

.hot{
  padding-bottom: 15px;
}

.hot-span{
  display: block;
  font-size: 16px !important;
  margin-top: 65px;
}

.hot span{
  color: #fff;
  font-size: 13px;
  margin-left: 20px;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.hot-title{
  font-size: 17px;
  margin: 20px 0 10px 10px;
}
.choose-div{
  height: 50px;
  width: 100%;
  position: fixed;
  bottom: 0;
  z-index: 2;
  background-color: #ffffff;
  padding-top: 10px;
  border-top: 1px solid #e1e1e1;
}
.choose-class-active{
  color: #000000;
  background-color: #e1e1e1;
  width: 90px;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
}
.choose-class{
  color: #ffffff;
  background-color: #e1e1e1;
  width: 90px;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
  outline:none;
}
.choose-input{
  background-color: #ffffff;
  margin-left: 20px;
  border: none;
  height: 38px;
  font-size: 16px;
  width: calc(100% - 140px);
  outline:none;
}
.choose-input::placeholder{
  color: #acacac;
}
</style>
