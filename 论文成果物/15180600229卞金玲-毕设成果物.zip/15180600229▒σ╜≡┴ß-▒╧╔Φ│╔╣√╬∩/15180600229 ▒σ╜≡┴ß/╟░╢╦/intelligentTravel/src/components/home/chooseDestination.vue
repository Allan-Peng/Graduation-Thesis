<template>
  <div id="chooseDestination">
    <Header title="请选择目的地"></Header>
    <div style="    margin-bottom: 45px; width: 100%;margin-top: 55px;
    position: absolute;">
      <span class="hot-title">精选榜</span>
      <div class="hot">
        <div class="hot-div" v-for="city in cityList" :key="city.nNoteId" :style="{background: 'url('+city.cImg+')'}" @click="chooseCity(city.cCity)">
          <span class="hot-span">{{city.cCity}}</span>
          <span>{{city.cDiscription}}</span>
        </div>
      </div>
    </div>
    <div class="choose-div">
      <input class="choose-input" v-model="destination" placeholder="选择目的地..." readonly/>
      <button :class="destination.trim()!==''?chooseClassActive:chooseClass" @click="jumpChooseTime">下一步</button>
    </div>
  </div>
</template>

<script>
import Header from '../header.vue'
export default {
  components:{Header},
  data () {
    return {
      cityList: [
        {
          cCity:'澳门',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'北京市',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'福建',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'海南',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'贵州',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'四川',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'广东',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'广西',
          cImg:'../../../static/images/search-city0.jpg'
        },
        {
          cCity:'甘肃',
          cImg:'../../../static/images/search-city0.jpg'
        }
      ],
      destination: '',
      // departure: this.$route.params.departure,
      chooseClassActive: 'choose-class-active',
      chooseClass: 'choose-class'
    }
  },
  mounted () {
    // var that = this
    // that.$ajax.get(// 调用接口
    //   '/attraction/getCitys' // this指data
    // ).then(function (response) { // 接口返回数据
    //   that.cityList = response.data
    //   for(var i=0;i < that.cityList.length; i++) {
    //     if (that.cityList[i].cImg ===null) {
    //       that.cityList[i].cImg = '../../../static/images/search-city0.jpg'
    //     }
    //   }
    // })
  },
  methods: {
    chooseCity (cityName) {
      if (this.destination === cityName) {
        this.destination = ''
      } else {
        this.destination = cityName
      }
    },
    jumpChooseTime () {
      if (this.destination.trim() !== '') {
        this.$router.push(
          {
            path: '/recommendInfo',
            name: 'recommendInfo',
            query: {
              destination: this.destination
            }
          }
        )
      }
    }
  }
}
</script>

<style scoped>
#chooseDestination{
  height: 100%;
  margin: 0;
}
.choose-title{
  font-size: 22px;
  text-align: center;
  background-color: #5aa5d3;
  color: #ffffff;
  height: 50px;
  line-height: 50px;
}
.hot-div{
  display: inline-block;
  width: 30%;
  height: 0;
  padding-bottom: 30%;
  margin: 10px 0 10px 2.5%;
  border-radius: 5px;
  background-size:100% 100% !important;
}

.hot{
  padding-bottom: 15px;
}

.hot-span{
  display: block;
  font-size: 16px !important;
  margin-top: 65px;
}

.hot span{
  color: #fff;
  font-size: 13px;
  margin-left: 20px;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.hot-title{
  font-size: 17px;
  margin: 20px 0 10px 10px;
}
.choose-div{
  height: 50px;
  width: 100%;
  position: fixed;
  bottom: 0;
  z-index: 2;
  background-color: #ffffff;
  padding-top: 10px;
  border-top: 1px solid #e1e1e1;
}
.choose-class-active{
  color: #000000;
  background-color: #e1e1e1;
  width: 90px;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
}
.choose-class{
  color: #ffffff;
  background-color: #e1e1e1;
  width: 90px;
  height: 38px;
  font-size: 15px;
  border-radius: 5px;
  border: none;
  outline:none;
}
.choose-input{
  background-color: #ffffff;
  margin-left: 20px;
  border: none;
  height: 38px;
  font-size: 16px;
  width: calc(100% - 140px);
  outline:none;
}
.choose-input::placeholder{
  color: #acacac;
}
</style>
