<template>
  <div>
    <Header title="我的收藏"></Header>
    <div style="margin-top: 55px;">
    <div v-for="collect in collectList" :key="collect.id" class="div" @click="jumpToDetail(collect)">
      <img :src="collect.img" class="img"/>
      <div class="title_div">
        <span class="title">{{collect.title}}</span>
        <div class="discription">{{collect.discription}}</div>
      </div>
    </div>
    </div>
  </div>
</template>

<script>
import Header from '../header.vue'
export default {
  components:{Header},
  data () {
    return {
      collectList:[],
      userId : sessionStorage.getItem('userId')
    }
  },
  mounted () {
    var that = this
    that.$ajax.get(// 调用接口
      '/collect/getAllCollects?userId=' + that.userId
    ).then(function (response) {
      that.collectList = response.data
      for(var i=0;i<that.collectList.length;i++){
        if(that.collectList[i].discription===null){
          that.collectList[i].discription = '强烈推荐'
        }
        if(that.collectList[i].img===null){
          that.collectList[i].img = '../../../static/images/search-city0.jpg'
        }
      }
    })
  },
  methods:{
    jumpToDetail(collect) {
      if(collect.noteId !=0){
        this.$router.push(
        {
          name: 'noteDetail',
          query: {
            noteId: collect.noteId
          }
        }
      )
      }else{
        this.$router.push({
          name: 'recomDetail',
          query: {
            attrId: collect.attrId
          }
        })
      }
    }
  }
}
</script>

<style scoped>
.div{
  margin: 5px;
  height: 120px;
}
.title_div{
  width: 60%;
  display: inline-block;
  margin-left: 10px;
  position: absolute;
}
.img{
  width: 30%;
}
.title{
  font-weight: bold;
  font-size: 16px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  height: 45px;
}
.discription{
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  height: 40px;
}
</style>
