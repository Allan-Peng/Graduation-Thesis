// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'
import global from './utils/global.js'
import moment from 'moment'
import Header from './components/header'
import PullRefresh from './components/pullrefresh/index'

Vue.prototype.$moment = moment
Vue.prototype.$ajax = axios
Vue.prototype.$global = global
axios.defaults.baseURL = 'http://localhost:8080'

Vue.use(ElementUI)
Vue.use(PullRefresh)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App ,Header: Header },
  template: '<App/>'
})
