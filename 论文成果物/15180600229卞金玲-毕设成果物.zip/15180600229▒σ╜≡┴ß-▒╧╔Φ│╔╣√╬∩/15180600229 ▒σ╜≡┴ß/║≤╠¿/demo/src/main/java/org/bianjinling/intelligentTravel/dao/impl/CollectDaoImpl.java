package org.bianjinling.intelligentTravel.dao.impl;

import java.util.List;

import org.bianjinling.intelligentTravel.dao.ICollectDao;
import org.bianjinling.intelligentTravel.entity.Collect;
import org.bianjinling.intelligentTravel.mapper.CollectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CollectDaoImpl implements ICollectDao {
	@Autowired
	CollectMapper collectMapper;
	
	@Override
	public List<Collect> getAllCollects(int userId) {
		return collectMapper.getAllCollects(userId);
	}
	
	@Override
	public int doCollect(int userId, int collectId,int type) {
		return collectMapper.doCollect(userId, collectId,type);
	}
	
	@Override
	public int deleteCollect(int collectId) {
		return collectMapper.deleteCollect(collectId);
	}

	@Override
	public int addCollectNum(int collectId) {
		return collectMapper.addCollectNum(collectId);
	}

	@Override
	public int reduceCollectNum(int collectId) {
		return collectMapper.reduceCollectNum(collectId);
	}
}
