package org.bianjinling.intelligentTravel.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.bianjinling.intelligentTravel.entity.TravelNote;

public interface TravelNoteMapper {
    int deleteByPrimaryKey(Integer nNoteId);

    int insert(TravelNote record);

    int insertSelective(TravelNote record);

    TravelNote selectByPrimaryKey(@Param("nNoteId")Integer nNoteId,@Param("userId")Integer userId);
    
    List<TravelNote> selectOrderByRating();

    int updateByPrimaryKeySelective(TravelNote record);

    int updateByPrimaryKeyWithBLOBs(TravelNote record);

    int updateByPrimaryKey(TravelNote record);
}