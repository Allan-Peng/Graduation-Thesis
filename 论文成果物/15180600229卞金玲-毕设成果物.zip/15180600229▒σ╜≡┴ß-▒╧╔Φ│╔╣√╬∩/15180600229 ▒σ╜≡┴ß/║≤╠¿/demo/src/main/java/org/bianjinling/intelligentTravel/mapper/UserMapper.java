package org.bianjinling.intelligentTravel.mapper;

import org.bianjinling.intelligentTravel.entity.User;

public interface UserMapper {
    int deleteByPrimaryKey(Integer nId);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer nId);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

	User getUserByLogin(String login);
	
}