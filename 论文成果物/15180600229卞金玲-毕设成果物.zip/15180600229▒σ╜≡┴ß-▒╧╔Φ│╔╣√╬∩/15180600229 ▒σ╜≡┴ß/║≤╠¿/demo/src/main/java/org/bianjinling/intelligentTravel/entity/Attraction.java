package org.bianjinling.intelligentTravel.entity;

public class Attraction {
    private Integer nId;

    private String cName;

    private String cDiscription;

    private String cImg;

    private Double dPrice;

    private Double nRating;

    private Integer nType;

    private String cCity;
    
    private String cPlayTime;
    
    private String cTravel;
    
    private String cOpenTime;
    
    private String cTel;
    
    private int collectId;
    
    public int getCollectId() {
		return collectId;
	}

	public void setCollectId(int collectId) {
		this.collectId = collectId;
	}

	public Integer getnId() {
        return nId;
    }

    public void setnId(Integer nId) {
        this.nId = nId;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName == null ? null : cName.trim();
    }

    public String getcDiscription() {
        return cDiscription;
    }

    public void setcDiscription(String cDiscription) {
        this.cDiscription = cDiscription == null ? null : cDiscription.trim();
    }

    public String getcImg() {
        return cImg;
    }

    public void setcImg(String cImg) {
        this.cImg = cImg == null ? null : cImg.trim();
    }

    public Double getdPrice() {
        return dPrice;
    }

    public void setdPrice(Double dPrice) {
        this.dPrice = dPrice;
    }

    public Integer getnType() {
        return nType;
    }

    public void setnType(Integer nType) {
        this.nType = nType;
    }

    public String getcCity() {
        return cCity;
    }

    public void setcCity(String cCity) {
        this.cCity = cCity == null ? null : cCity.trim();
    }

	public Double getnRating() {
		return nRating;
	}

	public void setnRating(Double nRating) {
		this.nRating = nRating;
	}

	public String getcPlayTime() {
		return cPlayTime;
	}

	public void setcPlayTime(String cPlayTime) {
		this.cPlayTime = cPlayTime;
	}

	public String getcTravel() {
		return cTravel;
	}

	public void setcTravel(String cTravel) {
		this.cTravel = cTravel;
	}

	public String getcOpenTime() {
		return cOpenTime;
	}

	public void setcOpenTime(String cOpenTime) {
		this.cOpenTime = cOpenTime;
	}

	public String getcTel() {
		return cTel;
	}

	public void setcTel(String cTel) {
		this.cTel = cTel;
	}
    
    
}