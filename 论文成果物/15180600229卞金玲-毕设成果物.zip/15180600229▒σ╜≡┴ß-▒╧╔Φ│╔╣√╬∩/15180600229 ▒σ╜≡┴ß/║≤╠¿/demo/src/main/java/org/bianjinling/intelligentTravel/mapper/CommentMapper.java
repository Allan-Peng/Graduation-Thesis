package org.bianjinling.intelligentTravel.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.bianjinling.intelligentTravel.entity.Comment;

public interface CommentMapper {
	List<Comment> selectCommentById(@Param("commentId")int commentId,@Param("type") int type);
	
	int addComment(Comment comment);

	int delComment(@Param("commentId") int commentId);
}
