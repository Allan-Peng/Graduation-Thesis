package org.bianjinling.intelligentTravel.dao;

import org.bianjinling.intelligentTravel.entity.User;

public interface IUserDao {
	
	public User selectByPrimaryKey(int id);

	public User getUserByLogin(String login);

	public int updateInfo(User user);

}
