package org.bianjinling.intelligentTravel.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.bianjinling.intelligentTravel.entity.Attraction;

import com.github.pagehelper.Page;

public interface AttractionMapper {
//    int deleteByPrimaryKey(Integer nId);
//
//    int insert(Attraction record);
//
//    int insertSelective(Attraction record);
//
	Attraction selectByPrimaryKey(@Param("nId")int nId,@Param("userId")Integer userId);
//    
//    int updateByPrimaryKeySelective(Attraction record);
//
//    int updateByPrimaryKey(Attraction record);
//    
	Page<Attraction> selectOrderByRating();
	
	List<Attraction> getCitys();
	
	List<Attraction> getAttrByCitys(String city);
}