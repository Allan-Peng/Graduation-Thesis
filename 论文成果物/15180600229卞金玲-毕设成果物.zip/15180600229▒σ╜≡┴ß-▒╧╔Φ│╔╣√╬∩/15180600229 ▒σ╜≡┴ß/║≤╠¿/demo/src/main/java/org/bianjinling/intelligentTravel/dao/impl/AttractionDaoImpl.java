package org.bianjinling.intelligentTravel.dao.impl;

import java.util.List;

import org.bianjinling.intelligentTravel.dao.IAttractionDao;
import org.bianjinling.intelligentTravel.entity.Attraction;
import org.bianjinling.intelligentTravel.mapper.AttractionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;

@Repository
public class AttractionDaoImpl implements IAttractionDao{
	@Autowired
	AttractionMapper mAttractionMapper;
	
	@Override
	public Attraction selectByPrimaryKey(int nId,Integer userId) {
		return mAttractionMapper.selectByPrimaryKey(nId,userId);
	}	
	@Override
	public Page<Attraction> selectOrderByRating(int pageNo,int pageSize){
		PageHelper.startPage(pageNo,pageSize);
		return mAttractionMapper.selectOrderByRating();
	}
	@Override
	public List<Attraction> getCitys() {
		return mAttractionMapper.getCitys();
	}
	@Override
	public List<Attraction> getAttrByCitys(String city) {
		return mAttractionMapper.getAttrByCitys(city);
	}
}
