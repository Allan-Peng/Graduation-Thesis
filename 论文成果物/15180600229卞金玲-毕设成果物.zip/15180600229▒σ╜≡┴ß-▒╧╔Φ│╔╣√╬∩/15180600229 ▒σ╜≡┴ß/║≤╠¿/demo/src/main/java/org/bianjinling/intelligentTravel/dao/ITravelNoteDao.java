package org.bianjinling.intelligentTravel.dao;

import java.util.List;

import org.bianjinling.intelligentTravel.entity.TravelNote;

public interface ITravelNoteDao {
	/**
	 * 获取当前id的游记
	 * @param nNoteId 游记id
	 * @return
	 */
	public TravelNote selectByPrimaryKey(int nNoteId,Integer userId) ;
	
	/**
	 * 获取所有游记
	 * @return
	 */
	public List<TravelNote> selectOrderByRating() ;

	public int insert(TravelNote travelNote);
}
