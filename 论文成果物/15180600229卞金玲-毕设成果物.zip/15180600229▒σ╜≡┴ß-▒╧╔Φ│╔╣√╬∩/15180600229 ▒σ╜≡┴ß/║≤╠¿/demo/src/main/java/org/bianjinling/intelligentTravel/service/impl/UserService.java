package org.bianjinling.intelligentTravel.service.impl;

import org.bianjinling.intelligentTravel.dao.IUserDao;
import org.bianjinling.intelligentTravel.entity.User;
import org.bianjinling.intelligentTravel.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service("DemoService")
public class UserService implements IUserService {

	@Autowired
	IUserDao mUserDao;
	
	@Override
	public User getDemoTest(int id) {
		return mUserDao.selectByPrimaryKey(id);
	}
	
	@Override
	public User getUserByLogin(String login) {
		return mUserDao.getUserByLogin(login);
	}
	
	@Override
	public int updateInfo(User user) {
    	return mUserDao.updateInfo(user);
    }

}
