package org.bianjinling.intelligentTravel.entity;

public class User {
    private Integer nId;

	private String cLogin;

	private String cPassword;

	private String cName;

	public Integer getnId() {
		return nId;
	}

	public void setnId(Integer nId) {
		this.nId = nId;
	}

	public String getcLogin() {
		return cLogin;
	}

	public void setcLogin(String cLogin) {
		this.cLogin = cLogin == null ? null : cLogin.trim();
	}

	public String getcPassword() {
		return cPassword;
	}

	public void setcPassword(String cPassword) {
		this.cPassword = cPassword == null ? null : cPassword.trim();
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName == null ? null : cName.trim();
	}
}