package org.bianjinling.intelligentTravel.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.bianjinling.intelligentTravel.entity.Collect;

@Mapper
public interface CollectMapper {

	public List<Collect> getAllCollects(int userId);
	
	public int doCollect(@Param("userId") int userId,@Param("collectId")int collectId,@Param("type")int type);

	public int deleteCollect(int collectId);
	
	public int addCollectNum(int collectId);
	
	public int reduceCollectNum(int collectId);
}
