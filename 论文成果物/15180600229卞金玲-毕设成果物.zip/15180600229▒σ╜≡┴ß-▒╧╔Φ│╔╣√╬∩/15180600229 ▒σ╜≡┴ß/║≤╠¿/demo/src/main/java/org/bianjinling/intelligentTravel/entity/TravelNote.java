package org.bianjinling.intelligentTravel.entity;

import java.io.InputStream;

public class TravelNote {
    private Integer nNoteId;

    private String cTitle;

    private String cContent;

    private String autor;

    private Integer rating;

    private String img;

    private String cText;
    
    private String imgName;
    
    private int collectId;

	public int getCollectId() {
		return collectId;
	}

	public void setCollectId(int collectId) {
		this.collectId = collectId;
	}

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	public Integer getnNoteId() {
        return nNoteId;
    }

    public void setnNoteId(Integer nNoteId) {
        this.nNoteId = nNoteId;
    }

    public String getcTitle() {
        return cTitle;
    }

    public void setcTitle(String cTitle) {
        this.cTitle = cTitle == null ? null : cTitle.trim();
    }

    public String getcContent() {
        return cContent;
    }

    public void setcContent(String cContent) {
        this.cContent = cContent == null ? null : cContent.trim();
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor == null ? null : autor.trim();
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img == null ? null : img.trim();
    }

    public String getcText() {
        return cText;
    }

    public void setcText(String cText) {
        this.cText = cText == null ? null : cText.trim();
    }
}