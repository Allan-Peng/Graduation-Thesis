package org.bianjinling.intelligentTravel.service;

import java.util.List;

import org.bianjinling.intelligentTravel.entity.Collect;

public interface ICollectService {
	
	public List<Collect> getAllCollects(int userId);

	int doCollect(int userId, int collectId,int type);

	int deleteCollect(int collectId);
	
	public int addCollectNum(int collectId);
	
	public int reduceCollectNum(int collectId);

}
