package org.bianjinling.intelligentTravel.ctrl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bianjinling.intelligentTravel.basic.pagehelper.CustomPageInfo;
import org.bianjinling.intelligentTravel.entity.Attraction;
import org.bianjinling.intelligentTravel.entity.Recommend;
import org.bianjinling.intelligentTravel.service.IAttractionService;
import org.bianjinling.intelligentTravel.util.Dijkstra;
import org.bianjinling.intelligentTravel.util.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/attraction")
public class AttractionCtrl {
	@Autowired
	IAttractionService attractionService;

	@RequestMapping(value="/getAttractionById" , method = RequestMethod.GET)
	public Attraction selectByPrimaryKey(int nId,@RequestParam Integer userId) {
		return attractionService.selectByPrimaryKey(nId,userId);
	}
	
	@RequestMapping(value="/getAttractions" , method = RequestMethod.GET)
	public List<Attraction> selectOrderByRating(int pageNo,int pageSize){
		CustomPageInfo<Attraction> aa = attractionService.selectOrderByRating(pageNo,pageSize);
		return aa.getList();
	}
	
	
	@RequestMapping(value="/getTravels" , method = RequestMethod.GET)
	public Recommend getTravels(String destination){
		Recommend recommend = new Recommend();
		Map<String, List<Attraction>> attr = new HashMap<String, List<Attraction>>();
		Dijkstra test=new Dijkstra();
        Node start=test.init();
        test.computePath(start);
        String lu = test.printPathInfo(destination);
        String citys[] = lu.split("->");
        attr.put(citys[0], null);
        for(int i=1;i<citys.length;i++) {
        	List<Attraction> attractions =  attractionService.getAttrByCitys(citys[i]);
        	attr.put(citys[i], attractions);
        }
        recommend.setLu(lu);
        recommend.setAttr(attr);
        return recommend;
	}
	@ResponseBody
	@RequestMapping(value="/getCitys" , method = RequestMethod.GET)
	public List<Attraction> getCitys() {
		return attractionService.getCitys();
	}
	
	@RequestMapping(value="/getAttrByCity" , method = RequestMethod.GET)
	public List<Attraction> getAttrByCity() {
		return attractionService.getCitys();
	}
	
}
