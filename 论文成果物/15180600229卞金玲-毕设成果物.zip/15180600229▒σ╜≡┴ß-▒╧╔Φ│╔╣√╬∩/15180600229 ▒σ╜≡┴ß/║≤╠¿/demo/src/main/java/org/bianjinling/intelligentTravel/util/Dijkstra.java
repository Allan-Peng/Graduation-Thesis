package org.bianjinling.intelligentTravel.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import lombok.experimental.var;

public class Dijkstra {
    Set<Node> open = new HashSet<Node>();
    Set<Node> close = new HashSet<Node>();
    Map<String, Integer> path = new HashMap<String, Integer>();//封装路径距离
    Map<String, String> pathInfo = new HashMap<String, String>();//封装路径信息

    public Node init() {
        //初始路径,因没有A->E这条路径,所以path(E)设置为Integer.MAX_VALUE
//        path.put("安徽", 4);
//        pathInfo.put("安徽", "广西->安徽");
        path.put("澳门", 5);
        pathInfo.put("澳门", "安徽->澳门");
        path.put("北京市", Integer.MAX_VALUE);
        pathInfo.put("北京市", "安徽");
        path.put("福建", Integer.MAX_VALUE);
        pathInfo.put("福建", "安徽");
        path.put("海南", Integer.MAX_VALUE);
        pathInfo.put("海南", "安徽");
        path.put("贵州", Integer.MAX_VALUE);
        pathInfo.put("贵州", "安徽");
        path.put("四川", 5);
        pathInfo.put("四川", "安徽->四川");
        path.put("广东", Integer.MAX_VALUE);
        pathInfo.put("广东", "安徽");
        path.put("广西", 4);
        pathInfo.put("广西", "安徽->广西");
        path.put("甘肃", Integer.MAX_VALUE);
        pathInfo.put("甘肃", "安徽");
        //将初始节点放入close,其他节点放入open
        Node start = new MapBuilder().build(open, close);
        return start;
    }

    public void computePath(Node start) {
        //取距离start节点最近的子节点,放入close
        Node nearest = getShortestPath(start);
        if (nearest == null) {
            return;
        }
        close.add(nearest);     //已遍历的
        open.remove(nearest);   //未遍历的

        Map<Node, Integer> childs = nearest.getChild();
        for (Node child : childs.keySet()) {
            if (open.contains(child)) {//如果子节点在open中
                Integer newCompute = path.get(nearest.getName()) + childs.get(child);
                if (newCompute < path.get(child.getName())) {//新计算出来的距离小于之前设置的距离
                    path.put(child.getName(), newCompute);
                    pathInfo.put(child.getName(), pathInfo.get(nearest.getName()) + "->" + child.getName());
                }
            }
        }
        computePath(start);//重复执行自己,确保所有子节点被遍历
        computePath(nearest);//向外一层层递归,直至所有顶点被遍历
    }

    public String printPathInfo(String destination) {
    	String lu = "";
        Set<Map.Entry<String, String>> pathInfos = pathInfo.entrySet();
        for (Map.Entry<String, String> pathInfo : pathInfos) {
        	System.out.println(pathInfo.getKey() + ":" + pathInfo.getValue());
        	if(pathInfo.getValue().endsWith(destination)) {
        		lu = pathInfo.getValue();
        	}
            
        }
        return lu;
    }

    /**
     * 获取与node最近的子节点
     */
    private Node getShortestPath(Node node) {
        Node res = null;
        int minDis = Integer.MAX_VALUE;
        Map<Node, Integer> childs = node.getChild();
        // 遍历与Node相连接的所有节点，选取其中距离最短的节点
        for (Node child : childs.keySet()) {
            if (open.contains(child)) {
                int distance = childs.get(child);
                if (distance < minDis) {
                    minDis = distance;
                    res = child;
                }
            }
        }
        return res;
    }
}
