package org.bianjinling.intelligentTravel.basic.pagehelper;

import java.io.Serializable;
import java.util.List;

import com.github.pagehelper.Page;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * mybatis分页插件pagehelper的自定义分页对象
 * @author chenxi-3
 *
 * @param <T>
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Data
@ApiModel(value = "分页对象")
public class CustomPageInfo<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    //当前页
    @ApiModelProperty(value = "当前页码")
    private int pageNum;

    //每页的数量
    @ApiModelProperty(value = "每页的数量")
    private int pageSize;

    //总记录数
    @ApiModelProperty(value = "总记录数")
    private long total;

    //结果集
    @ApiModelProperty(value = "结果集")
    private List<T> list;

    /**
     * 包装Page对象
     *
     * @param list
     */
    public CustomPageInfo(List<T> list) {
        if (list instanceof Page) {
            Page page = (Page) list;
            this.pageNum = page.getPageNum();
            this.pageSize = page.getPageSize();

            this.list = page;
            this.total = page.getTotal();
        } else {
            this.pageNum = 1;
            this.pageSize = list.size();

            this.list = list;
            this.total = list.size();
        }
    }

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = list;
	}
    
    
}