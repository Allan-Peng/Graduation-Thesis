package org.bianjinling.intelligentTravel.dao.impl;

import java.util.List;

import org.bianjinling.intelligentTravel.dao.ICommentDao;
import org.bianjinling.intelligentTravel.entity.Comment;
import org.bianjinling.intelligentTravel.mapper.CommentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CommentDaoImpl implements ICommentDao{

	@Autowired
	CommentMapper commentMapper;
	
	@Override
	public List<Comment> selectCommentById(int commentId,int type){
		return commentMapper.selectCommentById(commentId,type);
	}

	@Override
	public int addComment(Comment comment) {
		return commentMapper.addComment(comment);
	}

	@Override
	public int delComment(int commentId) {
		return commentMapper.delComment(commentId);
	}
}
