package org.bianjinling.intelligentTravel.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.bianjinling.intelligentTravel.basic.pagehelper.CustomPageInfo;
import org.bianjinling.intelligentTravel.dao.IAttractionDao;
import org.bianjinling.intelligentTravel.entity.Attraction;
import org.bianjinling.intelligentTravel.service.IAttractionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.Page;

@Service("AttractionService")
public class AttractionService implements IAttractionService{
	@Autowired
	IAttractionDao mAttractionDao;
	
	@Override
	public Attraction selectByPrimaryKey(int nId,Integer userId) {
		return mAttractionDao.selectByPrimaryKey(nId,userId);
	}	
	@Override
	public CustomPageInfo<Attraction> selectOrderByRating(int pageNo,int pageSize){
		Page<Attraction> aa = mAttractionDao.selectOrderByRating(pageNo,pageSize);
		return new CustomPageInfo<Attraction>(aa);
	}
	@Override
	public List<Attraction> getCitys() {
		return mAttractionDao.getCitys();
	}
	@Override
	public List<Attraction> getAttrByCitys(String city) {
		return mAttractionDao.getAttrByCitys(city);
	}
	
}
