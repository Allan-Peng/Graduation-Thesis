package org.bianjinling.intelligentTravel.service.impl;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.List;

import org.bianjinling.intelligentTravel.dao.ITravelNoteDao;
import org.bianjinling.intelligentTravel.entity.TravelNote;
import org.bianjinling.intelligentTravel.service.ITravelNoteService;
import org.bianjinling.intelligentTravel.util.FtpUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sun.misc.BASE64Decoder;

@Service("TravelNoteService")
public class TravelNoteService implements ITravelNoteService {

	@Autowired
	ITravelNoteDao mTravelNoteDao;
	
	@Override
	public TravelNote selectByPrimaryKey(int nNoteId,Integer userId) {
		return mTravelNoteDao.selectByPrimaryKey(nNoteId,userId);
	}
	
	@Override
	public List<TravelNote> selectOrderByRating(){
		return mTravelNoteDao.selectOrderByRating();
	}

	@Override
	public int insert(TravelNote travelNote) throws IOException {
		
		 String ftpHost = "127.0.0.1";
	        String ftpUserName = "bianjl";
	        String ftpPassword = "Bjl960913";
	        int ftpPort = 21;
	        String fileName = travelNote.getImgName();
		           
            byte[] bytes = new BASE64Decoder().decodeBuffer(travelNote.getImg().trim());
            //转化为输入流
//            ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);
            
            InputStream sbs = new ByteArrayInputStream(bytes); 

			boolean test = FtpUtil.uploadFile(ftpHost, ftpUserName,ftpPassword,ftpPort, fileName,sbs);
			System.out.println(test);
		
	        if (sbs != null) {
	            try {
	            	sbs.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	        
	        travelNote.setImg("../../../static/images/"+fileName);

		return mTravelNoteDao.insert(travelNote);
	}
}
