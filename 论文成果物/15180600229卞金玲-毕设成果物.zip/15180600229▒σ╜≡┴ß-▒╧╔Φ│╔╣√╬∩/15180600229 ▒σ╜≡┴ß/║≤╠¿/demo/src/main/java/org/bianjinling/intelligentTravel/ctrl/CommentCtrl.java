package org.bianjinling.intelligentTravel.ctrl;

import java.util.List;

import org.bianjinling.intelligentTravel.entity.Comment;
import org.bianjinling.intelligentTravel.service.ICommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/comment")
public class CommentCtrl {

	@Autowired
	ICommentService commentService;
	
	/**
	 * 获取评论
	 * @param commentId 评论内容的id
	 * @param type 评论的类别 0:游记 1:景点
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/getComments", method = RequestMethod.GET)
	public List<Comment> selectCommentById(int commentId,int type){
		return commentService.selectCommentById(commentId,type);
	}
	
	@RequestMapping(value = "/addComment", method = RequestMethod.POST)
	public int addComment(@RequestBody Comment comment){
		return commentService.addComment(comment.getComment());
	}
	
	@RequestMapping(value = "/delComment", method = RequestMethod.GET)
	public int delComment(int commentId){
		return commentService.delComment(commentId);
	}
}
