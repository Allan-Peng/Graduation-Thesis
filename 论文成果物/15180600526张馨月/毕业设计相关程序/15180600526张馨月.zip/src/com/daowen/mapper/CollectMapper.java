package com.daowen.mapper;

import com.daowen.entity.Collect;
import com.daowen.ssm.simplecrud.SimpleMapper;

public interface CollectMapper extends SimpleMapper<Collect> {

	
}
