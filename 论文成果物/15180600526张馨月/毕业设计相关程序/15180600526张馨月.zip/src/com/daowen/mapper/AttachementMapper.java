package com.daowen.mapper;

import com.daowen.entity.Attachement;
import com.daowen.ssm.simplecrud.SimpleMapper;

public interface AttachementMapper extends SimpleMapper<Attachement> {

	
}
