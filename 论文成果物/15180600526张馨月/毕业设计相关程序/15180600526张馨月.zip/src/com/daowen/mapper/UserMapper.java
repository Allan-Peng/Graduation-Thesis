package com.daowen.mapper;

import com.daowen.entity.User;
import com.daowen.ssm.simplecrud.SimpleMapper;

public interface UserMapper extends SimpleMapper<User> {

	
}
