package com.daowen.mapper;

import com.daowen.entity.Lunbotu;
import com.daowen.ssm.simplecrud.SimpleMapper;

public interface LunbotuMapper extends SimpleMapper<Lunbotu> {

	
}
