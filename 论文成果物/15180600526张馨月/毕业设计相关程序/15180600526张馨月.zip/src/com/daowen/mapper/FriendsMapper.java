package com.daowen.mapper;

import com.daowen.entity.Friends;
import com.daowen.ssm.simplecrud.SimpleMapper;

public interface FriendsMapper extends SimpleMapper<Friends> {

	
}
