package com.daowen.mapper;

import com.daowen.entity.Comment;
import com.daowen.ssm.simplecrud.SimpleMapper;

public interface CommentMapper extends SimpleMapper<Comment> {

	
}
