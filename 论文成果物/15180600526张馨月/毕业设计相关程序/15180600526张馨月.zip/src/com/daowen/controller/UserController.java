package com.daowen.controller;

import java.text.MessageFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.daowen.entity.User;
import com.daowen.service.UserService;
import com.daowen.ssm.simplecrud.SimpleController;
import com.daowen.webcontrol.PagerMetal;

@Controller
public class UserController extends SimpleController {

	@Autowired
	private UserService userSrv=null;

	@Override
	@RequestMapping("/admin/usermanager.do")
	public void mapping(HttpServletRequest request, HttpServletResponse response) {
		this.mappingMethod(request, response);
	}
	
	public void chongzhi() {
		String jine = request.getParameter("jine");
		String forwardurl = request.getParameter("forwardurl");
		String id = request.getParameter("id");
		if (id == null || id == "")
			return;
		User user = userSrv.load(new Integer(id));
		if (user != null) {
			userSrv.update(user);
			request.getSession().setAttribute("user", user);
			redirect(forwardurl);
		}

	}
	public void modifyPaypw() {

		String paypwd=request.getParameter("paypwd");
		String errorurl=request.getParameter("errorurl");
		String  forwardurl=request.getParameter("forwardurl");
		String repassword1=request.getParameter("repassword1");
		String id = request.getParameter("id");
		if (id == null||id=="")
			return;
		User user =userSrv.load(new Integer(id));
		if(user!=null)
		{
			userSrv.update(user);
			request.getSession().setAttribute("user", user);
			redirect(forwardurl);
		}
		

	}

	public void exit() {

		if (request.getSession().getAttribute("user") != null) {

			System.out.println("系统退出");
			request.getSession().removeAttribute("user");

		}
		

	}
	
	public void login() {
		String usertype = request.getParameter("usertype");
		
		if (usertype != null && usertype.equals("0")) {
			userLogin();
		}
	}
	private void userLogin() {

		String accountname = request.getParameter("accountname");
		String password = request.getParameter("password");

		String filter = MessageFormat.format("where accountname=''{0}'' and password=''{1}''", accountname,
				password);
		User user = (User) userSrv.load(filter);
		String errorurl=request.getParameter("errorurl");
		String forwardurl=request.getParameter("forwardurl");
        if(user==null){
        	dispatchParams(request, response);
        	request.setAttribute("errormsg", "<label class='error'>系统账户和密码不匹配</label>");
        	forward(errorurl);
        	return;
        }
        	
		if (user.getPassword().equals(password)) {
			user.setLogtimes(user.getLogtimes() + 1);
			userSrv.update(user);
			request.getSession().setAttribute("user", user);
			if (forwardurl == null||"".equals(forwardurl))
				forwardurl = "/e/user/accountinfo.jsp";
			redirect(forwardurl);
		}

	}
	

	public void save() {
		String accountname = request.getParameter("accountname");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
        String idcardno=request.getParameter("idcardno");
		String email = request.getParameter("email");
		String  mobile=request.getParameter("mobile");
		String  touxiang=request.getParameter("touxiang");
		String  sex=request.getParameter("sex");
		if (userSrv.isExist("where accountname='" + accountname
				+ "'")) {
				request.setAttribute("errormsg",
						"<label class='error'>用户名已经存在</label>");
				dispatchParams(request, response);
				forward("/e/register.jsp");
		}

		User user = new User();
		user.setAccountname(accountname == null ? "" : accountname);
		user.setPassword(password == null ? "" : password);
		if(mobile!=null) {
			user.setMobile(mobile);
		}
		if(sex!=null) {
			user.setSex(sex);
		} else {
			user.setSex("男");
		}
		user.setNickname(accountname);
        user.setName(name);
		user.setRegdate(new Date());
        user.setIdcardno(idcardno==null?"":idcardno);
		user.setLogtimes(0);
		if(touxiang!=null) {
			user.setTouxiang(touxiang);
		} else {
			user.setTouxiang(request.getContextPath()
				+ "/upload/nopic.jpg");
		}
		user.setEmail(email == null ? "" : email);
		user.setStatus(1);
		userSrv.save(user);
		String forwardurl=request.getParameter("forwardurl");
		if (forwardurl == null) {
			forwardurl = "/admin/usermanager.do?actiontype=get";
		}
		redirect(forwardurl);

	}
	public void delete() {
		String id = request.getParameter("id");
		userSrv.delete(" where id=" + id);
		get();
	}
	
	public void update() {
		String id = request.getParameter("id");
		if (id == null)
			return;
		User user = userSrv.load(new Integer(id));
		if (user == null)
			return;
		String accountname = request.getParameter("accountname");
		String nickname = request.getParameter("nickname");
		String forwardurl = request.getParameter("forwardurl");
		String touxiang = request.getParameter("touxiang");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String sex = request.getParameter("sex");
		String name = request.getParameter("name");
	    String idcardno=request.getParameter("idcardno");
	    if(accountname!=null)
		   user.setAccountname(accountname);
		user.setNickname(nickname==null?"":nickname);
		user.setTouxiang(touxiang==null?"":touxiang);
		user.setEmail(email==null?"":email);
		user.setMobile(mobile==null?"":mobile);
		user.setIdcardno(idcardno==null?"":idcardno);
		user.setSex(sex==null?"":sex);
		user.setName(name==null?"":name);
		userSrv.update(user);
		request.getSession().setAttribute("user", user);
		if (forwardurl == null) {
			forwardurl = "/admin/usermanager.do?actiontype=get";
		}
		redirect(forwardurl);

	}
	
	public void modifyPw() {

		String password=request.getParameter("password");
		String errorurl=request.getParameter("errorurl");
		String  forwardurl=request.getParameter("forwardurl");
		String repassword1=request.getParameter("repassword1");
		String id = request.getParameter("id");
		if (id == null||id=="")
			return;
		User user =userSrv.load(new Integer(id));
		if(user!=null)
		{
			if(!user.getPassword().equals(password)){
				request.setAttribute("errormsg",
						"<label class='error'>原始密码不正确</label>");
				dispatchParams(request, response);
				forward(errorurl);
				return ;
			}
			user.setPassword(repassword1);
			userSrv.update(user);
			request.getSession().setAttribute("user", user);
			redirect(forwardurl);
		}

	}
	
	
	public void load() {
		//
		String id = request.getParameter("id");
		String actiontype = "save";
		if (id != null){
			User user = userSrv.load("where id="+ id);
			if (user != null) {
				request.setAttribute("user", user);
			}
			actiontype = "update";
		}
		request.setAttribute("id", id);
		request.setAttribute("actiontype", actiontype);
		String forwardurl = request.getParameter("forwardurl");
		forward(forwardurl);
		
	}
	public void  get(){
		String filter = "";
		//
		int pageindex = 1;
		int pagesize = 10;
		// 获取当前分页
		String accountname = request.getParameter("accountname");
		if (accountname != null)
			filter = "  where accountname like '%" + accountname + "%'  ";
		String currentpageindex = request.getParameter("currentpageindex");
		// 当前页面尺寸
		String currentpagesize = request.getParameter("pagesize");
		// 设置当前页
		if (currentpageindex != null)
			pageindex = new Integer(currentpageindex);
		// 设置当前页尺寸
		if (currentpagesize != null)
			pagesize = new Integer(currentpagesize);
		List<User> listuser = userSrv.getEntity();
		int recordscount = userSrv.getRecordCount(filter);
		request.setAttribute("listuser", listuser);
		PagerMetal pm = new PagerMetal(recordscount);
		// 设置尺寸
		pm.setPagesize(pagesize);
		// 设置当前显示页
		pm.setCurpageindex(pageindex);
		// 设置分页信息
		request.setAttribute("pagermetal", pm);
		// 分发请求参数
		dispatchParams(request, response);
		String forwardurl = request.getParameter("forwardurl");
		System.out.println("forwardurl=" + forwardurl);
		if (forwardurl == null) {
			forwardurl = "/admin/usermanager.jsp";
		}
		forward(forwardurl);
	}
	
	

}
