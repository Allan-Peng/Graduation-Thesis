package com.daowen.service;

import org.springframework.stereotype.Service;

import com.daowen.mapper.CommentMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;
@Service
public class CommentService extends SimpleBizservice<CommentMapper>{

	
}
