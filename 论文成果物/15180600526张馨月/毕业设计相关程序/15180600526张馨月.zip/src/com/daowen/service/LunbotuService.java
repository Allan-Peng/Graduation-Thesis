package com.daowen.service;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.daowen.mapper.LunbotuMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;

@Service("lunbotuService")
@Scope("prototype")
public class LunbotuService extends SimpleBizservice<LunbotuMapper> {

	
}
