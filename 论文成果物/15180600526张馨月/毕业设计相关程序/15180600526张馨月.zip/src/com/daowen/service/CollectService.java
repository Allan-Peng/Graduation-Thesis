package com.daowen.service;

import org.springframework.stereotype.Service;

import com.daowen.mapper.CollectMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;
@Service
public class CollectService extends SimpleBizservice<CollectMapper> {


	
}
