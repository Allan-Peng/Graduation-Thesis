package com.daowen.service;
import org.springframework.stereotype.Service;

import com.daowen.mapper.VideoMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;
@Service
public class VideoService extends SimpleBizservice<VideoMapper>{
}
