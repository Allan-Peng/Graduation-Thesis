package com.daowen.service;

import org.springframework.stereotype.Service;

import com.daowen.mapper.SysconfigMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;

@Service
public class SysconfigService extends SimpleBizservice<SysconfigMapper> {

	
	
}
