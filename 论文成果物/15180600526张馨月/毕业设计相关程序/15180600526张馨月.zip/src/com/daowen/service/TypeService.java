package com.daowen.service;
import org.springframework.stereotype.Service;

import com.daowen.mapper.TypeMapper;
import com.daowen.ssm.simplecrud.SimpleBizservice;
@Service
public class TypeService extends SimpleBizservice<TypeMapper>{
}
