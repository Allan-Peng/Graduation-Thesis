package com.daowen.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Video {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private String title;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	private String tupian;

	public String getTupian() {
		return tupian;
	}

	public void setTupian(String tupian) {
		this.tupian = tupian;
	}

	private String pubren;

	public String getPubren() {
		return pubren;
	}

	public void setPubren(String pubren) {
		this.pubren = pubren;
	}

	private Date pubtime;

	public Date getPubtime() {
		return pubtime;
	}

	public void setPubtime(Date pubtime) {
		this.pubtime = pubtime;
	}

	private String subtitle;

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	private String remoteurl;

	public String getRemoteurl() {
		return remoteurl;
	}

	public void setRemoteurl(String remoteurl) {
		this.remoteurl = remoteurl;
	}

	private int xshowtype;

	public int getXshowtype() {
		return xshowtype;
	}

	public void setXshowtype(int xshowtype) {
		this.xshowtype = xshowtype;
	}

	private int typeid;

	public int getTypeid() {
		return typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	private String typename;

	public String getTypename() {
		return typename;
	}

	public void setTypename(String typename) {
		this.typename = typename;
	}

	private int againstcount;

	public int getAgainstcount() {
		return againstcount;
	}

	public void setAgainstcount(int againstcount) {
		this.againstcount = againstcount;
	}

	private int agreecount;

	public int getAgreecount() {
		return agreecount;
	}

	public void setAgreecount(int agreecount) {
		this.agreecount = agreecount;
	}

	private String des;

	public String getDes() {
		return des;
	}

	public void setDes(String des) {
		this.des = des;
	}

	private int clickcount;

	public int getClickcount() {
		return clickcount;
	}

	public void setClickcount(int clickcount) {
		this.clickcount = clickcount;
	}

	/**
	 * 字母索引
	 */
	private String alphabetindex;

	public String getAlphabetindex() {
		return alphabetindex;
	}

	public void setAlphabetindex(String alphabetindex) {
		this.alphabetindex = alphabetindex;
	}

	private int dqid;

	public int getDqid() {
		return dqid;
	}

	public void setDqid(int dqid) {
		this.dqid = dqid;
	}

	private String dqname;

	public String getDqname() {
		return dqname;
	}

	public void setDqname(String dqname) {
		this.dqname = dqname;
	}

	private int ndid;

	public int getNdid() {
		return ndid;
	}

	public void setNdid(int ndid) {
		this.ndid = ndid;
	}

	private String ndname;

	public String getNdname() {
		return ndname;
	}

	public void setNdname(String ndname) {
		this.ndname = ndname;
	}
	private String tags;

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

}
