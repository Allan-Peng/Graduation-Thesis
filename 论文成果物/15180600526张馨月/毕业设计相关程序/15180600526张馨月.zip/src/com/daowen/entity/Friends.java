package com.daowen.entity;

import java.util.Date;
import javax.persistence.*;

@Entity
public class Friends {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private String hyaccount;

	public String getHyaccount() {
		return hyaccount;
	}

	public void setHyaccount(String hyaccount) {
		this.hyaccount = hyaccount;
	}

	private String gzaccount;

	public String getGzaccount() {
		return gzaccount;
	}

	public void setGzaccount(String gzaccount) {
		this.gzaccount = gzaccount;
	}
}
