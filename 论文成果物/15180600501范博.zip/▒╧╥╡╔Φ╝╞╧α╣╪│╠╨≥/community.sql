-- MySQL dump 10.13  Distrib 5.7.25, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: community
-- ------------------------------------------------------
-- Server version	5.7.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+08:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '博客编号',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `content` longtext NOT NULL COMMENT '内容',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `read_count` int(11) NOT NULL DEFAULT '0' COMMENT '评论数',
  `user_name` varchar(255) NOT NULL COMMENT '用户名',
  `category_id` int(11) NOT NULL COMMENT '分类编号',
  `category_name` varchar(255) NOT NULL COMMENT '分类名',
  `state` int(1) DEFAULT '0' COMMENT '状态 0:未审核 1:审核通过 -1:不通过',
  `reason` varchar(50) DEFAULT NULL COMMENT '不通过原因',
  PRIMARY KEY (`blog_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='博客信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` (`blog_id`, `title`, `content`, `create_time`, `user_id`, `read_count`, `user_name`, `category_id`, `category_name`, `state`, `reason`) VALUES (1,'“Python太逆天！请救救Java！”今早9万程序员刷爆朋友圈……','<p style=\"text-align:center;\"><img alt=\"\" class=\"has\" src=\"https://img-blog.csdnimg.cn/20190416134103349.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p>\r\n\r\n<p>没想到有生之年，笔者能观察到“霸主陨落”的过程，继PLPY4月榜单官宣，Python躺赢，再度“夺”冠，实力甩下Java和C后，近期，Stack&nbsp;Overflow发布了2019开发者调查报告，也证实了王者陨落这一事实。</p>\r\n\r\n<p>那么，2019年大环境下，程序员群体正在发生哪些变化？收入究竟如何？这份报告邀请超147个国家、9万名开发者参与调查，内容涉及开发者基本情况、技术、工作、社区、方法论多个维度。以下为和正在敲代码的你息息相关的结论。</p>\r\n\r\n<blockquote>\r\n<p><span style=\"color:#f33b45;\"><strong>2019年Python趋势分析：</strong></span></p>\r\n\r\n<p><strong><a href=\"https://edu.csdn.net/topic/python115?utm_source=blog08\" rel=\"nofollow\" target=\"_blank\"><span style=\"color:#f33b45;\">https://edu.csdn.net/topic/python115?utm_source=blog08</span></a></strong></p>\r\n</blockquote>\r\n\r\n<hr><p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style=\"color:#f33b45;\">Python薪资飙升，Java52K垫底</span></strong></p>\r\n\r\n<p><span style=\"color:#f33b45;\"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 超人气PY 3年内狂增速</strong></span></p>\r\n\r\n<p><span style=\"color:#f33b45;\"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 这对程序员意味着什么？</strong></span></p>\r\n\r\n<p>作为全球&nbsp;IT&nbsp;界受欢迎的技术问答社区，Stack&nbsp;Overflow&nbsp;一年一度的开发者报告，则是以全球程序员为对象的规模最大、最全面的调查，今年已经进行到了第九年。</p>\r\n\r\n<p>据报告显示：今年Python增长速度仍是最快，在今年的编程语言排行榜上力压&nbsp;Java，位居第二受喜爱的语言（仅次于&nbsp;Rust），随之带来的，就是薪酬的提升：</p>\r\n\r\n<p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 全球最高薪酬开发者使用的语言</strong></p>\r\n\r\n<p style=\"text-align:center;\"><img alt=\"\" class=\"has\" src=\"https://img-blog.csdnimg.cn/20190416134317677.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>这对程序员意味着，当你选择Pythyon的时候，无疑是选择了一个新兴的编程语言霸主，而且这个霸主目前有大量空缺，谁先入局，谁先享受红利。</p>\r\n\r\n<p>在过去的互联网时代，我们看到太多这样的例子了，举一个简单的说明：<strong><span style=\"color:#f33b45;\">就如10多年前选择Java人和2018年选择做Java的人，所享受的红利和技术的提升绝对相差甚远</span>，</strong>这一点，相信处在编程圈的你我都有这样直观的感受。所以，身为程序员，我们的选择很重要，当Python屠榜时，<span style=\"color:#f33b45;\"><strong>最大的机会，一定是程序员。最直观的感受就是薪资的暴涨！</strong></span></p>\r\n\r\n<p>我们爬取了全国的Python职位，最后发现Python薪资最高的是一线城市，竟然平均月薪高达25K！</p>\r\n\r\n<p>在某勾网随便查看Python，都分分钟让我惊呆！</p>\r\n\r\n<blockquote>\r\n<p><span style=\"color:#f33b45;\"><strong>Python岗位薪资趋势分析：</strong></span></p>\r\n\r\n<p><strong><a href=\"https://edu.csdn.net/topic/python115?utm_source=blog08\" rel=\"nofollow\" target=\"_blank\"><span style=\"color:#f33b45;\">https://edu.csdn.net/topic/python115?utm_source=blog08</span></a></strong></p>\r\n</blockquote>\r\n\r\n<p style=\"text-align:center;\"><img alt=\"\" class=\"has\" src=\"https://img-blog.csdnimg.cn/20190416135523306.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p>\r\n\r\n<p style=\"text-align:center;\"><img alt=\"\" class=\"has\" src=\"https://img-blog.csdnimg.cn/20190416135544455.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p>\r\n\r\n<p>那么当你心动时，一定要了解新霸主Python到底好在哪，才能让90%的程序员都心之所向？</p>\r\n\r\n<hr><p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color:#f33b45;\">&nbsp; &nbsp; Python这些魔力堪称逆天</span></strong></p>\r\n\r\n<p><span style=\"color:#f33b45;\"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 让90%程序员服服帖帖</strong></span></p>\r\n\r\n<p><span style=\"color:#f33b45;\"><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; 你怎么看？</strong></span></p>\r\n\r\n<p>很简单！Python应用太广了！</p>\r\n\r\n<p>能够大展头角的领域涵盖方方面面！<strong>大到航天飞机</strong>，美国航天局(NASA)大规模的使用Python进行数据分析和运算，Google&nbsp;earth、谷歌爬虫、Google广告等项目也都在大量使用Python开发。</p>\r\n\r\n<p style=\"text-align:center;\"><img alt=\"\" class=\"has\" src=\"https://img-blog.csdnimg.cn/20190416135656863.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p>\r\n\r\n<p><strong>小到嵌入式系统</strong>，像之前非常火热的“树莓派”、豆瓣，就是使用Python开发的。数据分析、爬虫、Web开发等众多岗位也是大厂必备项！</p>\r\n\r\n<p>Python代码简洁易懂，同样的内容按照代码量计算，<strong>C++：Java：Python=1000:100:10，其实学习Python意味着，在你的工具库中将获得一个新的强大工具！我还没有见过一个对工具说“不”的程序员，这意味着<strong>劳动力的大大解放，有了更多的精力，才能谋求更多升职加薪、突破个人上限的机会</strong>，不是吗？</strong></p>\r\n\r\n<blockquote>\r\n<p><span style=\"color:#f33b45;\"><strong>Python如何系统学习？</strong></span></p>\r\n\r\n<p><strong><a href=\"https://edu.csdn.net/topic/python115?utm_source=blog08\" rel=\"nofollow\" target=\"_blank\"><span style=\"color:#f33b45;\">https://edu.csdn.net/topic/python115?utm_source=blog08</span></a></strong></p>\r\n</blockquote>\r\n\r\n<hr><p><strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color:#f33b45;\">机器学习和Python是什么关系？</span></strong></p>\r\n\r\n<p>这也是为什么程序员需要学习Python的另一个原因。机器学习的发展在过去的几年中是惊人的，它正在迅速改变我们周围的一切。</p>\r\n\r\n<p>可以说，想学机器学习，Python是必经之路。国家对人工智能的重视，不言而喻。</p>\r\n\r\n<p style=\"text-align:center;\"><img alt=\"\" class=\"has\" src=\"https://img-blog.csdnimg.cn/2019041613581530.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p>\r\n\r\n<p>&nbsp;</p>','2019-05-02 11:51:04',1,4,'第一个用户',10,'数据库',1,'通过'),(15,'12','123','2019-05-02 11:36:34',1,0,'第一个用户',10,'数据库',-1,NULL),(16,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(17,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(18,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(19,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(20,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(21,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(22,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(23,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(24,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(25,'12','123','2019-03-10 05:46:05',1,0,'第一个用户',10,'数据库',0,NULL),(27,'哈哈哈12312','<p>123123</p><p><img src=\"http://127.0.0.1:8010/1552934397171.png\"></p>','2019-05-02 11:48:50',4,0,'第4个',2,'科技前沿',1,NULL),(30,'今天是个好日子','<h1>年底啊</h1><p><br></p><p><br></p><pre class=\"ql-syntax\" spellcheck=\"false\">package com.f22pkj31.community.controller;\n\n\nimport com.f22pkj31.community.entity.*;\nimport com.f22pkj31.community.service.BlogClientService;\nimport org.springframework.beans.factory.annotation.Autowired;\nimport org.springframework.web.bind.annotation.RequestBody;\nimport org.springframework.web.bind.annotation.RequestMapping;\nimport org.springframework.web.bind.annotation.RestController;\n\nimport java.time.LocalDateTime;\n\n/**\n * &lt;p&gt;\n * 前端控制器\n * &lt;/p&gt;\n *\n * @author f22pkj31\n * @since 2019-02-23\n */\n@RestController\n@RequestMapping(\"/blog\")\npublic class BlogController {\n\n    @Autowired\n    private BlogClientService blogClientService;\n\n    @RequestMapping(\"blogList\")\n    public Object blogList(@RequestBody PageIn&lt;Blog&gt; pageIn) {\n        return blogClientService.blogList(pageIn);\n    }\n\n    @RequestMapping(\"sendBlog\")\n    public Object sendBlog(@RequestBody Blog blog) {\n        return blogClientService.sendBlog(blog.setCreateTime(LocalDateTime.now()));\n    }\n\n    @RequestMapping(\"deleteBlog\")\n    public Object deleteBlog(@RequestBody CommonId commonId) {\n        blogClientService.deleteComment(new BlogComment().setBlogId(commonId.getId()));\n        return blogClientService.deleteBlog(commonId);\n    }\n\n    @RequestMapping(\"blogDetail\")\n    public Blog blogDetail(@RequestBody CommonId commonId) {\n        return blogClientService.blogDetail(commonId);\n    }\n\n    @RequestMapping(\"updateBlog\")\n    public Object updateBlog(@RequestBody Blog blog) {\n        return blogClientService.updateBlog(blog.setCreateTime(LocalDateTime.now()));\n    }\n\n    @RequestMapping(\"sendComment\")\n    public Object sendComment(@RequestBody BlogComment blogComment) {\n        CommonId commonId = new CommonId();\n        commonId.setId(blogComment.getBlogId());\n        blogClientService.addReadCount(commonId);\n        return blogClientService.sendComment(blogComment.setCreateTime(LocalDateTime.now()));\n    }\n\n    @RequestMapping(\"commentList\")\n    public Object commentList(@RequestBody PageIn&lt;BlogComment&gt; pageIn) {\n        return blogClientService.commentList(pageIn);\n    }\n\n    @RequestMapping(\"deleteComment\")\n    public Object deleteComment(@RequestBody CommonId commonId) {\n        BlogComment blogComment = blogClientService.commentDetail(commonId);\n        CommonId id = new CommonId();\n        id.setId(blogComment.getBlogId());\n        blogClientService.subReadCount(id);\n        return blogClientService.deleteComment(commonId);\n    }\n\n    @RequestMapping(\"saveCollection\")\n    public Object saveCollection(@RequestBody BlogCollection blogCollection) {\n        return blogClientService.sendCollection(blogCollection.setCreateTime(LocalDateTime.now()));\n    }\n\n    @RequestMapping(\"collectionList\")\n    public Object collectionList(@RequestBody PageIn&lt;BlogCollection&gt; pageIn) {\n        return blogClientService.collectionList(pageIn);\n    }\n\n    @RequestMapping(\"deleteCollection\")\n    public Object deleteCollection(@RequestBody CommonId commonId) {\n        return blogClientService.deleteCollection(commonId);\n    }\n\n    @RequestMapping(\"collectionListByUserId\")\n    public Object collectionListByUserId(@RequestBody PageIn&lt;BlogCollection&gt; pageIn) {\n        return blogClientService.collectionListByUserId(pageIn);\n    }\n\n    @RequestMapping(\"countComment\")\n    public int countComment(@RequestBody CommonId commonId) {\n        return blogClientService.countComment(commonId);\n    }\n\n    @RequestMapping(\"blogListOrderByRead\")\n    public Object blogListOrderByRead(@RequestBody PageIn&lt;Blog&gt; pageIn){\n        return blogClientService.blogListOrderByRead(pageIn);\n    }\n\n    @RequestMapping(\"addReadCount\")\n    public void addReadCount(@RequestBody CommonId commonId) {\n        blogClientService.addReadCount(commonId);\n    }\n\n    @RequestMapping(\"subReadCount\")\n    public void subReadCount(@RequestBody CommonId commonId) {\n        blogClientService.subReadCount(commonId);\n    }\n\n\n}\n</pre><p><img src=\"http://127.0.0.1:8010/1553612314044.png\"></p><iframe class=\"ql-video\" frameborder=\"0\" allowfullscreen=\"true\" src=\"http://127.0.0.1:8010/1553612337854.mp4\"></iframe><p><br></p>','2019-05-02 11:46:29',5,0,'F22PKJ31',4,'架构',1,NULL),(31,'测试','<h1><strong class=\"ql-size-huge\">测试</strong></h1><ul><li>我是测试数据1</li><li>我是测试数据2</li><li>我是测试数据3</li></ul><ol><li>我是厕刷的adf</li><li>asdf</li><li>asdfasdf</li><li>阿斯蒂芬</li><li>阿斯蒂芬</li><li>阿斯蒂芬</li></ol><p>阿斯蒂芬</p><p>阿斯蒂芬</p><p><br></p><p>代码块</p><pre class=\"ql-syntax\" spellcheck=\"false\">public class Test{\n  public static void main(String[] args){\n    System.out.println(\"121231\");\n  }\n}\n</pre><p><br></p><p>图片</p><p><img src=\"http://127.0.0.1:8010/TIM图片20190311024336.png\"></p><p>视频</p><iframe class=\"ql-video\" frameborder=\"0\" allowfullscreen=\"true\" src=\"http://127.0.0.1:8010/321.mp4\"></iframe><p><br></p><p><br></p>','2019-05-02 11:20:16',19,0,'f22pkj31测试',4,'架构',1,NULL),(32,'测试博客','<p>测试博客按打款了深刻的减肥啦</p>','2019-05-16 08:21:10',1,0,'第一个用户',10,'数据库',-1,'内容不充实'),(33,'1234','<p>1234124</p>','2019-05-15 23:26:54',1,0,'第一个用户',3,'生活',1,'通过'),(34,'撰写博客测试','<h1>测试测试<span class=\"ql-cursor\">﻿</span></h1><pre class=\"ql-syntax\" spellcheck=\"false\">margin: 10px 0;text-align: right\" v-show=\"userId!=null\"&gt;\n            &lt;el-input maxlength=\"100\" placeholder=\"请输入回复内容，限制100字\" type=\"textarea\" v-model=\"newComment\"&gt;&lt;/el-input&gt;\n            &lt;el-button @click=\"sendPostComment\" style=\"margin: 10px 0\" type=\"primary\"&gt;回复&lt;/el-button&gt;\n         &lt;/div&gt;\n         &lt;div style=\"margin: 10px 0;text-align: right\" v-show=\"userId==null\"&gt;\n            &lt;el-input maxlength=\"100\" type=\"textarea\" v-model=\"newComment\" disabled&gt;&lt;/el-input&gt;\n            &lt;el-button style=\"margin: 10px 0\" type=\"danger\"&gt;请登录后回复&lt;/el-button&gt;\n         &lt;/div&gt;\n         &lt;div style=\"width: 100%;height: 200px;text-align: center;background-color: #FFFFFF\"\n              v-if=\"commentList==null||commentList.length === 0\"&gt;\n            &lt;h4 style=\"line-height: 200px\"&gt;暂无回复&lt;/h4&gt;\n         &lt;/div&gt;\n         &lt;v-comment :comment=\"comment\" v-for=\"comment in commentList\"&gt;&lt;/v-comment&gt;\n         &lt;el-pagination :current-page=\"current\" :page-size=\"size\" :total=\"total\"\n                        @current-change=\"handleCurrentChange\"\n                        background layout=\"prev, pager, next\"\n                        style=\"float: right\"&gt;\n         &lt;/el-pagination&gt;\n      &lt;/el-main&gt;\n   &lt;/el-container&gt;\n&lt;/template&gt;\n</pre><p><img src=\"http://127.0.0.1:8010/springcloud 微服务 架构图.png\"></p><iframe class=\"ql-video\" frameborder=\"0\" allowfullscreen=\"true\" src=\"http://127.0.0.1:8010/手作羊毛毡1.mp4\"></iframe><p><br></p>','2019-05-15 23:25:59',5,0,'F22PKJ31',3,'生活',1,'通过'),(35,'博客测试','<p><strong><em><s><u>拉萨扩大解放</u></s></em></strong></p><p><span class=\"ql-size-huge\">阿斯顿发大水</span></p><p><br></p><h1><span class=\"ql-size-huge\">阿斯蒂芬</span></h1><p>阿斯蒂芬</p><pre class=\"ql-syntax\" spellcheck=\"false\">public void hh(){\n  \n  }\n</pre><p>1231</p><p><img src=\"http://127.0.0.1:8010/TIM图片20190311024336.png\"></p><p>123123</p><iframe class=\"ql-video\" frameborder=\"0\" allowfullscreen=\"true\" src=\"http://127.0.0.1:8010/手作羊毛毡1.mp4\"></iframe><p><br></p><p>12312</p><p><br></p>','2019-05-19 18:24:05',28,0,'test2',3,'生活',0,NULL),(36,'123','<p>123123</p>','2019-05-19 18:26:12',28,0,'test2',2,'科技前沿',0,NULL),(37,'123','<p>123123</p>','2019-05-19 18:26:28',28,0,'test2',4,'架构',0,NULL),(39,'www','<p><strong><em><s><u>assfdfasasdf </u></s></em></strong></p><p><strong><em><s><u>a</u></s></em></strong></p><p><strong><em><s><u>sdf asdf as</u></s></em></strong></p><p><br></p><p><img src=\"http://127.0.0.1:8010/TIM图片20190311024336.png\"></p><iframe class=\"ql-video\" frameborder=\"0\" allowfullscreen=\"true\" src=\"http://127.0.0.1:8010/手作羊毛毡1.mp4\"></iframe><p><br></p>','2019-05-19 20:55:17',36,0,'www',3,'生活',1,'通过'),(40,'阿斯蒂芬','<p><strong><em><u>啊手动阀手动阀</u></em></strong></p><p><strong><em><u>啊手动阀sd</u></em></strong></p><p><br></p><h1>啊手动阀<span class=\"ql-size-huge\">啊手动阀</span></h1><p><br></p><pre class=\"ql-syntax\" spellcheck=\"false\">a阿斯顿发射点\n</pre><p><br></p><p><br></p><p><img src=\"http://127.0.0.1:8010/TIM图片20190311024341.png\"></p><iframe class=\"ql-video\" frameborder=\"0\" allowfullscreen=\"true\" src=\"http://127.0.0.1:8010/手作羊毛毡1.mp4\"></iframe><p><br></p>','2019-05-19 21:42:37',37,0,'hhh',2,'科技前沿',1,'12312');
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_collection`
--

DROP TABLE IF EXISTS `blog_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_collection` (
  `collection_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `blog_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `blog_title` varchar(255) NOT NULL,
  PRIMARY KEY (`collection_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_collection`
--

LOCK TABLES `blog_collection` WRITE;
/*!40000 ALTER TABLE `blog_collection` DISABLE KEYS */;
INSERT INTO `blog_collection` (`collection_id`, `user_id`, `user_name`, `blog_id`, `create_time`, `blog_title`) VALUES (20,19,'f22pkj31测试',30,'2019-04-06 13:13:52','今天是个好日子'),(21,1,'第一个用户',27,'2019-05-02 16:16:24','哈哈哈12312'),(22,28,'test2',1,'2019-05-19 18:21:28','“Python太逆天！请救救Java！”今早9万程序员刷爆朋友圈……'),(26,37,'hhh',39,'2019-05-19 21:52:13','www');
/*!40000 ALTER TABLE `blog_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_comment`
--

DROP TABLE IF EXISTS `blog_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `blog_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `blog_title` varchar(255) NOT NULL,
  PRIMARY KEY (`comment_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_comment`
--

LOCK TABLES `blog_comment` WRITE;
/*!40000 ALTER TABLE `blog_comment` DISABLE KEYS */;
INSERT INTO `blog_comment` (`comment_id`, `content`, `user_id`, `create_time`, `blog_id`, `user_name`, `blog_title`) VALUES (1,'哇！Python好强',5,'2019-05-15 23:02:33',1,'F22PKJ31','“Python太逆天！请救救Java！”今早9万程序员刷爆朋友圈……'),(2,'wawawa',28,'2019-05-19 18:21:33',1,'test2','“Python太逆天！请救救Java！”今早9万程序员刷爆朋友圈……'),(3,'怕怕怕',29,'2019-05-19 18:33:00',1,'test3','“Python太逆天！请救救Java！”今早9万程序员刷爆朋友圈……'),(4,'啊科技时代李开复',37,'2019-05-19 21:34:48',1,'hhh','“Python太逆天！请救救Java！”今早9万程序员刷爆朋友圈……');
/*!40000 ALTER TABLE `blog_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`category_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`category_id`, `category_name`, `create_time`) VALUES (2,'科技前沿','2019-03-10 08:21:33'),(3,'生活','2019-03-10 08:21:34'),(4,'架构','2019-03-05 00:00:00'),(5,'前端','2019-03-05 00:00:00'),(10,'数据库','2019-03-10 08:21:31');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `head_img`
--

DROP TABLE IF EXISTS `head_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `head_img` (
  `head_id` int(11) NOT NULL AUTO_INCREMENT,
  `img_url` varchar(255) NOT NULL,
  `news_id` int(11) NOT NULL,
  PRIMARY KEY (`head_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `head_img`
--

LOCK TABLES `head_img` WRITE;
/*!40000 ALTER TABLE `head_img` DISABLE KEYS */;
INSERT INTO `head_img` (`head_id`, `img_url`, `news_id`) VALUES (1,'http://127.0.0.1:8010/0b064fc36751986d01a28558778fbf01.jpg',1),(2,'http://127.0.0.1:8010/e1550a30540e7df0b574eb15413d8d88.jpg',11),(3,'http://127.0.0.1:8010/40ed0b8f3e367719cd00c012b01f5fdb.jpg',3);
/*!40000 ALTER TABLE `head_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_count` bigint(255) NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `category_id` int(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `state` int(1) DEFAULT '0' COMMENT '状态 0:未审核 1:审核通过 -1:不通过',
  `reason` varchar(50) DEFAULT NULL COMMENT '不通过原因',
  PRIMARY KEY (`news_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` (`news_id`, `title`, `user_id`, `read_count`, `content`, `create_time`, `category_id`, `category_name`, `user_name`, `img_url`, `state`, `reason`) VALUES (1,'Java 跌落神坛！Python 正式登顶世界第一编程语言1',2,5,'<p>编程语言流行指数(PYPL)排行榜近日公布了2019年2月份榜单。</p><p>在最新一期榜单上，Python的份额高达26.42％，<strong>稳居第一，并且猛增5.2%，同时成为增长势头最好的语言。</strong>而被挤到第二的Java，目前份额为21.2％，同比下跌1.3个百分点 。</p><p class=\"ql-align-center\"><img src=\"https://img-blog.csdnimg.cn/20190313151915794.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p><blockquote><strong style=\"color: rgb(243, 59, 69);\">Python学习指南：</strong></blockquote><blockquote><a href=\"https://edu.csdn.net/topic/python115?utm_source=blog08\" target=\"_blank\" style=\"color: rgb(243, 59, 69);\"><strong><u>https://edu.csdn.net/topic/python115?utm_source=blog08</u></strong></a><strong style=\"color: rgb(243, 59, 69);\"><u> </u></strong></blockquote><p>圈内知名网站Stack Overflow的数据显示，<strong>其实早在去年6月份，Python的月活用户就已超越了Java、JavaScript，成为第一。</strong>IEEE Spectrum也在2018年度顶级编程语言排行榜上将Python列为第一，领先C++、C、Java、C#。</p><p>Python火起来不是没有原因的，另一个报告做了一个有趣的调查。</p><p>Hired 网站近日发布了“2019 年软件工程师现状”报告。其中开发者最爱与最讨厌的编程语言——<strong>最爱 Python，最讨厌&nbsp;PHP</strong>。PHPer 能忍？哈哈</p><p class=\"ql-align-center\"><img src=\"https://img-blog.csdnimg.cn/2019031315194133.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p><p>开发者最想学习的技术/技能——机器学习。</p><p class=\"ql-align-center\"><img src=\"https://img-blog.csdnimg.cn/20190313152008334.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p><p>&nbsp;</p><p>那么我们就顺势来分析一下吧。</p><blockquote><strong style=\"color: rgb(243, 59, 69);\">2019年Python程序员薪资发展趋势：</strong></blockquote><blockquote><a href=\"https://edu.csdn.net/topic/python115?utm_source=blog08\" target=\"_blank\" style=\"color: rgb(243, 59, 69);\"><strong><u>https://edu.csdn.net/topic/python115?utm_source=blog08</u></strong></a></blockquote><h3><strong>一、为什么大家如此喜欢Python？</strong></h3><p>Python能够大展头角的领域涵盖方方面面。</p><p><strong>大到航天飞机</strong>，美国航天局(NASA)大规模的使用Python进行数据分析和运算，Google earth、谷歌爬虫、Google广告等项目也都在大量使用Python开发。</p><p class=\"ql-align-center\"><img src=\"https://img-blog.csdnimg.cn/20190313152049576.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p><p><strong>小到嵌入式系统</strong>，像之前非常火热的“树莓派”、豆瓣，就是使用Python开发的。</p><p>Python代码简洁易懂，同样的内容按照代码量计算，<strong>C++：Java：Python=1000:100:10，其实学习Python意味着，在你的工具库中将获得一个新的强大工具！我还没有见过一个对工具说“不”的程序员，这意味着劳动力的大大解放，有了更多的精力，才能谋求更多升职加薪、突破个人上限的机会，不是吗？</strong></p><blockquote><strong style=\"color: rgb(243, 59, 69);\">python如何学？专业老师一对一规划辅导：</strong></blockquote><blockquote><a href=\"https://edu.csdn.net/topic/python115?utm_source=blog08\" target=\"_blank\" style=\"color: rgb(243, 59, 69);\"><strong><u>https://edu.csdn.net/topic/python115?utm_source=blog08</u></strong></a><strong style=\"color: rgb(243, 59, 69);\">&nbsp;</strong></blockquote><h3><strong>二、机器学习和Python是什么关系？</strong></h3><p>这也是为什么程序员需要学习Python的另一个原因。机器学习的发展在过去的几年中是惊人的，它正在迅速改变我们周围的一切。</p><p>可以说，想学机器学习，Python是必经之路。国家对人工智能的重视，不言而喻。</p><p class=\"ql-align-center\"><img src=\"https://img-blog.csdnimg.cn/20190313152140231.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p><p>&nbsp;</p><p>所以你准备好学习Python了吗？你打算怎么开始，怎么发展呢？</p><h3><strong>三、Python全栈工程师实训营来了！</strong></h3><p>区别于其他培训的单一教学，在CSDN的全栈实训营中，你在学会Python后，<strong>更能学到很多重要领域技术（如Linux服务器、MySQL数据库、Web、机器学习……）</strong>。而这些，<strong>都是在找工作、加薪、跳槽过程中，战胜别人的核心技能壁垒和个人资本</strong>。</p><p>另外，即使你不是计算机专业出身，只要按照CSDN规划出来的Python学习路线，每天有计划的进行学习，那么成为一名合格的Python工程师并不难！如果你已经是一名开发者，那么学习Python的速度可以加快两倍！</p><p><strong>CSDN学院推出「Python 全栈工程师实训营」，就是为了让更多零基础的学习者，可以在4个月内掌握Python全栈，并拥有真正的软件编程工作能力，追求梦想岗位。</strong></p><p>CSDN还提供以下服务：</p><p>1、每周直播+定期知识点大串讲，老师帮你捋脉络；</p><p>2、社群助教+导师+班主任全天候答疑服务，你的问题永远不过夜；</p><p>3、科学且系统化的学习路线，闯关式学习，保证学习效率。</p><p><strong>联系CSDN学院小姐姐</strong></p><p><strong>获取一对一专属服务</strong></p><p><strong>包含Python学习规划服务+专属折扣</strong></p><p class=\"ql-align-center\"><img src=\"https://img-blog.csdnimg.cn/2019031315222874.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0NTRE5lZHU=,size_16,color_FFFFFF,t_70\"></p><p>&nbsp;</p><blockquote><strong style=\"color: rgb(243, 59, 69);\">程序员转型测试，你是否适合转Python：</strong></blockquote><blockquote><a href=\"https://edu.csdn.net/topic/python115?utm_source=blog08\" target=\"_blank\" style=\"color: rgb(243, 59, 69);\"><u>https://edu.csdn.net/topic/python115?utm_source=blog08</u></a><strong style=\"color: rgb(243, 59, 69);\"><u> </u>&nbsp;&nbsp;</strong></blockquote><p>&nbsp;</p>','2019-05-02 12:37:34',2,'科技前沿','科技新闻','http://localhost:8010/201902281740116853.jpg',1,'优秀'),(2,'1231',2,12,'<p>12341234</p>','2019-05-19 11:16:57',2,'科技前沿','科技新闻','http://127.0.0.1:8010/39A62EC81CC13BBA20B352366C90F46A.jpg',1,''),(3,'1231',2,1,'12341234','2019-05-02 12:40:49',3,'生活','科技新闻','http://localhost:8010/201902281740116853.jpg',0,''),(4,'1231',2,0,'12341234','2019-05-02 12:40:50',3,'生活','科技新闻','http://localhost:8010/201902281740116853.jpg',1,''),(5,'1231',2,0,'12341234','2019-05-02 12:40:54',3,'生活','科技新闻','http://localhost:8010/201902281740116853.jpg',1,''),(9,'1231',2,0,'12341234','2019-05-02 12:41:08',10,'数据库','科技新闻','http://localhost:8010/201902281740116853.jpg',0,''),(10,'1231',2,0,'12341234','2019-05-02 12:41:14',10,'数据库','科技新闻','http://localhost:8010/201902281740116853.jpg',-1,''),(11,'12319999',2,0,'12341234','2019-05-02 12:41:09',10,'数据库','科技新闻','http://localhost:8010/201902281740116853.jpg',-1,''),(12,'1231',2,0,'12341234','2019-05-02 12:41:20',10,'数据库','科技新闻','http://localhost:8010/201902281740116853.jpg',-1,''),(13,'123',5,0,'<p>1232132</p>','2019-05-19 21:44:58',2,'科技前沿','F22PKJ31','http://127.0.0.1:8010/39A62EC81CC13BBA20B352366C90F46A.jpg',0,NULL);
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_collection`
--

DROP TABLE IF EXISTS `news_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news_collection` (
  `collection_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `news_title` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  PRIMARY KEY (`collection_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_collection`
--

LOCK TABLES `news_collection` WRITE;
/*!40000 ALTER TABLE `news_collection` DISABLE KEYS */;
INSERT INTO `news_collection` (`collection_id`, `news_id`, `user_id`, `create_time`, `news_title`, `user_name`) VALUES (16,1,4,'2019-03-26 09:52:43','Java 跌落神坛！Python 正式登顶世界第一编程语言','第4个'),(19,1,1,'2019-05-02 16:16:03','Java 跌落神坛！Python 正式登顶世界第一编程语言1','第一个用户'),(22,1,28,'2019-05-19 18:20:07','Java 跌落神坛！Python 正式登顶世界第一编程语言1','test2'),(23,1,29,'2019-05-19 18:32:00','Java 跌落神坛！Python 正式登顶世界第一编程语言1','test3'),(25,3,35,'2019-05-19 19:10:10','1231','qqqq'),(27,1,37,'2019-05-19 21:33:26','Java 跌落神坛！Python 正式登顶世界第一编程语言1','hhh');
/*!40000 ALTER TABLE `news_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_comment`
--

DROP TABLE IF EXISTS `news_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `news_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `news_title` varchar(255) NOT NULL,
  PRIMARY KEY (`comment_id`) USING BTREE,
  KEY `news_comment_user_user_id_user_name_fk` (`user_id`,`user_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_comment`
--

LOCK TABLES `news_comment` WRITE;
/*!40000 ALTER TABLE `news_comment` DISABLE KEYS */;
INSERT INTO `news_comment` (`comment_id`, `content`, `user_id`, `create_time`, `news_id`, `user_name`, `news_title`) VALUES (2,'抢沙发',28,'2019-05-19 18:20:19',1,'test2','Java 跌落神坛！Python 正式登顶世界第一编程语言1'),(3,'123123',28,'2019-05-19 18:21:13',1,'test2','Java 跌落神坛！Python 正式登顶世界第一编程语言1'),(4,'评论2222',29,'2019-05-19 18:32:10',1,'test3','Java 跌落神坛！Python 正式登顶世界第一编程语言1'),(5,'aslkdjflk',32,'2019-05-19 18:47:26',2,'user1','1231'),(6,'aksdlkasf',33,'2019-05-19 18:50:53',2,'user01','1231'),(7,'123',33,'2019-05-19 18:51:18',2,'user01','1231'),(8,'123',33,'2019-05-19 18:51:20',2,'user01','1231'),(9,'123',33,'2019-05-19 18:55:39',2,'user01','1231'),(10,'123',33,'2019-05-19 18:55:44',2,'user01','1231'),(11,'士大夫给',33,'2019-05-19 18:55:49',2,'user01','1231'),(12,'123',33,'2019-05-19 18:56:53',2,'user01','1231'),(13,'哈哈哈',33,'2019-05-19 18:58:25',2,'user01','1231'),(14,'123',27,'2019-05-19 19:00:22',2,'test1','1231'),(15,'123123',27,'2019-05-19 19:00:29',2,'test1','1231'),(16,'1231',27,'2019-05-19 19:00:51',2,'test1','1231'),(18,'askjdlf',34,'2019-05-19 19:03:25',1,'user22','Java 跌落神坛！Python 正式登顶世界第一编程语言1'),(20,'123123',35,'2019-05-19 19:09:58',3,'qqqq','1231'),(23,'就哈萨克等级划分',37,'2019-05-19 21:33:34',1,'hhh','Java 跌落神坛！Python 正式登顶世界第一编程语言1');
/*!40000 ALTER TABLE `news_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `read_count` int(255) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `user_name` varchar(255) NOT NULL,
  `state` int(1) DEFAULT '0' COMMENT '状态 0:未审核 1:审核通过 -1:不通过',
  `reason` varchar(50) DEFAULT NULL COMMENT '不通过原因',
  PRIMARY KEY (`post_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` (`post_id`, `title`, `content`, `user_id`, `read_count`, `create_time`, `user_name`, `state`, `reason`) VALUES (1,'真好','<p><img src=\"http://127.0.0.1:8010/1553447186768.jpg\"></p>',1,1,'2019-05-02 14:32:18','第一个用户',1,''),(2,'123','123',1,5,'2019-05-02 14:32:20','第一个用户',1,''),(6,'123','123',1,0,'2019-05-02 14:33:09','第一个用户',0,''),(7,'123','123',1,0,'2019-05-02 14:33:12','第一个用户',-1,''),(8,'123','123',1,0,'2019-05-02 14:33:11','第一个用户',-1,''),(9,'123','123',1,0,'2019-05-02 14:33:14','第一个用户',-1,''),(10,'123','123',1,0,'2019-05-15 23:33:03','第一个用户',-1,'通个'),(11,'123','123',1,0,'2019-05-02 14:33:18','第一个用户',-1,''),(12,'123','<p>1234</p>',1,0,'2019-05-02 14:48:10','第一个用户',-1,''),(13,'测试','<p><img src=\"http://127.0.0.1:8010/1553449068545.png\"></p><p>今天真开心</p>',4,0,'2019-05-02 14:32:16','第4个',1,'');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_collection`
--

DROP TABLE IF EXISTS `post_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_collection` (
  `collection_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `post_title` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  PRIMARY KEY (`collection_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_collection`
--

LOCK TABLES `post_collection` WRITE;
/*!40000 ALTER TABLE `post_collection` DISABLE KEYS */;
INSERT INTO `post_collection` (`collection_id`, `post_id`, `user_id`, `create_time`, `post_title`, `user_name`) VALUES (5,13,19,'2019-04-06 13:35:51','测试','f22pkj31测试'),(6,1,36,'2019-05-19 20:49:03','真好','www');
/*!40000 ALTER TABLE `post_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_comment`
--

DROP TABLE IF EXISTS `post_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `user_name` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  PRIMARY KEY (`comment_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_comment`
--

LOCK TABLES `post_comment` WRITE;
/*!40000 ALTER TABLE `post_comment` DISABLE KEYS */;
INSERT INTO `post_comment` (`comment_id`, `post_title`, `content`, `user_id`, `create_time`, `user_name`, `post_id`) VALUES (1,'123','恩恩是的',19,'2019-05-15 22:37:17','f22pkj31测试',2),(2,'123','晚上大是大非',19,'2019-05-15 22:37:23','f22pkj31测试',2),(3,'123','阿斯顿发斯蒂芬',19,'2019-05-15 22:37:25','f22pkj31测试',2),(5,'123','卡萨丁劫分类阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯蒂芬阿斯顿发是的阿斯蒂芬劫分类阿斯蒂芬阿',19,'2019-05-15 22:42:05','f22pkj31测试',2),(6,'真好','132132',36,'2019-05-19 20:49:09','www',1),(7,'123','阿斯顿发射点',37,'2019-05-19 21:38:28','hhh',2);
/*!40000 ALTER TABLE `post_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `age` varchar(2) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `sex` varchar(4) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`user_id`, `user_name`, `passwd`, `mobile`, `age`, `email`, `sex`, `create_time`, `img_url`) VALUES (1,'第一个用户','12','12','12','12','男','2019-05-02 16:14:39','http://127.0.0.1:8010/TIM图片20190217214613.jpg'),(2,'科技新闻','admin','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(3,'用户1','12','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(4,'第4个','123','12','12','12','男','2019-03-27 03:51:38','http://127.0.0.1:8010/319002617.jpg'),(5,'F22PKJ31','12','15242181696','22','f22pkj31@foxmail.com','男','2019-05-19 10:46:37','http://127.0.0.1:8010/39A62EC81CC13BBA20B352366C90F46A.jpg'),(6,'第6个','12','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(7,'第7个','12','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(8,'第8个','12','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(9,'第9个','12','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(10,'第10个','12','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(11,'第11个','12','12','12','12','男','1970-01-02 00:00:00','http://127.0.0.1:8010/319002617.jpg'),(12,'第12个','444','123123','12','12','12','2019-03-27 03:54:51','http://127.0.0.1:8010/319002617.jpg'),(15,'第13个','12341234','1234','12','12','男','2019-03-10 12:27:09','http://127.0.0.1:8010/319002617.jpg'),(19,'f22pkj31测试','123123123','13131313131','23','123123123','女','2019-05-02 17:06:38','http://127.0.0.1:8010/39A62EC81CC13BBA20B352366C90F46A.jpg'),(27,'test1','test','1213','21','11@qq.com','男','2019-05-19 19:00:39','http://127.0.0.1:8010/319002617.jpg'),(28,'test2','test','13131313131','22','1311@qq.com','男','2019-05-19 18:19:35','http://127.0.0.1:8010/123.png'),(29,'test3','test3','13188888888','22','11@qq.com','男','2019-05-19 18:29:50','http://127.0.0.1:8010/123.png'),(30,'rrr','rrr','',NULL,'','','2019-05-19 18:43:12',NULL),(31,'test11','test11','','12','','女','2019-05-19 18:44:28',NULL),(32,'user1','user','10086','10','10086@qq.com','男','2019-05-19 18:47:07','http://127.0.0.1:8010/39A62EC81CC13BBA20B352366C90F46A.jpg'),(33,'user01','123','1313','22','0010@qq.com','男','2019-05-19 19:00:04','http://127.0.0.1:8010/39A62EC81CC13BBA20B352366C90F46A.jpg'),(34,'user22','user','10010','22','10010@qq.com','男','2019-05-19 19:02:41','http://127.0.0.1:8010/TIM图片20190217214128.jpg'),(35,'qqqq','qq','10000','10','100@qq.com','男','2019-05-19 19:08:57','http://127.0.0.1:8010/TIM图片20190217214613.jpg'),(36,'www','ww','10000','41','100@qq.com','男','2019-05-19 20:46:40','http://127.0.0.1:8010/TIM图片20190217214613.jpg'),(37,'hhh','hh','132132','20','112321@qq.com','男','2019-05-19 21:33:08','http://127.0.0.1:8010/TIM图片20190407220743.png');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-19 23:31:07
