package com.f22pkj31.community.entity;

import lombok.Data;

@Data
public class UploadResp {

    private String error;

    private String url;

}
