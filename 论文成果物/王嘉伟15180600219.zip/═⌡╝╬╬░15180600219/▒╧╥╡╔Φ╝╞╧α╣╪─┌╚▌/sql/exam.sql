INSERT INTO `exam` VALUES (1, '001', '英语', '2013-12-18', NULL, NULL, 1, NULL, '已结束');
INSERT INTO `exam` VALUES (2, '002', '语文', '2013-12-18', NULL, NULL, 2, NULL, '考试中');
INSERT INTO `exam` VALUES (3, '003', '数学', '2013-12-18', NULL, NULL, 3, NULL, '考试中');
INSERT INTO `exam` VALUES (4, '004', 'java', '2013-12-18', NULL, NULL, 4, NULL, '考试中');
INSERT INTO `exam` VALUES (5, '005', 'h5', '2013-12-18', NULL, NULL, 5, NULL, '考试中');
