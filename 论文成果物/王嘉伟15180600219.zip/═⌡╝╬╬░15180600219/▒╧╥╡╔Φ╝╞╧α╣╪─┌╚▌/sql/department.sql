INSERT INTO `department` VALUES (1, '矿冶工程学院');
INSERT INTO `department` VALUES (2, '政治学院');
INSERT INTO `department` VALUES (3, '计算机学院');
INSERT INTO `department` VALUES (4, 'java');
