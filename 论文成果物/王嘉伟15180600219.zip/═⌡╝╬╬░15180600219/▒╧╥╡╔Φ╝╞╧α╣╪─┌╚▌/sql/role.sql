INSERT INTO `role` VALUES (1, '班主任', 1);
INSERT INTO `role` VALUES (2, '讲师', 1);
INSERT INTO `role` VALUES (4, '院长', 1);
INSERT INTO `role` VALUES (5, '超级管理员', 1);
INSERT INTO `role` VALUES (6, '班主任主管', 1);
INSERT INTO `role` VALUES (7, '管理员', 1);
INSERT INTO `role` VALUES (12, '班主任2', 1);
