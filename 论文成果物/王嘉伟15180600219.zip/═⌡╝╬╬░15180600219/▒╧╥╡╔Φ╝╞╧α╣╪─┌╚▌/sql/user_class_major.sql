INSERT INTO `user_class_major` VALUES (1, 1, 1, 1);
INSERT INTO `user_class_major` VALUES (2, 2, 2, 2);
INSERT INTO `user_class_major` VALUES (3, 3, 3, 3);
INSERT INTO `user_class_major` VALUES (4, 4, 1, 1);
INSERT INTO `user_class_major` VALUES (5, 5, 1, 1);
