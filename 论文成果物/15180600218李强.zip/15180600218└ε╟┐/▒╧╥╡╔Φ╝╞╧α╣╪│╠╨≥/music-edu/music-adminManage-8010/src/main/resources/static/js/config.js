'use strict';

var config = {

    //接口地址
    serverUrl: window.location.protocol + "//" + window.location.host+"/admin",

    //接口应用
    serverApp: 'pasture-api',
    //文件资源
    serverFile:'/music/download/',

};

// 接口地址
var serverUrl = config.serverUrl;
// 接口地址
var serverApp = config.serverApp;
var serverFile = config.serverFile;
