package com.dao;

import java.util.List;

import com.entity.guanjianzi;

public interface guanjianziMapper {
  List<guanjianzi> findAllGuanjianzi();
}
