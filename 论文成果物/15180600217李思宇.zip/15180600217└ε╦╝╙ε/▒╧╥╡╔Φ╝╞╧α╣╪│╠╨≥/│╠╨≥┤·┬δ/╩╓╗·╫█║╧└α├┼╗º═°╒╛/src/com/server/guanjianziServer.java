package com.server;

import java.util.List;

import com.entity.guanjianzi;

public interface guanjianziServer {
 public List<guanjianzi> findAllGuanjianzi();
}
