package com.clps.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.clps.Reposity.PostReposity;
import com.clps.mapper.CommentMapper;
import com.clps.mapper.PostMapper;
import com.clps.model.Ad;
import com.clps.model.Comment;
import com.clps.model.Poster;
import com.clps.model.User;
import com.clps.model.adopt;

@Service
public class PostService {
	@Autowired
	private PostMapper postMapper;
	@Autowired
	private CommentMapper commentMapper;
	@Autowired
	private PostReposity postReposity;
	public int comPost(Integer postId,String postCom,String postDate)
	{
		return postMapper.comPost(postId,postCom,postDate);
	}
	public List<Comment> findComById(Integer postId)
	{
		return commentMapper. findComById(postId);
	}
	@Transactional
	public Poster findPoster(Integer postId)
	{
		return postMapper.findPoster(postId);
	}
	
	public User findById(Integer id)
	{
		return postMapper.findById(id);
	}
	public int addAdopt(Integer postId, Integer ownerId, Integer appId, String appName) {
		// TODO Auto-generated method stub
		return postMapper.addAdopt(postId,ownerId,appId,appName);
	}
	public int delPoster(Integer postId) {
		// TODO Auto-generated method stub
		return postMapper.delPoster(postId);
	}
	@Cacheable(value="posters")
	public List<Poster> findTopFourPosters()
	{
		return postMapper.findTopFourPosters();
	}
	@CacheEvict(value="posters",allEntries=true)
	public int addComCount(Integer postId) {
		// TODO Auto-generated method stub
		return postMapper.addComCount(postId);
	}
	public Page<Poster> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return postReposity.findAll(pageable);
	}
	public List<adopt> findAppingPosters(Integer ownerId) {
		// TODO Auto-generated method stub
		return postMapper.findAppingPosters(ownerId);
	}
	public List<Poster> findAppPosters(Integer ownerId) {
		// TODO Auto-generated method stub
		return  postMapper.findAppPosters(ownerId);
	}
	public void changePosterStatu(Integer i) {
		// TODO Auto-generated method stub
		postMapper.delPoster(i);
	}
	public int findPoster1() {
		// TODO Auto-generated method stub
	return	postMapper.findPoster1();
	}
	public int findPoster2() {
		// TODO Auto-generated method stub
		return	postMapper.findPoster2();
	}
	public int findAllPoster1() {
		// TODO Auto-generated method stub
		return	postMapper.findAllPoster1();
	}
	public int findUserCount() {
		// TODO Auto-generated method stub
		return postMapper.findUserCount();
	}
	public void adAdd(String text,String time) {
		// TODO Auto-generated method stub
		System.out.println("In service"+time+text);
		postMapper.adAdd(text,time);
	}
	public List<Ad> findAllAds() {
		// TODO Auto-generated method stub
		return postMapper.findAllAds();
	}
	public Ad findRecentAd() {
		// TODO Auto-generated method stub
		return postMapper.findRecentAd();
	}
}
