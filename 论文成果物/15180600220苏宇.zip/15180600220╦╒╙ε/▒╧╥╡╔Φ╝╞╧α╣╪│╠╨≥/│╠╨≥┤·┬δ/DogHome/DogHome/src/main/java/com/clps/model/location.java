package com.clps.model;

public class location {
private Integer locatId;
private String locatName;
public Integer getLocatId() {
	return locatId;
}
public void setLocatId(Integer locatId) {
	this.locatId = locatId;
}
public location(Integer locatId, String locatName) {
	super();
	this.locatId = locatId;
	this.locatName = locatName;
}
@Override
public String toString() {
	return "location [locatId=" + locatId + ", locatName=" + locatName + "]";
}
public String getLocatName() {
	return locatName;
}
public void setLocatName(String locatName) {
	this.locatName = locatName;
}
}
