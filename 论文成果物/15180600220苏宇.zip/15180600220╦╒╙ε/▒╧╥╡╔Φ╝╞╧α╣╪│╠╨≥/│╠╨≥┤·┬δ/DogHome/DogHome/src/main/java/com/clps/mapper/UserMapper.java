package com.clps.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.clps.model.Poster;
import com.clps.model.User;
import com.clps.model.adopt;
import com.clps.model.dogType;
import com.clps.model.location;
import com.clps.model.reInfo;

public interface UserMapper {
	@Select("SELECT * FROM USER WHERE USERNAME = #{userName}")
	User findByName(@Param("userName") String userName);
	/*@Insert("INSERT INTO USER(NAME, AGE) VALUES(#{name}, #{age})")
	int insert(@Param("name") String name, @Param("age") Integer age);*/
	/*@Select("SELECT * FROM USER WHERE USER")*/
	@Select("SELECT * FROM USER WHERE USERId = #{userId}")
	User findUserById(Integer userId);
	@Update("update USER SET userAge=#{userAge},IDCardNum=#{idCardNum},"
			+ "USERPHONE=#{userPhone},USERLOCATION=#{userLocation},USERPASS=#{userPass},userEmail=#{userEmail} "
			+ "WHERE USERID=#{userId}")
	int updateInfoById(@Param("userId")Integer userId, @Param("userAge")String userAge,
@Param("idCardNum") String idCardNum, @Param("userPhone")String userPhone, 
@Param("userLocation")String userLocation,@Param("userPass")String userPass,@Param("userEmail")String userEmail);
	@Select("SELECT * FROM POST WHERE ownerId =#{userId}")
	List<Poster> findPostByOwnerId(Integer userId);
	@Insert("Insert into user values(null,#{userName},#{userAge},#{userPass},#{userPhone},#{idCardNum},#{userLocation},0,#{userEmail})")
	int register(@Param("userName")String userName,@Param("userPass") String userPass,@Param("userAge") String userAge, @Param("userPhone")String userPhone, @Param("idCardNum")String idCardNum,
			@Param("userLocation")String userLocation,@Param("userEmail")String userEmail);
	@Select("SELECT count(*) FROM user where userName =#{userName}")
	int findUserByName(@Param("userName")String userName);
	@Select("Select postId,appName from adopt where ownerId=#{userId}")
	List<Map<Integer, String>> findAdopterName(Integer userId);
	@Select("select postId from adopt where ownerId = #{userId}")
	List<Integer> findAppId(Integer userId);
	@Select("select appName from adopt where postId = #{integer}")
	String findAppnameByPostId(Integer integer);
	@Select("select * from adopt where ownerId = #{userId} ")
	List<adopt> findAppNamesByOwnerId(Integer userId);
	@Update("update  adopt set flag=1 where id =#{id}")
	void setPostTry(Integer id);
	@Update("update post set flag=1 where postId =#{postId}")
	void setPosterTry(Integer postId);
	@Update("update  adopt set flag=0 where id =#{id}")
	void setPostTryRefuse(Integer id);
	@Update("update post set flag=0 where postId =#{postId}")
	void setPosterTryRefuse(Integer postId);
	@Select("select * from user ")
	List<User> findAllUser();
	@Update("update user set flag=2 where userName=#{s}")
	void changeUserStatu(String s);
	@Update("update user set flag=6 where userName=#{s}")
	void changeUserStatuToHasPushReInfo(String s);
	@Select("select * from adopt where flag=1 and appId=#{appId}")
	adopt findReInfo(Integer appId);
	@Select("select * from post where flag=1 and postId=#{postId}")
	Poster findPosterById(Integer postId);
	@Insert("Insert into reinfo values(null,#{postId},#{title},#{suffix},#{fileName},#{ownerId},#{ownerName},#{appName},#{content},0)")
	int addReInfo(@Param("postId")Integer postId,@Param("title") String title, @Param("suffix")String suffix, @Param("fileName")String fileName,@Param("ownerId") Integer ownerId, @Param("ownerName")String ownerName,
			@Param("appName")String appName,@Param("content")String content);
	@Select("select * from reInfo where postId=#{postId}")
	reInfo findReInfoDetail(Integer postId);
	@Delete("delete  from adopt where postId=#{postId}")
	void setAdoptFlagTwo(@Param("postId")Integer postId);
	@Update("update post set flag=2 where postId=#{postId}")
	void setPosterFlagTwo(@Param("postId")Integer postId);
	@Update("update reInfo set flag=2 where postId=#{postId}")
	void setReInfoFlagTwo(@Param("postId")Integer postId);
	@Select("select userEmail from user where userId  =#{appId}")
	String findEmailByUserId(Integer appId);
	@Select("select appId from adopt where id=#{id}")
	Integer findEmailByAdoptId(Integer id);
	@Update("update  adopt set flag=3 where postId =#{postId}")
	void setAdoptFlagThree(Integer postId);
	@Update("update post set flag=0 where postId=#{postId}")
	void setPosterFlagZero(@Param("postId")Integer postId);
	@Update("update reInfo set flag=3 where postId=#{postId}")
	void setReInfoFlagThree(@Param("postId")Integer postId);
	@Select("select appId from adopt where id =#{id}")
	Integer findUserFlagFour(Integer id);
	@Update("update user set flag=4  where userId =#{userId}")
	void setUserFlagFour(Integer userId);
	@Update("update user set flag=0  where userId =#{userId}")
	void setUserFlagZero(Integer appId);
	@Select("select * from dogtype")
	List<dogType> findDogTypes();
	@Select("select * from location")
	List<location> findLocations();
	@Insert("Insert into dogType(typeName) values(#{typeName})")
	void addDog(String typeName);
	@Insert("Insert into location(locatName) values(#{typeName})")
	void addLocate(String locatName);
	@Insert("Insert into chat values(null,#{fromUsername},#{toUsername},#{time})")
	void addChatInfo(@Param("fromUsername")String fromUsername, @Param("toUsername")String toUsername, @Param("time")String time);
	@Select("select distinct fromName from chat where toName = #{userName}")
	List<String> findChatInfo(@Param("userName")String userName);

}

