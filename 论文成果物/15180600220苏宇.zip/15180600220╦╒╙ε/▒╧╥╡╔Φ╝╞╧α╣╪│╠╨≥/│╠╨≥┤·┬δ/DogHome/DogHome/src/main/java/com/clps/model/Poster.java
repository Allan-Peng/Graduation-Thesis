package com.clps.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="post")
public class Poster implements Serializable {

@Override
	public String toString() {
		return "Poster [postId=" + postId + ", content=" + content + ", title=" + title + ", imgType=" + imgType
				+ ", imgName=" + imgName + ", locatName=" + locatName + ", typeName=" + typeName + ", ownerId="
				+ ownerId + ", dogTypeInfo=" + dogTypeInfo + ", locationInfo=" + locationInfo + ", flag=" + flag + "]";
	}
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "postId", updatable = false)
private Integer postId;
@Column(name = "content", updatable = false)
private String content;
@Column(name = "title", updatable = false)
private String title;
@Column(name = "imgType", updatable = false)
private String imgType;
@Column(name = "imgName", updatable = false)
private String imgName;
@Column(name = "locatName", updatable = false)
private Integer locatName;
@Column(name = "typeName", updatable = false)
private Integer typeName;
@Column(name = "ownerId", updatable = false)
private Integer ownerId;
@Transient
private dogType dogTypeInfo;
@Transient
private location locationInfo;
@Column(name = "flag", updatable = false)
private Integer flag;
public Integer getFlag() {
	return flag;
}

public void setFlag(Integer flag) {
	this.flag = flag;
}

public dogType getDogTypeInfo() {
	return dogTypeInfo;
}

public void setDogTypeInfo(dogType dogTypeInfo) {
	this.dogTypeInfo = dogTypeInfo;
}

public location getLocationInfo() {
	return locationInfo;
}

public void setLocationInfo(location locationInfo) {
	this.locationInfo = locationInfo;
}

public Integer getPostId() {
	return postId;
}

public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getImgType() {
	return imgType;
}
public void setImgType(String imgType) {
	this.imgType = imgType;
}
public String getImgName() {
	return imgName;
}
public void setImgName(String imgName) {
	this.imgName = imgName;
}
public Integer getLocatName() {
	return locatName;
}
public void setLocatName(Integer locatName) {
	this.locatName = locatName;
}
public Integer getTypeName() {
	return typeName;
}
public void setTypeName(Integer typeName) {
	this.typeName = typeName;
}
public Integer getOwnerId() {
	return ownerId;
}
public void setOwnerId(Integer ownerId) {
	this.ownerId = ownerId;
}

}
