package com.clps.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;


import com.clps.model.Ad;
import com.clps.model.Poster;
import com.clps.model.User;
import com.clps.model.adopt;


public interface PostMapper {
	@Insert("INSERT INTO POST(TITLE, CONTENT,IMGTYPE,IMGNAME,typeName,locatName,OWNERID) VALUES(#{title}, #{content},#{imgType},#{imgName},#{typeName},#{locatName},#{ownerId})")
	int addPost(@Param("title") String title, @Param("content") String content,@Param("imgType")String imgType,@Param("imgName")String imgName,
			@Param("typeName")Integer typeName,@Param("locatName")Integer locatName,@Param("ownerId")Integer ownerId);
	
	@Select("SELECT	*FROM	post LEFT JOIN location ON post.locatName = location.locatId LEFT JOIN dogType ON dogtype.typeId = post.typeName WHERE postId = #{postId};;")
	/*@Results({
		@Result(property = "locatName",  column = "locatName"),@Result(property = "typeName",  column = "typeName")
	})*/
	 @Results({
         @Result(property="locationInfo",column="locatName",one=@One(select="com.clps.mapper.locationMapper.findLocatById")),
         @Result(property="dogTypeInfo",column="typeName",one=@One(select="com.clps.mapper.dogTypeMapper.findTypeById"))
     })

	Poster findPoster(Integer postId);
	@Select("SELECT * FROM POST")
	List<Poster> findAllPoster();
	@Insert("insert into comment(postId,postCom,postDate) values (#{postId},#{postCom},#{postDate}) ")
	int comPost(@Param("postId")Integer postId, @Param("postCom")String postCom,@Param("postDate")String postDate);
	@Insert("insert into adopt(postId,ownerId,appId,appName) values (#{postId},#{ownerId},#{appId},#{appName})")
	int addAdopt(@Param("postId")Integer postId, @Param("ownerId")Integer ownerId, @Param("appId")Integer appId, @Param("appName")String appName);
	@Select("SELECT * FROM USER WHERE USERID = #{id}")
	User findById(@Param("id")Integer id);
	@Delete("Delete from POST where postId= #{postId}")
	int delPoster(Integer postId);
	@Select("SELECT * FROM post GROUP BY  comCount DESC limit 4")
	List<Poster> findTopFourPosters();
	@Update("update post set comCount=comCount+1 where postId = #{postId}")
	int addComCount(Integer postId);
	@Select("Select * from adopt where ownerId = #{ownerId} and flag=1")
	List<adopt> findAppingPosters(Integer ownerId);
	@Select("Select * from post where ownerId = #{ownerId} and flag=1")
	List<Poster> findAppPosters(Integer ownerId);
	@Select("select count(*) from post ")
	int findAllPoster1();
	@Select("select count(*) from post where flag=1")
	int findPoster1();
	@Select("select count(*) from post where flag=2")
	int findPoster2();
	@Select("select count(*) from user ")
	int findUserCount();
	@Insert("insert into ad values(null,#{text},#{date})")
	void adAdd(@Param("text")String text,@Param("date")String date);
	@Select("select * from ad")
	List<Ad> findAllAds();
	@Select("select  * from ad order by id desc LIMIT 1")
	Ad findRecentAd();
	
}
