package com.clps.TestController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.clps.mapper.UserMapper;
import com.clps.model.User;

import com.clps.service.UserService;

import io.swagger.annotations.Api;



@Api("userController相关api")
@Controller
public class TestUserController {
	
	@Autowired
	private UserMapper userMapper;
	@Autowired
	private UserService userService;
	

	@RequestMapping(value="/testfindByName2",method=RequestMethod.GET,produces="application/json")
	@ResponseBody
	public User testfindByName2(String name)
	{
		return userMapper.findByName(name);
		 
	}

}
