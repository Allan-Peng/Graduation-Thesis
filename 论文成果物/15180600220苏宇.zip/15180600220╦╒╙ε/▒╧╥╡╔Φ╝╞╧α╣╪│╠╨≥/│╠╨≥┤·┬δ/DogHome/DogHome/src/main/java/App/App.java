package App;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

import springfox.documentation.swagger2.annotations.EnableSwagger2;
@ComponentScan(basePackages={"com.clps.controller","com.clps.service","com.clps.TestController"
		})
@EnableAutoConfiguration
@EnableSwagger2
@EnableJpaRepositories(basePackages="com.clps.Reposity")
@ServletComponentScan(basePackages={"com.clps.service"})
@MapperScan(basePackages="com.clps.mapper")
@EnableCaching
@EntityScan("com.clps.model")
@EnableScheduling
public class App {
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}
