package com.clps.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.clps.model.Ad;
import com.clps.model.Comment;
import com.clps.model.Poster;
import com.clps.model.User;
import com.clps.model.adopt;
import com.clps.model.dogType;
import com.clps.model.location;
import com.clps.service.CommentService;
import com.clps.service.PostService;

import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@Controller
public class PostController {
	@Autowired
	private PostService postService;
	@Autowired
	private CommentService commentService;
	

	
	@RequestMapping("/detail")
	public ModelAndView detail(Integer postId) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("PostDetail");
		Poster poster= postService.findPoster(postId);
		Integer ownerId=poster.getOwnerId();
		User pubUser=postService.findById(ownerId);
		location detailLocat=poster.getLocationInfo();
		dogType detailDogType=poster.getDogTypeInfo();
	String locatName=detailLocat.getLocatName();
	String typeName=detailDogType.getTypeName();
	   List<Comment> coms=commentService.findComById(postId);
	   mv.addObject("coms", coms);
		System.out.println(poster);
		mv.addObject("pubUser",pubUser);
		mv.addObject("poster", poster);
		mv.addObject("locatName",locatName);
		mv.addObject("typeName",typeName);
		return mv;
	}
	@RequestMapping("adopt")
	public ModelAndView adopt(Integer postId,Integer ownerId,Integer appId,String appName) {
		ModelAndView mv = new ModelAndView();
		User appUser=postService.findById(appId);
		if(appUser.getFlag()==4)
		{
			mv.addObject("url", "抱歉！");
			mv.addObject("exception", "不能重复发出领养申请");
			mv.setViewName("ErrorPage");
			return mv;
		}
		int result = postService.addAdopt(postId,ownerId,appId,appName);
		if(result>0)
		{	mv.addObject("url", "恭喜！");
			mv.addObject("exception","您已成功发出领养申请！");
			mv.setViewName("ErrorPage");
		}
		else{
			mv.addObject("url", "抱歉！");
			mv.addObject("exception", "发出领养申请失败，请稍后重试");
			mv.setViewName("ErrorPage");
		}
		
		return mv;
		
	}
	@RequestMapping("managerApp")
	public ModelAndView managerApp(Integer ownerId) {
		ModelAndView mv = new ModelAndView();
		List<adopt> adopts = postService.findAppingPosters(ownerId);
		List<Poster> posters = postService.findAppPosters(ownerId);
		System.out.println(adopts);
		System.out.println(posters);
		
		for(adopt ad:adopts)
		{
			System.out.println(ad);
		}
		for(Poster ad:posters)
		{
			System.out.println(ad);
		}
		if(adopts.size()==0)
		{
			adopts=null;
		}
		if(posters.size()==0)
		{
			adopts=null;
		}
		mv.addObject("posters", posters);
		mv.addObject("adopts", adopts);
		mv.setViewName("managerApp");
		return mv;
		
	}
	@RequestMapping("findAllPostByPage")
	public ModelAndView findAllPostByPage(Integer currentPage) {
		ModelAndView mv = new ModelAndView();
		 Pageable pageable = new PageRequest(currentPage,10, Sort.Direction.ASC,"postId");
		  Page<Poster> posterS = postService.findAll(pageable);
		//int result = postService.addAdopt();
		   int totalPage=posterS.getTotalPages();
		   List<Poster> posters = posterS.getContent();
		   System.out.println(totalPage);
		  for(Poster po:posters)
		  {
			  System.out.println(po);
		  }
		  mv.addObject("totalPage", totalPage);
		  mv.addObject("currentPage", currentPage);
		  mv.addObject("posters", posters);
		mv.setViewName("postList");
		return mv;
		
	}
	
	@RequestMapping("adSubmit")
	public String adSubmit(String text,String date){
		ModelAndView mv = new ModelAndView();
		Date date1=new Date();
		  DateFormat format=new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss");
		  String time=format.format(date1);
		  System.out.println(text);
		  System.out.println(time);
		  date=time;
			Ad recentAd=postService.findRecentAd();
			mv.addObject("recentAd", recentAd);
			List<Ad> ads=postService.findAllAds();
			mv.addObject("ads", ads);
		 mv.setViewName("manager/mHome");
		postService.adAdd(text,date);
		return "redirect:/adminLogin";
		//return mv;
	}
	
	@RequestMapping("/adminLogin")
	public ModelAndView adminLogin(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		int poster1Cou = postService.findPoster1();
		int poster2Cou = postService.findPoster2();
		int posterCou = postService.findAllPoster1();
		int userCoun = postService.findUserCount();
		Ad recentAd=postService.findRecentAd();
		mv.addObject("recentAd", recentAd);
		System.out.println(recentAd);
		List<Ad> ads=postService.findAllAds();
		mv.addObject("ads", ads);
		 req.getSession().setAttribute("userCoun",userCoun);
		
		  req.getSession().setAttribute("poster1Cou",poster1Cou);	
		   req.getSession().setAttribute("poster2Cou",poster2Cou);	
		   req.getSession().setAttribute("posterCou",posterCou);
		mv.setViewName("manager/mHome");
		
		return mv;
	}
	
	@RequestMapping("/mHome")
	public ModelAndView mHome(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		int poster1Cou = postService.findPoster1();
		int poster2Cou = postService.findPoster2();
		int posterCou = postService.findAllPoster1();
		int userCoun = postService.findUserCount();
		Ad recentAd=postService.findRecentAd();
		mv.addObject("recentAd", recentAd);
		System.out.println(recentAd);
		List<Ad> ads=postService.findAllAds();
		mv.addObject("ads", ads);
		 req.getSession().setAttribute("userCoun",userCoun);
		
		  req.getSession().setAttribute("poster1Cou",poster1Cou);	
		   req.getSession().setAttribute("poster2Cou",poster2Cou);	
		   req.getSession().setAttribute("posterCou",posterCou);
		mv.setViewName("manager/mHome");
		
		return mv;
	}
	
	@RequestMapping("posterM")
	public ModelAndView posterM(Integer currentPage) {
		ModelAndView mv = new ModelAndView();
		
		 Pageable pageable = new PageRequest(currentPage,10, Sort.Direction.ASC,"postId");
		  Page<Poster> posterS = postService.findAll(pageable);
		  int totalPage=posterS.getTotalPages();
		 List<Poster> posters=posterS.getContent();
		  mv.addObject("totalPage", totalPage);
		  mv.addObject("currentPage", currentPage);
		  mv.addObject("posters", posters);
		mv.setViewName("manager/posterM");
		return mv;
	}
	@RequestMapping("changePosterStatu")
	public String posterM(Integer[] postId,HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		for(Integer i:postId)
		{
			postService.changePosterStatu(i);
		}
		response.sendRedirect("posterM?currentPage=0"); 
		return null;
}
	@RequestMapping("/delPoster")
	public String delPoster(Integer postId,Integer ownerId,RedirectAttributes attr) {
		ModelAndView mv = new ModelAndView();
		attr.addFlashAttribute("userId", ownerId);
		int result = postService.delPoster(postId);
		return "redirect:/userCenter";
		
	}
}
