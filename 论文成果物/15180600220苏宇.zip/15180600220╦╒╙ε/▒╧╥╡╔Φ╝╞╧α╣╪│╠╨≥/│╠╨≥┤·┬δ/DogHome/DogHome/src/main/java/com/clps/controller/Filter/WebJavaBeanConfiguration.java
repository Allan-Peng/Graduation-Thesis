package com.clps.controller.Filter;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebJavaBeanConfiguration {
    /**
     * 日志拦截器
     */
    @Autowired
    private LogInterceptor logInterceptor;

    /**
     * 实例化WebMvcConfigurer接口
     *
     * @return
     */
    @Bean
    public WebMvcConfigurer webMvcConfigurer() {
        return new WebMvcConfigurer() {
            /**
             * 添加拦截器
             * @param registry
             */
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(logInterceptor).addPathPatterns("/**")
                .excludePathPatterns("/Photo","/index","/adminLogin","","Error",
                "/adLogin","/findAllPostByPage**","/findUserByName","/PosterList**","/**/*.css",
                "/addPostView","/loginView","/static/**","/static","static**","/pushReInfoView?**"
                ,"/pushReInfoView*","**.js","logout","/pushReInfoView","/swagger-ui.html/**","/swagger",
               "/webjars/springfox-swagger-ui/**","/v2/api-docs","/swagger-resources","/**/swagger-resources/**",
               "/v2/api-docs", "/configuration/ui", "/swagger-resources", "/configuration/security", 
               "/swagger-ui.html", "/webjars/**",
               "/findByName2","/login","/Error","/detail","/register","/**/*.css","**.css","error");
            
            }
        };
    }
}