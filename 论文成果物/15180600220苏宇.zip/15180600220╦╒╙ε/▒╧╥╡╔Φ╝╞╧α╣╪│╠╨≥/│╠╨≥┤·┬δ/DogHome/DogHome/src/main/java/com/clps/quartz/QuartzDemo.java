package com.clps.quartz;

import java.util.Date;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.clps.util.MailUtils;


public class QuartzDemo implements Job {
	/**
	 * 任务被触发时所执行的方法
	 */
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		try {
			System.out.println("发送邮件");
			
			MailUtils.sendMail("847047477@qq.com", "您的申请已经成功，记得发送回访照片\n(如果已发请忽略)");
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}