package com.clps.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.clps.model.location;

public interface locationMapper {
	@Select("SELECT * FROM location ")
	List<location> getAllLocation();
	@Select("SELECT * FROM LOCATION WHERE LOCATID=#{locatId}")
	location findLocatById(Integer locatId);
}
