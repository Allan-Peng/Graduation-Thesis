package com.clps.model;



import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Accessors(chain=false)
public class adopt implements Serializable{
	private Integer id;
	private Integer postId;
	private Integer ownerId;
	private Integer appId;
	private String appName;
	private Integer flag;
}
