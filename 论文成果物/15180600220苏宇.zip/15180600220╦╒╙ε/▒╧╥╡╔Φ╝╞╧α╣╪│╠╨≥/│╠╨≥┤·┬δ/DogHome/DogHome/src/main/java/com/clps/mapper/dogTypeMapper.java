package com.clps.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.clps.model.dogType;
import com.clps.model.location;

public interface dogTypeMapper {
	@Select("SELECT * FROM DOGTYPE ")
	List<dogType> getAllDogType();
	@Select("SELECT * FROM DOGTYPE WHERE typeId=#{typeName}")
	dogType findTypeById(Integer typeName);
}
