package com.clps.model;

public class Ad {
private String text;
private String date;
private int id;
public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getText() {
	return text;
}

public void setText(String text) {
	this.text = text;
}
}
