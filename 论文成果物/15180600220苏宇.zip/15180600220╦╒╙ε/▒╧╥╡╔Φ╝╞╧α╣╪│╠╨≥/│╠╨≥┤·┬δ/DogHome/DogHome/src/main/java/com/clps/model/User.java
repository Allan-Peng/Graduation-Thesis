package com.clps.model;


public class User {
	
	private Integer userId;
	 
	private String userName;
	 
	private String userPass;
	
	public User(Integer userId, String userName, String userPass, String userAge,
			String userPhone, String userLocation, String iDCardNum,Integer flag,String userEmail ) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPass = userPass;
		this.userAge = userAge;
		this.userEmail = userEmail;
		this.flag = flag;
		this.userPhone = userPhone;
		this.userLocation = userLocation;
		IDCardNum = iDCardNum;
	}

	private String userAge;
	private String userEmail;
	public String getUserEmail() {
		return userEmail;
	}



	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	private Integer flag;
	public Integer getFlag() {
		return flag;
	}



	public void setFlag(Integer flag) {
		this.flag = flag;
	}



	public String getUserAge() {
		return userAge;
	}

	

	public void setUserAge(String userAge) {
		this.userAge = userAge;
	}

	



	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserLocation() {
		return userLocation;
	}

	public void setUserLocation(String userLocation) {
		this.userLocation = userLocation;
	}

	public String getIDCardNum() {
		return IDCardNum;
	}

	public void setIDCardNum(String iDCardNum) {
		IDCardNum = iDCardNum;
	}

	private String userPhone;
	private String userLocation;
	
	private String IDCardNum;
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	

	

	
	
}
