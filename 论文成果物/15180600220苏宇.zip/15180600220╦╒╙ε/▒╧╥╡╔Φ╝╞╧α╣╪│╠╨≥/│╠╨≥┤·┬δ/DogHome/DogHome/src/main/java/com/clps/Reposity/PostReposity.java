package com.clps.Reposity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.clps.model.Poster;

@Repository
public interface PostReposity extends JpaRepository<Poster,Integer>{
	Page<Poster> findAll(Pageable pageable);
}
