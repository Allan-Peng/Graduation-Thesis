package com.clps.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Accessors(chain=false)
public class reInfo {
private Integer id;
private Integer postId;
private String title;
private String imgType;
private String imgName;
private Integer ownerId;
private String ownerName;
private String appName;
private String content;
private Integer flag;
}
