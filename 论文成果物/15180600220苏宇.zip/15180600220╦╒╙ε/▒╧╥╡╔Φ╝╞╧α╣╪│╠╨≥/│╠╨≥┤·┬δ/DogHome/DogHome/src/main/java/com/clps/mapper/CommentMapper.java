package com.clps.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.clps.model.Comment;
import com.clps.model.dogType;
import com.clps.model.location;

public interface CommentMapper {
	
	@Select("SELECT * FROM comment WHERE postId=#{postId}")
	List<Comment> findComById(Integer postId);
}
