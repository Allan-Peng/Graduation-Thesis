package com.clps.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Accessors(chain=false)
public class ErrorInfo {
    // 错误类别码
    public Integer code;
    // 错误信息
    public String message;
    // 映射路径
    public String url;
    // get/set方法省略
}
