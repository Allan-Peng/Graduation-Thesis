/*
Navicat MySQL Data Transfer

Source Server         : DogHome
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-05-18 15:20:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ad
-- ----------------------------
DROP TABLE IF EXISTS `ad`;
CREATE TABLE `ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ad
-- ----------------------------
INSERT INTO `ad` VALUES ('1', 'test', 'testDate');
INSERT INTO `ad` VALUES ('2', 'hi', '2019-03-26  21:05:58');
INSERT INTO `ad` VALUES ('3', 'hello', '2019-03-26  21:05:58');
INSERT INTO `ad` VALUES ('4', 'hello', '21:05:58');
INSERT INTO `ad` VALUES ('5', 'a', '21:05:58');
INSERT INTO `ad` VALUES ('6', '欢迎来到德莱联盟！', '2019-03-26  21:33:33');
INSERT INTO `ad` VALUES ('7', 'ModelAndView', '2019-03-26  21:37:35');
INSERT INTO `ad` VALUES ('8', '一个用户只能同时试领养一个帖子中的宠物哦！', '2019-04-05  14:41:12');

-- ----------------------------
-- Table structure for adopt
-- ----------------------------
DROP TABLE IF EXISTS `adopt`;
CREATE TABLE `adopt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postId` int(11) DEFAULT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `appId` int(11) DEFAULT NULL,
  `appName` varchar(255) DEFAULT NULL,
  `flag` int(255) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of adopt
-- ----------------------------
INSERT INTO `adopt` VALUES ('1', '1', '1', '4', 'suyu', '1');
INSERT INTO `adopt` VALUES ('3', '7', '1', '3', 'yu2', '0');
INSERT INTO `adopt` VALUES ('6', '21', '1', '8', 'suha', '1');
INSERT INTO `adopt` VALUES ('7', '14', '4', '1', 'su', '1');
INSERT INTO `adopt` VALUES ('8', '22', '1', '5', 'testT', '1');
INSERT INTO `adopt` VALUES ('9', '8', '1', '4', 'suyu', '1');
INSERT INTO `adopt` VALUES ('10', '24', '1', '10', 'lisiyu', '1');
INSERT INTO `adopt` VALUES ('11', '6', '1', '11', 'qq', '1');
INSERT INTO `adopt` VALUES ('12', '29', '12', '13', 'bb', '0');
INSERT INTO `adopt` VALUES ('13', '31', '12', '13', 'bb', '1');
INSERT INTO `adopt` VALUES ('14', '34', '14', '15', 'dd', '1');
INSERT INTO `adopt` VALUES ('16', '4', '1', '16', 'ee', '0');

-- ----------------------------
-- Table structure for chat
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fromName` varchar(255) DEFAULT NULL,
  `toName` varchar(255) DEFAULT NULL,
  `sendTime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chat
-- ----------------------------
INSERT INTO `chat` VALUES ('1', 'suyu', 'su', '2019.5.18');
INSERT INTO `chat` VALUES ('3', 'ee', 'su', '2019-05-18 14:42:40');
INSERT INTO `chat` VALUES ('5', 'ff', 'su', '2019-05-18  14:52:53');
INSERT INTO `chat` VALUES ('6', 'su', 'ee', '2019-05-18  14:57:47');
INSERT INTO `chat` VALUES ('7', 'ee', 'su', '2019-05-18  15:01:49');
INSERT INTO `chat` VALUES ('8', 'ff', 'su', '2019-05-18  15:02:16');
INSERT INTO `chat` VALUES ('9', 'su', 'suyu', '2019-05-18  15:09:02');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `comId` int(11) NOT NULL AUTO_INCREMENT,
  `postId` int(11) NOT NULL,
  `postCom` varchar(255) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  PRIMARY KEY (`comId`),
  KEY `postId` (`postId`),
  CONSTRAINT `postId` FOREIGN KEY (`postId`) REFERENCES `post` (`postId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('1', '1', '好可爱哦', '2018-12-30 06:00:06');
INSERT INTO `comment` VALUES ('2', '1', 's', '2019-01-03 22:02:21');
INSERT INTO `comment` VALUES ('3', '1', 's', '2019-01-03 22:02:21');
INSERT INTO `comment` VALUES ('4', '15', 'asa', '2019-01-03 22:20:52');
INSERT INTO `comment` VALUES ('5', '15', '给我吧', '2019-01-03 22:24:35');
INSERT INTO `comment` VALUES ('6', '15', '撒旦撒旦啊', '2019-01-03 22:38:23');
INSERT INTO `comment` VALUES ('7', '15', '突然特', '2019-01-03 22:41:28');
INSERT INTO `comment` VALUES ('8', '15', '超级喜欢给我吧', '2019-01-04 19:23:16');
INSERT INTO `comment` VALUES ('9', '28', 'sda', '2019-05-16 15:50:59');
INSERT INTO `comment` VALUES ('10', '1', '阿斯达', '2019-05-16 15:52:22');
INSERT INTO `comment` VALUES ('11', '1', '阿斯达', '2019-05-16 15:56:55');
INSERT INTO `comment` VALUES ('12', '29', 'asda ', '2019-05-16 15:59:43');
INSERT INTO `comment` VALUES ('13', '30', 'sakljd', '2019-05-16 16:02:59');
INSERT INTO `comment` VALUES ('14', '31', 'asdsa', '2019-05-16 16:05:40');
INSERT INTO `comment` VALUES ('15', '32', 'dasda', '2019-05-16 16:10:36');
INSERT INTO `comment` VALUES ('16', '33', 'sdasd', '2019-05-16 16:13:16');
INSERT INTO `comment` VALUES ('17', '34', 'asda', '2019-05-16 16:16:30');
INSERT INTO `comment` VALUES ('18', '35', 'asda', '2019-05-16 16:37:44');
INSERT INTO `comment` VALUES ('19', '36', 'asdas', '2019-05-16 16:47:31');
INSERT INTO `comment` VALUES ('20', '37', 'asdas', '2019-05-17 12:58:50');

-- ----------------------------
-- Table structure for dogtype
-- ----------------------------
DROP TABLE IF EXISTS `dogtype`;
CREATE TABLE `dogtype` (
  `typeId` int(11) NOT NULL AUTO_INCREMENT,
  `typeName` varchar(255) NOT NULL,
  PRIMARY KEY (`typeId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dogtype
-- ----------------------------
INSERT INTO `dogtype` VALUES ('1', '哈士奇');
INSERT INTO `dogtype` VALUES ('2', '金毛');
INSERT INTO `dogtype` VALUES ('3', '拉布拉多');
INSERT INTO `dogtype` VALUES ('4', '柯基');
INSERT INTO `dogtype` VALUES ('5', '法老犬');
INSERT INTO `dogtype` VALUES ('6', '藏獒');
INSERT INTO `dogtype` VALUES ('7', '腊肠');
INSERT INTO `dogtype` VALUES ('8', '中华田园犬');
INSERT INTO `dogtype` VALUES ('9', '萨摩耶');
INSERT INTO `dogtype` VALUES ('10', '泰迪');

-- ----------------------------
-- Table structure for location
-- ----------------------------
DROP TABLE IF EXISTS `location`;
CREATE TABLE `location` (
  `locatId` int(11) NOT NULL AUTO_INCREMENT,
  `locatName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`locatId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of location
-- ----------------------------
INSERT INTO `location` VALUES ('1', '大连');
INSERT INTO `location` VALUES ('2', '鞍山');
INSERT INTO `location` VALUES ('3', '北京');
INSERT INTO `location` VALUES ('4', '沈阳');
INSERT INTO `location` VALUES ('5', '哈尔滨');
INSERT INTO `location` VALUES ('6', '长春');
INSERT INTO `location` VALUES ('7', '热河');
INSERT INTO `location` VALUES ('8', '重庆');

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `postId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `imgType` varchar(255) DEFAULT NULL,
  `imgName` varchar(255) DEFAULT NULL,
  `typeName` int(255) DEFAULT NULL,
  `ownerId` int(255) DEFAULT NULL,
  `locatName` int(255) DEFAULT NULL,
  `comCount` int(255) DEFAULT '0',
  `flag` int(255) DEFAULT '0',
  PRIMARY KEY (`postId`),
  KEY `OwnerId` (`ownerId`),
  KEY `location` (`locatName`),
  KEY `typeId` (`typeName`),
  CONSTRAINT `OwnerId` FOREIGN KEY (`ownerId`) REFERENCES `user` (`userId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `location` FOREIGN KEY (`locatName`) REFERENCES `location` (`locatId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `typeId` FOREIGN KEY (`typeName`) REFERENCES `dogtype` (`typeId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES ('1', 'this is title', 'this is content', 'jpg', '1544370972197', '1', '1', '1', '3', '1');
INSERT INTO `post` VALUES ('2', 'as', 'Enter your text here...', 'jpg', '1544370972197', '1', '1', '1', '0', '0');
INSERT INTO `post` VALUES ('3', 'sasa', 'Enter your text here...', 'jpg', '1544370972197', '1', '1', '2', '0', '1');
INSERT INTO `post` VALUES ('4', '可爱狗', '吃百家饭，无病', 'png', '1544370972197', '1', '1', '1', '20', '0');
INSERT INTO `post` VALUES ('5', 'tet', 'sa', 'png', '1544370972197', '1', '1', '1', '0', '1');
INSERT INTO `post` VALUES ('6', '654', '4654', 'png', '1545754692974', '1', '1', '1', '1', '1');
INSERT INTO `post` VALUES ('7', '阿萨德群', '参考链接拿到', 'png', '1545927252366', '1', '1', '1', '10', '0');
INSERT INTO `post` VALUES ('8', '阿萨德', '十大', 'png', '1545927435502', '1', '1', '2', '11', '1');
INSERT INTO `post` VALUES ('9', '发阿萨德', '在CDas的', 'png', '1545927639956', '1', '2', '1', '0', '1');
INSERT INTO `post` VALUES ('13', '请问', '大师', 'png', '1546011856721', '1', '2', '1', '2', '0');
INSERT INTO `post` VALUES ('14', '快快乐乐', '阿萨德', 'png', '1546012219053', '1', '4', '2', '0', '1');
INSERT INTO `post` VALUES ('15', '日你打吧', '啊啊啊从', 'png', '1546012252323', '1', '4', '2', '0', '0');
INSERT INTO `post` VALUES ('16', 'asdsa', 'asfasf', 'png', '1546098389007', '1', '4', '1', '40', '0');
INSERT INTO `post` VALUES ('17', 'why no pics', 'test no pics', 'png', '1554035042044', '1', '1', '1', '30', '0');
INSERT INTO `post` VALUES ('18', '为什么没有照片', '则么就ius没有', 'png', '1554035755755', '1', '1', '1', '50', '0');
INSERT INTO `post` VALUES ('20', 'Perfect test again', 'again', 'png', '1554079131734', '1', '8', '1', '66', '2');
INSERT INTO `post` VALUES ('21', 'testMail', 'testMail', 'png', '1554219805823', '2', '1', '1', '0', '1');
INSERT INTO `post` VALUES ('22', 'testQuartz', 'testQuartz', 'png', '1554460877853', '7', '1', '4', '0', '1');
INSERT INTO `post` VALUES ('23', '纯种狗，已打疫苗', '在甘井子区警察局附近发现，很可怜，求收养', 'png', '1555851830683', '1', '1', '1', '0', '0');
INSERT INTO `post` VALUES ('24', '回归测试帖子', '测试', 'png', '1557725939452', '1', '1', '1', '0', '1');
INSERT INTO `post` VALUES ('25', 's ', 'asda', 'png', '1557991182136', '1', '1', '1', '0', '0');
INSERT INTO `post` VALUES ('26', 'as', 'asdas', 'png', '1557992609965', '2', '12', '1', '0', '0');
INSERT INTO `post` VALUES ('27', 'salk', 'asdasd', 'png', '1557992734192', '2', '12', '1', '0', '0');
INSERT INTO `post` VALUES ('28', 'sadj', 'asdas', 'png', '1557993020701', '1', '12', '1', '1', '0');
INSERT INTO `post` VALUES ('29', '推送', '阿斯达', 'png', '1557993542520', '1', '12', '2', '1', '0');
INSERT INTO `post` VALUES ('30', 'shuia', 'asdas', 'png', '1557993752767', '1', '12', '2', '1', '0');
INSERT INTO `post` VALUES ('31', 'shusad ', 'sadas', 'png', '1557993903274', '1', '12', '1', '1', '1');
INSERT INTO `post` VALUES ('32', 'sadj', 'asdas', 'png', '1557994198716', '1', '12', '1', '1', '0');
INSERT INTO `post` VALUES ('33', 'suyu', 'asdas', 'png', '1557994359381', '2', '12', '1', '1', '0');
INSERT INTO `post` VALUES ('34', 'sjii', 'sadsda', 'png', '1557994551389', '1', '14', '1', '1', '1');
INSERT INTO `post` VALUES ('35', 'asdjk', 'asda', 'png', '1557995814880', '1', '16', '1', '1', '2');
INSERT INTO `post` VALUES ('36', 'suyu', 'asda', 'png', '1557996412334', '1', '18', '1', '1', '2');
INSERT INTO `post` VALUES ('37', 'test', 'test', 'png', '1558069077203', '1', '20', '3', '1', '2');

-- ----------------------------
-- Table structure for reinfo
-- ----------------------------
DROP TABLE IF EXISTS `reinfo`;
CREATE TABLE `reinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postId` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `imgType` varchar(255) DEFAULT NULL,
  `imgName` varchar(255) DEFAULT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `appName` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `flag` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reinfo
-- ----------------------------
INSERT INTO `reinfo` VALUES ('2', '1', 'this is title', 'png', 'bf372b3a887f485fae9a5fe8349f82bc.png', '1', 'su', 'suyu', 'just test', '0');
INSERT INTO `reinfo` VALUES ('6', '5', 'tet', 'png', '86b5e148453448e9937352b3d2dd278e', '1', 'su', 'suha', 'testPICS', '0');
INSERT INTO `reinfo` VALUES ('7', '9', '发阿萨德', 'png', '5be1ab90634b4a7c838aa3cd887a5e68', '2', 'yu3', 'yu5', '156', '0');
INSERT INTO `reinfo` VALUES ('8', '19', 'Perfect DOG HOME', 'png', '76f3738edbef419eaab39c8b7835aec3', '8', 'suha', 'su', 'Perfect I like', '0');
INSERT INTO `reinfo` VALUES ('9', '20', 'Perfect test again', 'png', 'e287b952d3e545fda4e6c6d4f5c3c41e', '8', 'suha', 'su', 'one more time', '0');
INSERT INTO `reinfo` VALUES ('10', '24', '回归测试帖子', 'png', 'ca0a2e654c4042f39d6217d76dbcd999.png', '1', 'su', 'lisiyu', 'test', '0');
INSERT INTO `reinfo` VALUES ('12', '24', '回归测试帖子', 'png', '0b72e6bd219945f5a93f5a46f6ea14f0.png', '1', 'su', 'lisiyu', 'final tedt', '0');
INSERT INTO `reinfo` VALUES ('13', '24', '回归测试帖子', 'png', '4b47efcab11d4d398f711bd432ef4ffc.png', '1', 'su', 'lisiyu', 'test', '0');
INSERT INTO `reinfo` VALUES ('14', '35', 'asdjk', 'png', '4ccace31ebd247879beb658d0d8fd26d.png', '16', 'ee', 'ff', 'sadasd', '2');
INSERT INTO `reinfo` VALUES ('15', '36', 'suyu', 'png', '51df58071b9c4ad99f92975cfd1c0b4c.png', '18', 'zz', 'xx', 'asdas', '2');
INSERT INTO `reinfo` VALUES ('16', '37', 'test', 'png', '36bd91cc990e4ab5857d3971df87c667.png', '20', 'test1', 'test2', 'asdasd', '2');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(12) NOT NULL,
  `userAge` varchar(12) DEFAULT NULL,
  `userPass` varchar(255) NOT NULL,
  `userPhone` varchar(255) DEFAULT NULL,
  `IDCardNum` varchar(255) DEFAULT NULL,
  `userLocation` varchar(255) DEFAULT NULL,
  `flag` int(255) DEFAULT '0',
  `userEmail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'su', '23', '22', '18041168099', '210381199611112736', '大连市甘井子区', '6', '847047477@qq.com');
INSERT INTO `user` VALUES ('2', 'yu3', null, '22', null, null, null, '2', '2587284684@qq.com');
INSERT INTO `user` VALUES ('3', 'yu2', null, '22', null, null, null, '2', '2587284684@qq.com');
INSERT INTO `user` VALUES ('4', 'suyu', null, '22', null, null, null, '4', 'm18940892032_1@163.com');
INSERT INTO `user` VALUES ('5', 'testT', null, '22', null, null, null, '4', '847047477@qq.com');
INSERT INTO `user` VALUES ('6', 'yu4', null, '22', null, null, null, '0', 'm18940892032_1@163.com');
INSERT INTO `user` VALUES ('7', 'yu5', null, '22', null, null, null, '0', '847047477@qq.com');
INSERT INTO `user` VALUES ('8', 'suha', '24', 'su', '18041168099', '210381199611112736', '大连市甘井子区', '0', 'm18940892032_1@163.com');
INSERT INTO `user` VALUES ('9', 'AdminSu', '23', '847047477', '111111', '22222222', '大连北京爱我去', '1', '847047477@qq.com');
INSERT INTO `user` VALUES ('10', 'lisiyu', '22', '11', '18041168099', '210381199611112736', 'Dalian', '4', '847047477@qq.com');
INSERT INTO `user` VALUES ('11', 'qq', '22', '11', '18041168099', '210381199611112736', 'dalian', '4', '847047477@qq.com');
INSERT INTO `user` VALUES ('12', 'aa', '11', '11', null, null, null, '0', '847047477@qq.com');
INSERT INTO `user` VALUES ('13', 'bb', null, '11', null, null, null, '4', '847047477@qq.com');
INSERT INTO `user` VALUES ('14', 'cc', null, '11', null, null, null, '6', '847047477@qq.com');
INSERT INTO `user` VALUES ('15', 'dd', null, '11', null, null, null, '4', '847047477@qq.com');
INSERT INTO `user` VALUES ('16', 'ee', null, '11', null, null, null, '6', '847047477@qq.com');
INSERT INTO `user` VALUES ('17', 'ff', null, '11', null, null, null, '0', '847047477@qq.com');
INSERT INTO `user` VALUES ('18', 'zz', '21', '11', '', '', '', '6', '847047477@qq.com');
INSERT INTO `user` VALUES ('19', 'xx', null, '11', null, null, null, '0', '847047477@qq.com');
INSERT INTO `user` VALUES ('20', 'test1', null, '11', null, null, null, '6', '847047477@qq.com');
INSERT INTO `user` VALUES ('21', 'test2', null, '11', null, null, null, '0', '847047477@qq.com');
