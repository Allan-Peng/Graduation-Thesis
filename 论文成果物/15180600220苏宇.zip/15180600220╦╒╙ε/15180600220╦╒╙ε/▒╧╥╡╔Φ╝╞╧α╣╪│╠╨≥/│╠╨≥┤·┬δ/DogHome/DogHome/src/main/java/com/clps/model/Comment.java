package com.clps.model;

public class Comment {
	private Integer comId;
 public Integer getComId() {
		return comId;
	}
	public void setComId(Integer comId) {
		this.comId = comId;
	}
private Integer postId;
 private String postCom;
 private String postDate;
public Integer getPostId() {
	return postId;
}
public void setPostId(Integer postId) {
	this.postId = postId;
}
public String getPostCom() {
	return postCom;
}
public void setPostCom(String postCom) {
	this.postCom = postCom;
}
public String getPostDate() {
	return postDate;
}
public void setPostDate(String postDate) {
	this.postDate = postDate;
}
}
