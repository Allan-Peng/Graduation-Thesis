package com.clps.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.ScheduleBuilder;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.clps.mapper.UserMapper;
import com.clps.model.Ad;
import com.clps.model.Comment;
import com.clps.model.Poster;
import com.clps.model.User;
import com.clps.model.adopt;
import com.clps.model.dogType;
import com.clps.model.location;
import com.clps.model.reInfo;
import com.clps.quartz.QuartzDemo;
import com.clps.service.CommentService;
import com.clps.service.PostService;
import com.clps.service.UserService;
import com.clps.util.MailUtils;

import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@Controller

public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserMapper userMapper;
	@Autowired
	private UserService userService;
	@Autowired
	private PostService postService;
	@Autowired
	private CommentService commentService;

	@RequestMapping("/index")
	public ModelAndView index() throws SchedulerException {
		ModelAndView mav = new ModelAndView();
		Ad recentAd = postService.findRecentAd();
		mav.addObject("recentAd", recentAd);
		List<Poster> findTopFourPosters = postService.findTopFourPosters();
		mav.addObject("topPoster", findTopFourPosters);
		mav.setViewName("home");
		for (int i = 0; i < findTopFourPosters.size(); i++) {
			System.out.println(findTopFourPosters.get(i));
		}

		return mav;
	}

	@RequestMapping("chat")
	public ModelAndView chat(String FromUsername, String ToUsername) {

		ModelAndView mav = new ModelAndView();
		Date date1=new Date();
		  DateFormat format=new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss");
		  String time=format.format(date1);
		mav.setViewName("chat");
		mav.addObject("username", FromUsername);
		mav.addObject("ToUsername", ToUsername);
		userService.addChatInfo(FromUsername,ToUsername,time);
		System.out.println(FromUsername + " : " + ToUsername);
		// mav.addObject("webSocketUrl",
		// "ws://"+InetAddress.getLocalHost().getHostAddress()+":"+request.getServerPort()+request.getContextPath()+"/chat");
		return mav;
	}



	@RequestMapping("comOfPost")
	public ModelAndView comment(Comment com) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("PostDetail");
		System.out.println(com.getPostCom() + " " + com.getPostId() + "" + com.getPostDate());
		postService.comPost(com.getPostId(), com.getPostCom(), com.getPostDate());
		Poster poster = postService.findPoster(com.getPostId());
		location detailLocat = poster.getLocationInfo();
		dogType detailDogType = poster.getDogTypeInfo();
		String locatName = detailLocat.getLocatName();
		String typeName = detailDogType.getTypeName();
		int addCountResult = postService.addComCount(com.getPostId());
		System.out.println(poster);

		List<Comment> coms = commentService.findComById(com.getPostId());
		mv.addObject("coms", coms);
		mv.addObject("poster", poster);
		mv.addObject("locatName", locatName);
		mv.addObject("typeName", typeName);
		return mv;
	}

	@RequestMapping("/Error")
	public ModelAndView aboutPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ErrorPage");
		return mv;
	}

	@RequestMapping("updateUserInfo")
	public ModelAndView updateUserInfo(User user) {
		ModelAndView mv = new ModelAndView();
		System.out.println(user.toString());
		int result = userService.updateInfoById(user.getUserId(), user.getUserAge(), user.getIDCardNum(),
				user.getUserPhone(), user.getUserLocation(), user.getUserPass(), user.getUserEmail());
		logger.info(user.toString());
		User userInfo = userService.findUserById(user.getUserId());
		mv.addObject("userInfo", userInfo);
		mv.setViewName("userCenter");
		return mv;
	}

	@RequestMapping("userCenter")
	public ModelAndView userCenter(@ModelAttribute("userId") Integer userId) {
		ModelAndView mv = new ModelAndView();
		User user = userService.findUserById(userId);
		List<Poster> myPost = userService.findPostByOwnerId(userId);

		// List<Integer> postIds= userService.findAppId(userId);
		List<adopt> appNames = userService.findAppNamesByOwnerId(userId);
		List<String> names=userService.findChatInfo(user.getUserName());
		mv.addObject("userInfo", user);
		mv.addObject("myPost", myPost);
		mv.addObject("names", names);
		mv.addObject("appNames", appNames);
		mv.setViewName("userCenter");
		return mv;
	}

	@RequestMapping("agreeFinal")
	public ModelAndView agreeFinal(Integer postId, Integer appId) throws SchedulerException {
		ModelAndView mv = new ModelAndView();
		userService.setAdoptFlagTwo(postId);
		userService.setPosterFlagTwo(postId);
		userService.setReInfoFalgTwo(postId);
		userService.setUserFlagZero(appId);
		String email = userService.findEmailByUserId(appId);

		try {
			MailUtils.sendMail(email, "您的领养成功，现在小可爱归您了！");
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("Exception", "已同意您的领养");
		mv.addObject("url", "恭喜");
		mv.setViewName("ErrorPage");
		return mv;
	}

	@RequestMapping("refuseFinal")
	public ModelAndView refuseFinal(Integer postId, Integer appId) {
		ModelAndView mv = new ModelAndView();
		userService.setAdoptFlagThree(postId);
		userService.setPosterFlagZero(postId);
		userService.setReInfoFalgThree(postId);
		userService.setUserFlagZero(appId);
		String email = userService.findEmailByUserId(appId);
		try {
			MailUtils.sendMail(email, "您的领养成功，现在小可爱归您了！");
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("exception", "已同意您的领养");
		mv.addObject("url", "恭喜");
		mv.setViewName("ErroPage");
		return mv;
	}

	@RequestMapping("agreeWith")
	public String agree(Integer postId, Integer id, Integer ownerId, RedirectAttributes attr)
			throws SchedulerException {
		ModelAndView mv = new ModelAndView();
		userService.setPostTry(id);
		userService.setPosterTry(postId);
		userService.setUserFlagFour(id);
		Integer appId = userService.findEmailByAdoptId(id);
		String email = userService.findEmailByUserId(appId);
		try {
			MailUtils.sendMail(email, "您的试领养申请已被同意！");
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		attr.addFlashAttribute("userId", ownerId);
		JobDetail jobDetail = JobBuilder.newJob(QuartzDemo.class).build();
		String cronString = "0 0 0 1/7 * ?";
		SchedulerFactory factory = new StdSchedulerFactory();
		// 触发器
		TriggerBuilder<Trigger> triggerBuilder = TriggerBuilder.newTrigger();
		// 触发器名,触发器组
		triggerBuilder.withIdentity("su", "suGroup");
		triggerBuilder.startNow();
		// 触发器时间设定
		triggerBuilder.withSchedule(CronScheduleBuilder.cronSchedule(cronString));
		// 创建Trigger对象
		CronTrigger trigger = (CronTrigger) triggerBuilder.build();
		Scheduler scheduler = factory.getScheduler();
		scheduler.scheduleJob(jobDetail, trigger);
		scheduler.start();
		//System.out.println("set flag success");
		return "redirect:/userCenter";
	}

	@RequestMapping("refuseWith")
	public String confuse(Integer postId, Integer id, Integer ownerId, RedirectAttributes attr) {
		ModelAndView mv = new ModelAndView();
		userService.setPostTryRefuse(id);
		userService.setPosterTryRefuse(postId);
		Integer appId = userService.findEmailByAdoptId(id);
		String email = userService.findEmailByUserId(appId);
		try {
			MailUtils.sendMail(email, "抱歉，您的试领养申请被驳回！");
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		attr.addFlashAttribute("userId", ownerId);
		System.out.println("set flag success");
		return "redirect:/userCenter";
	}

	@RequestMapping("logout")
	public ModelAndView logout(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		req.getSession().invalidate();
		mv.addObject("exception", "用户已注销");
		mv.addObject("url", "操作成功");
		mv.setViewName("LogoutPage");
		return mv;
	}

	@RequestMapping("/loginView")
	public ModelAndView loginView() {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("manager/login");
		return mv;
	}

	@RequestMapping("userM")
	public ModelAndView Muser() {
		ModelAndView mv = new ModelAndView();
		List<User> users = userService.findAllUser();
		mv.setViewName("manager/userM");
		mv.addObject("users", users);
		return mv;
	}

	@RequestMapping("commonM")
	public ModelAndView commonM() {
		ModelAndView mv = new ModelAndView();
		List<dogType> dogs = userService.findDogTypes();
		List<location> locations = userService.findLocations();
		mv.setViewName("manager/commonM");
		mv.addObject("dogs", dogs);
		mv.addObject("locations", locations);
		return mv;
	}

	@RequestMapping("changeUserStatu")
	public ModelAndView userStatu(String[] user_name) {

		ModelAndView mv = new ModelAndView();
		if (user_name != null) {
			for (String s : user_name) {
				userService.changeUserStatu(s);
			}

		}

		List<User> users = userService.findAllUser();
		mv.setViewName("manager/userM");
		mv.addObject("users", users);
		return mv;
	}

	@RequestMapping("/register")
	public ModelAndView register(User user) {
		ModelAndView mv = new ModelAndView();
		int result = 0;
		int count = userService.findUserByName(user.getUserName());
		if (count > 0) {
			// 失败 用户名重复
			mv.addObject("exception", "操作失败请重试");
			mv.addObject("url", "抱歉");
			mv.setViewName("ErrorPage");
		} else {
			// 注册成功
			result = userService.register(user.getUserName(), user.getUserPass(), user.getUserAge(),
					user.getUserPhone(), user.getIDCardNum(), user.getUserLocation(), user.getUserEmail());
			mv.addObject("exception", "注册成功");
			mv.addObject("url", "恭喜");
			mv.setViewName("ErrorPage");
		}

		logger.info(result + user.toString());
		return mv;
	}

	@RequestMapping("/addPostView")
	public ModelAndView addPostView() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addPost");
		List<location> locations = userService.getAllLocation();
		mv.addObject("locations", locations);
		List<dogType> dogTypes = userService.getAllDogType();
		mv.addObject("dogTypes", dogTypes);
		return mv;
	}

	@RequestMapping("/dogSubmit")
	public ModelAndView addDog(String typeName) {
		ModelAndView mv = new ModelAndView();
		userService.addDog(typeName);
		mv.setViewName("manager/commonM");
		List<location> locations = userService.getAllLocation();
		mv.addObject("locations", locations);
		List<dogType> dogTypes = userService.getAllDogType();
		mv.addObject("dogs", dogTypes);
		return mv;
	}

	@RequestMapping("/locateSubmit")
	public ModelAndView addLocate(String locatName) {
		ModelAndView mv = new ModelAndView();
		userService.addLocate(locatName);
		mv.setViewName("manager/commonM");
		List<location> locations = userService.getAllLocation();
		mv.addObject("locations", locations);
		List<dogType> dogTypes = userService.getAllDogType();
		mv.addObject("dogs", dogTypes);
		return mv;
	}

	@RequestMapping("/PosterList")
	public ModelAndView findAllPoster() {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("postList");
		List<Poster> posters = userService.findAllPoster();
		mv.addObject("posters", posters);
		logger.info("" + posters.size());
		return mv;
	}

	@RequestMapping("/index2")
	public String index2() {
		return "inter";
	}

	@RequestMapping("/login")
	public ModelAndView login(String userName, String userPass, HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		logger.info("userName:" + userName + " " + userPass);

		User user = userService.login(userName);
		if (user == null) {
			mv.addObject("url", "抱歉");
			mv.addObject("execption", "操作失败请重试");
			mv.setViewName("ErrorPage");
		} else {
			if (userPass.equals(user.getUserPass())) {
				logger.info(user.toString());

				mv.addObject("exception", "用户已登录");
				mv.addObject("url", "操作成功");
				mv.setViewName("ErrorPage");
				req.getSession().setAttribute("LoginUser", user);
				mv.addObject("loginUser", user);
			} else {
				mv.addObject("exception", "用户名或密码错误");
				mv.addObject("url", "抱歉");
				mv.setViewName("ErrorPage");
			}
		}

		return mv;
	}

	@RequestMapping("/adLogin")
	public String adLogin(String userName, String userPass, HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		logger.info("userName:" + userName + " " + userPass);

		User user = userService.login(userName);
		if (user == null) {
			mv.addObject("url", "抱歉");
			mv.addObject("execption", "操作失败请重试");
			mv.setViewName("ErrorPage");
		} else {
			if (userPass.equals(user.getUserPass()) && user.getFlag() == 1) {
				logger.info(user.toString());

				req.getSession().setAttribute("LoginUser", user);

				return "redirect:/adminLogin";
			}
		}

		return "AdminLoginFalse";
	}

	@RequestMapping("/findUserByName")
	public ModelAndView findUserByName(String name) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		User user = userMapper.findByName(name);
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping("/pushReInfoView")
	public ModelAndView pushReInfoView(Integer appId) {
		ModelAndView mvAndView = new ModelAndView();
		// req.getSession().getAttribute("LoginUser").toString();
		System.out.println("appId :" + appId);
		adopt adoptInfo = userService.findReInfo(appId);
		if (adoptInfo == null) {
			mvAndView.addObject("url", "抱歉");
			mvAndView.addObject("execption", "您还没有试领养中的宠物");
			mvAndView.setViewName("ErrorPage");
		} else {
			System.out.println(adoptInfo.getPostId());
			Poster posterInfo = userService.findPosterById(adoptInfo.getPostId());
			if (posterInfo == null) {
				mvAndView.addObject("url", "抱歉");
				mvAndView.addObject("execption", "您还没有试领养中的宠物");
				mvAndView.setViewName("ErrorPage");

			} else {
				User userInfo = userService.findUserById(posterInfo.getOwnerId());
				if (userInfo.getFlag() == 6) {
					mvAndView.addObject("url", "抱歉");
					mvAndView.addObject("exception", "您已经发布过回访信息了哦！");
					mvAndView.setViewName("ErrorPage");
					return mvAndView;
				}
				// logger.info(posterInfo.toString());
				userService.changeUserStatuToReinfo(userInfo.getUserName());
				mvAndView.setViewName("addReInfo");
				mvAndView.addObject("userInfo", userInfo);
				mvAndView.addObject("posterInfo", posterInfo);
				mvAndView.addObject("adoptInfo", adoptInfo);
			}

		}

		return mvAndView;
	}

	@RequestMapping("addPost")
	public ModelAndView addPost(Poster poster, @RequestParam(value = "photo") MultipartFile photo,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		Long num = System.currentTimeMillis();
		String count = num.toString();
		logger.info(count);
		System.out.println(count);
		String title = poster.getTitle();
		String content = poster.getContent();
		Integer typeName = poster.getTypeName();
		Integer locatName = poster.getLocatName();
		Integer ownerId = poster.getOwnerId();
		System.out.println("title:" + title + " content:" + content + locatName + typeName + "ownerId:" + ownerId);

		ServletContext application = request.getServletContext();
		String realPath = application.getRealPath("userPhoto/");
		logger.info(realPath);
		int index = photo.getOriginalFilename().lastIndexOf(".");
		String suffix = photo.getOriginalFilename().substring(index + 1);
		String fileName = realPath + File.separator + count + "." + suffix;
		logger.info(fileName);
		try {
			photo.transferTo(new File(fileName));
		} catch (Exception e) {
			e.printStackTrace();
		}

		// poster.
		// return userService.addPost(title, content);
		int result = userService.addPost(title, content, suffix, count, typeName, locatName, ownerId);
		if (result > 0) {

			mv.addObject("url", "发布帖子成功");
			mv.setViewName("ErrorPage");

		} else {
			mv.addObject("url", 500);
			mv.addObject("exception", "发表失败，请重试");
			mv.setViewName("ErrorPage");
		}
		return mv;
	}

	@RequestMapping("Photo")
	public void posterPhoto(String imgType, String imgName, HttpServletRequest request, HttpServletResponse response) {
		// 找到文件
		ServletContext application = request.getServletContext();
		String realPath = application.getRealPath("userPhoto");
		// System.out.println(id);
		String fileName = realPath + File.separator + imgName + "." + imgType;
		System.out.println(fileName);
		File file = new File(fileName);
		if (file.exists()) {
			byte[] buffer = new byte[1024];
			FileInputStream fis = null;
			BufferedInputStream bis = null;
			try {
				fis = new FileInputStream(file);
				bis = new BufferedInputStream(fis);
				OutputStream os = response.getOutputStream();
				int i = bis.read(buffer);
				while (i != -1) {
					os.write(buffer, 0, i);
					i = bis.read(buffer);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (bis != null)
					try {
						bis.close();
					} catch (Exception e) {
					}
				if (fis != null)
					try {
						fis.close();
					} catch (Exception e) {
					}
			}
		}
	}

	@RequestMapping("Photo2")
	public void rePhoto(String imgType, String imgName, HttpServletRequest request, HttpServletResponse response) {
		// 找到文件
		ServletContext application = request.getServletContext();
		String realPath = application.getRealPath("userPhoto");
		// System.out.println(id);
		String fileName = realPath + File.separator + imgName;
		System.out.println(fileName);
		File file = new File(fileName);
		if (file.exists()) {
			byte[] buffer = new byte[1024];
			FileInputStream fis = null;
			BufferedInputStream bis = null;
			try {
				fis = new FileInputStream(file);
				bis = new BufferedInputStream(fis);
				OutputStream os = response.getOutputStream();
				int i = bis.read(buffer);
				while (i != -1) {
					os.write(buffer, 0, i);
					i = bis.read(buffer);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (bis != null)
					try {
						bis.close();
					} catch (Exception e) {
					}
				if (fis != null)
					try {
						fis.close();
					} catch (Exception e) {
					}
			}
		}
	}

	@RequestMapping(value = "/findByName2", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public User findByName2(String name) {
		return userMapper.findByName(name);

	}

	/*
	 * @ResponseBody
	 * 
	 * @RequestMapping("/add") public int insert(String name, Integer age) {
	 * return userService.addUser(name, age);
	 * 
	 * }
	 */

	@RequestMapping("pushReInfo")
	public ModelAndView pushReInfo(reInfo reIn, @RequestParam(value = "photo") MultipartFile photo,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		String s = UUID.randomUUID().toString();
		String name = s.substring(0, 8) + s.substring(9, 13) + s.substring(14, 18) + s.substring(19, 23)
				+ s.substring(24);
		Integer postId = reIn.getPostId();
		String title = reIn.getTitle();
		Integer ownerId = reIn.getOwnerId();
		String ownerName = reIn.getOwnerName();
		String appName = reIn.getAppName();
		String content = reIn.getContent();
		ServletContext application = request.getServletContext();
		String realPath = application.getRealPath("userPhoto/");
		logger.info(realPath);
		int index = photo.getOriginalFilename().lastIndexOf(".");
		String suffix = photo.getOriginalFilename().substring(index + 1);
		String fileName = realPath + File.separator + name + "." + suffix;
		logger.info(fileName);
		try {
			photo.transferTo(new File(fileName));
		} catch (Exception e) {
			e.printStackTrace();
		}

		// poster.
		// return userService.addPost(title, content);
		name = name + "." + suffix;
		int result = userService.addReInfo(postId, title, suffix, name, ownerId, ownerName, appName, content);
		if (result > 0) {
			mv.addObject("exception", "发布成功");
			mv.setViewName("ErrorPage");

		} else {
			mv.addObject("url", 500);
			mv.addObject("exception", "发表失败，请重试");
			mv.setViewName("ErrorPage");
		}
		return mv;

	}

	@RequestMapping("/reInfoDetail")
	public ModelAndView reInfodetail(Integer postId) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("reInfoDetail");
		reInfo reInfo = userService.findReInfoDetail(postId);
		mv.addObject("reInfo", reInfo);

		return mv;
	}
}
