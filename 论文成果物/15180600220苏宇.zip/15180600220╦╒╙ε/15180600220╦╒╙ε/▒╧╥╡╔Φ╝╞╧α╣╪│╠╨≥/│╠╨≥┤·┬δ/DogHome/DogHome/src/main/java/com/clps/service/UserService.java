package com.clps.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.clps.mapper.PostMapper;
import com.clps.mapper.UserMapper;
import com.clps.mapper.dogTypeMapper;
import com.clps.mapper.locationMapper;
import com.clps.model.Poster;

import com.clps.model.User;
import com.clps.model.adopt;
import com.clps.model.dogType;
import com.clps.model.location;
import com.clps.model.reInfo;

@Service
public class UserService {
	@Autowired
private UserMapper userMapper;
	@Autowired
	private PostMapper postMapper;
	@Autowired
	private locationMapper locationMapper;
	@Autowired
	private dogTypeMapper dogTypeMapper;
	@Transactional
	public int addPost(String title,String content,String imgType,String imgName,Integer typeName,Integer locatName,Integer ownerId)
	{
		return postMapper.addPost(title, content,imgType,imgName,typeName,locatName,ownerId);
		
	}
	@Transactional
	public User login(String userName)
	{
		return userMapper.findByName(userName);
	}
	
	public List<location> getAllLocation()
	{
		return locationMapper.getAllLocation();
	}
	public List<dogType> getAllDogType()
	{
		return dogTypeMapper.getAllDogType();
	}
/*	@Transactional
	public int addUser(String name,Integer age)
	{	
				int l=userMapper.insert(name, age);
				int k=5/0;
				return l;
	}*/
	@Transactional
	public List<Poster> findAllPoster()
	{
		return postMapper.findAllPoster();
	}
	public User findUserById(Integer userId) {
		// TODO Auto-generated method stub
		return userMapper.findUserById(userId);
	}
	public int updateInfoById(Integer userId, String userAge, String idCardNum, String userPhone, String userLocation,
			String userPass,String userEmail) {
		// TODO Auto-generated method stub
		return userMapper.updateInfoById(userId,userAge,idCardNum,userPhone,userLocation,userPass,userEmail);
	}
	public List<Poster> findPostByOwnerId(Integer userId) {
		// TODO Auto-generated method stub
		return userMapper.findPostByOwnerId(userId);
	}
	public int register(String userName, String userPass, String userAge, String userPhone, String idCardNum,
			String userLocation,String userEmail) {
		// TODO Auto-generated method stub
		return userMapper.register(userName,userPass,userAge, userPhone, idCardNum,
			userLocation,userEmail);
	}
	public int findUserByName(String userName) {
		// TODO Auto-generated method stub
		return userMapper.findUserByName(userName);
	}
	public List<Map<Integer, String>> findAdopterName(Integer userId) {
		// TODO Auto-generated method stub
		return userMapper.findAdopterName(userId);
	}
	public List<Integer> findAppId(Integer userId) {
		// TODO Auto-generated method stub
		return userMapper.findAppId(userId);
	}
	public String findAppnameByPostId(Integer integer) {
		// TODO Auto-generated method stub
		return userMapper.findAppnameByPostId(integer);
	}
	public List<adopt> findAppNamesByOwnerId(Integer userId) {
		// TODO Auto-generated method stub
		return userMapper.findAppNamesByOwnerId(userId);
	}
	public void setPostTry(Integer id) {
		// TODO Auto-generated method stub
		userMapper.setPostTry(id);
		
	}
	public void setPostTryRefuse(Integer id) {
		// TODO Auto-generated method stub
		userMapper.setPostTryRefuse(id);
	}
	public void setPosterTryRefuse(Integer postId) {
		// TODO Auto-generated method stub
		userMapper.setPosterTryRefuse(postId);
	}
	public void setPosterTry(Integer postId) {
		// TODO Auto-generated method stub
		userMapper.setPosterTry(postId);
		
	}
	public List<User> findAllUser() {
		// TODO Auto-generated method stub
		return userMapper.findAllUser();
	}
	public void changeUserStatu(String s) {
		// TODO Auto-generated method stub
		userMapper.changeUserStatu(s);
	}
	public adopt findReInfo(Integer appId) {
		// TODO Auto-generated method stub
		return userMapper.findReInfo(appId);
	}
	public Poster findPosterById(Integer postId) {
		// TODO Auto-generated method stub
		return userMapper.findPosterById(postId);
	}
	public int addReInfo(Integer postId, String title, String suffix, String fileName, Integer ownerId,
			String ownerName, String appName,String content) {
		// TODO Auto-generated method stub
		return userMapper.addReInfo(postId,title,suffix,fileName,ownerId,
				ownerName, appName,content);
	}
	public reInfo findReInfoDetail(Integer postId) {
		// TODO Auto-generated method stub
		return userMapper.findReInfoDetail(postId);
	}
	public void setAdoptFlagTwo(Integer postId) {
		 userMapper.setAdoptFlagTwo(postId);
		
	}
	public void setPosterFlagTwo(Integer postId) {
		// TODO Auto-generated method stub
		userMapper.setPosterFlagTwo(postId);
	}
	public void setReInfoFalgTwo(Integer postId) {
		// TODO Auto-generated method stub
		userMapper.setReInfoFlagTwo(postId);
	}
	public String findEmailByUserId(Integer appId) {
		// TODO Auto-generated method stub
		return userMapper.findEmailByUserId(appId);
	}
	public Integer findEmailByAdoptId(Integer id) {
		// TODO Auto-generated method stub
		return userMapper.findEmailByAdoptId(id);
	}
	public void setAdoptFlagThree(Integer postId) {
		// TODO Auto-generated method stub
		userMapper.setAdoptFlagThree(postId);
	}
	public void setPosterFlagZero(Integer postId) {
		// TODO Auto-generated method stub
		userMapper.setPosterFlagZero(postId);
	}
	public void setReInfoFalgThree(Integer postId) {
		// TODO Auto-generated method stub
		userMapper.setReInfoFlagThree(postId);
	}
	public void setUserFlagFour(Integer id) {
		// TODO Auto-generated method stub
		Integer userId = userMapper.findUserFlagFour(id);
		userMapper.setUserFlagFour(userId);
	}
	public void setUserFlagZero(Integer appId) {
		// TODO Auto-generated method stub
		userMapper.setUserFlagZero(appId);
	}
	public void changeUserStatuToReinfo(String userName) {
		// TODO Auto-generated method stub
		userMapper.changeUserStatuToHasPushReInfo(userName);
	}
	public List<dogType> findDogTypes() {
		// TODO Auto-generated method stub
		return userMapper.findDogTypes();
	}
	public List<location> findLocations() {
		// TODO Auto-generated method stub
		return userMapper.findLocations();
	}
	public void addDog(String typeName) {
		// TODO Auto-generated method stub
		userMapper.addDog(typeName);
	}
	public void addLocate(String locatName) {
		// TODO Auto-generated method stub
		userMapper.addLocate(locatName);
	}
	public void addChatInfo(String fromUsername, String toUsername, String time) {
		// TODO Auto-generated method stub
		userMapper.addChatInfo(fromUsername,toUsername,time);
	}
	public List<String> findChatInfo(String userName) {
		// TODO Auto-generated method stub
		return userMapper.findChatInfo(userName);
	}
	
	
	
	
	/*@Transactional
	public Poster2 findPoster2(String postId)
	{
		return postMapper.findPoster2(postId);
	}
	@Transactional
	public Poster3 findPoster3(String postId)
	{
		return postMapper.findPoster3(postId);
	}*/
}
