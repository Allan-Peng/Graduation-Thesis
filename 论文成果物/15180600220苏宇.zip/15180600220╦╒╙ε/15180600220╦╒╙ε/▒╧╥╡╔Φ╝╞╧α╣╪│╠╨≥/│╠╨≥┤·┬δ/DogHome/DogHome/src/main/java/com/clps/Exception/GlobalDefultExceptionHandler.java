package com.clps.Exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class GlobalDefultExceptionHandler {
	
	//声明要捕获的异常
	@ExceptionHandler(Exception.class)
	
	public String defultExcepitonHandler(HttpServletRequest request,Exception e) {
		request.setAttribute("url", "服务器异常");
		request.setAttribute("exception", "请稍后重试");
		return "ErrorPage";

	}
}


